// popup.js — ver 10
const SHEET_URL = "https://docs.google.com/spreadsheets/d/13TsZkazILYwR0tX60QRBlszroEdAfHEj02AhQdZdc9U/edit?usp=sharing";

document.getElementById("settingsBtn")?.addEventListener("click", () => chrome.runtime.openOptionsPage());
document.getElementById("sheetBtn")?.addEventListener("click", () => window.open(SHEET_URL, "_blank"));

let currentTabId = null;
const STALE_MS = 3 * 60 * 60 * 1000; // 3時間以上同期されていなければ「古い」

// 「3分前」のような相対時刻
function relTime(ts) {
  if (!ts) return "未同期";
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (s < 45) return "たった今";
  const m = Math.round(s / 60); if (m < 60) return `${m}分前`;
  const h = Math.round(m / 60); if (h < 24) return `${h}時間前`;
  return `${Math.round(h / 24)}日前`;
}

// 小さな通知（画面下に数秒だけ表示）
function showToast(message, kind) {
  let box = document.getElementById("ui-toasts");
  if (!box) { box = document.createElement("div"); box.id = "ui-toasts"; box.setAttribute("role", "status"); document.body.appendChild(box); }
  const t = document.createElement("div");
  t.className = "ui-toast" + (kind ? " " + kind : "");
  t.textContent = message;
  box.appendChild(t);
  while (box.children.length > 3) box.firstChild.remove();
  setTimeout(() => { t.classList.add("leaving"); setTimeout(() => t.remove(), 250); }, kind === "error" ? 5000 : 2200);
}

// 単語の同期カードの表示
async function renderSync() {
  const d = await chrome.storage.local.get({ storedKeywords: [], lastSyncAt: null, lastSyncError: null });
  const n = (d.storedKeywords || []).length;
  let state = "fresh", title, sub;
  if (!d.lastSyncAt || n === 0) {
    state = "none"; title = "単語が未同期です"; sub = "内蔵の単語だけで判定しています。同期をおすすめします";
  } else if (Date.now() - d.lastSyncAt > STALE_MS || d.lastSyncError) {
    state = "stale"; title = d.lastSyncError ? "同期に失敗しています" : "同期が古くなっています";
    sub = `最終同期 ${relTime(d.lastSyncAt)}・シートの単語 ${n.toLocaleString()}件`;
  } else {
    title = "単語は最新です"; sub = `シートの単語 ${n.toLocaleString()}件・${relTime(d.lastSyncAt)}に同期`;
  }
  const strip = document.getElementById("syncStrip");
  if (strip) strip.dataset.state = state;
  document.getElementById("syncTitle").textContent = title;
  document.getElementById("syncSub").textContent = sub;
}


// ===== お知らせカード（ver10.2：新しい版・試験版・運用のお知らせ。最大3件） =====
// 見せるかどうか（版の比較・［あとで］・［この件は無視］・試験版のスイッチ・期間）は background.js が決める。
// 文字はすべて textContent で入れる（HTMLとして解釈しない）。リンクは background.js で https:// のものだけに絞ってある。
function renderUpdateCard() {
  chrome.runtime.sendMessage({ type: "getNotices" }, (res) => {
    void chrome.runtime.lastError;
    const box = document.getElementById("updateCards");
    if (!box) return;
    box.textContent = "";
    const list = (res && Array.isArray(res.notices)) ? res.notices : [];
    for (const n of list) {
      const card = document.createElement("div");
      card.className = "update-card";
      const title = document.createElement("div");
      title.className = "u-title";
      const tag = document.createElement("span");
      tag.className = "u-tag" + (n.kind === "beta" ? " beta" : n.kind === "notice" ? " info" : "");
      tag.textContent = n.kind === "beta" ? "試験版" : n.kind === "notice" ? "お知らせ" : "新しい版";
      title.appendChild(tag);
      title.appendChild(document.createTextNode(n.title || (n.version ? `バージョン ${n.version}` : "お知らせ")));
      card.appendChild(title);
      if (n.message) { const m = document.createElement("div"); m.className = "u-msg"; m.textContent = n.message; card.appendChild(m); }
      if (n.sub) { const m = document.createElement("div"); m.className = "u-sub"; m.textContent = n.sub; card.appendChild(m); }
      const row = document.createElement("div");
      row.className = "u-row";
      for (const l of (n.links || []).slice(0, 3)) {
        if (!l || !l.name || !/^https:\/\//i.test(l.url || "")) continue;
        const b = document.createElement("button");
        b.type = "button"; b.className = "primary"; b.textContent = l.name;
        b.onclick = () => chrome.tabs.create({ url: l.url });
        row.appendChild(b);
      }
      const act = (action) => () => {
        chrome.runtime.sendMessage({ type: "noticeAction", action, id: n.id }, () => { void chrome.runtime.lastError; card.remove(); });
      };
      const later = document.createElement("button"); later.type = "button"; later.textContent = "あとで"; later.onclick = act("later");
      const ign = document.createElement("button"); ign.type = "button"; ign.textContent = "この件は無視"; ign.onclick = act("ignore");
      row.appendChild(later); row.appendChild(ign);
      card.appendChild(row);
      box.appendChild(card);
    }
  });
}

// ===== このページを報告（ver10.1） =====
// 対象タブのURL（?以降・#以降は除く）・タイトル・検出された語を渡して、報告画面を新しいタブで開く
function stripQueryAndHash(url) {
  try { const u = new URL(String(url || "")); return u.origin + u.pathname; } catch (_e) { return ""; }
}
function openFeedback() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs[0];
    const open = (words) => {
      const q = new URLSearchParams();
      q.set("url", stripQueryAndHash(tab && tab.url));
      q.set("title", String((tab && tab.title) || "").slice(0, 200));
      // 語は、合計1500文字までに収める（JSONの途中で切れないよう、語単位で数える）
      const keep = []; let len = 0;
      for (const w of (words || []).slice(0, 50)) { len += String(w).length + 4; if (len > 1500) break; keep.push(String(w)); }
      q.set("words", JSON.stringify(keep));
      chrome.tabs.create({ url: chrome.runtime.getURL("feedback.html") + "?" + q.toString() });
      window.close();
    };
    if (!tab || tab.id == null) { open([]); return; }
    // 検出された語（パネルに出ている結果）。取れなければ空でよい
    let done = false;
    const finish = (w) => { if (done) return; done = true; open(w); };
    const timer = setTimeout(() => finish([]), 800);
    chrome.tabs.sendMessage(tab.id, { type: "getDetectedWords" }, (res) => {
      void chrome.runtime.lastError;
      clearTimeout(timer);
      finish(res && Array.isArray(res.words) ? res.words.filter((x) => typeof x === "string") : []);
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  // バージョン表示は manifest.json から読む（表記がずれないように）
  const verEl = document.getElementById("popupVer");
  if (verEl) verEl.textContent = "v" + chrome.runtime.getManifest().version;

  // 一括スキャン画面（保存したHTML・スクショのフォルダをまとめて判定）を新しいタブで開く
  document.getElementById("bulkScanBtn")?.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("bulk.html") });
  });

  // 常時表示パネルの透明度（5%刻み・動かすたびに保存＝開いているページへリアルタイム反映）
  const transSlider = document.getElementById("panelTransSlider");
  const transVal = document.getElementById("panelTransVal");
  if (transSlider && transVal) {
    const showTrans = (v) => { transVal.textContent = `${v}%`; };
    getPanelTransparency((v) => { transSlider.value = String(v); showTrans(v); });
    transSlider.addEventListener("input", () => {
      const v = normalizePanelTransparency(transSlider.value);
      showTrans(v);
      setPanelTransparency(v);
    });
  }

  // 常時表示パネルの位置リセット（初期位置＝画面左下へ戻す）
  const posResetBtn = document.getElementById("panelPosResetBtn");
  posResetBtn?.addEventListener("click", () => {
    resetPanelPosition(() => {
      const original = posResetBtn.textContent;
      posResetBtn.textContent = "リセットしました";
      setTimeout(() => { posResetBtn.textContent = original; }, 1200);
    });
  });

  // オフにしたいサイト（プルダウン。入力内容は設定画面と同じ保存先）
  // ポップアップは外をクリックすると閉じるため、入力中の下書きを控えて、開き直したときに復元する
  setupDisabledSitesEditor({
    textarea: document.getElementById("dsText"),
    saveBtn: document.getElementById("dsSaveBtn"),
    copyBtn: document.getElementById("dsCopyBtn"),
    msg: document.getElementById("dsMsg"),
    count: document.getElementById("dsCount"),
  }, { draftKey: "disabledSitesDraft" });
  // 下書きが残っていれば、閉じたままだと気づけないので開いておく
  try {
    if (localStorage.getItem("disabledSitesDraft") != null) document.getElementById("dsBox").open = true;
  } catch (_e) { /* 無視 */ }

  // アップデートのお知らせ
  renderUpdateCard();

  // このページを報告
  document.getElementById("feedbackBtn")?.addEventListener("click", openFeedback);

  // 単語の同期
  renderSync();
  document.getElementById("syncNowBtn")?.addEventListener("click", () => {
    const btn = document.getElementById("syncNowBtn");
    btn.disabled = true; btn.textContent = "同期中…";
    chrome.runtime.sendMessage({ type: "syncNow" }, async (res) => {
      void chrome.runtime.lastError;
      btn.disabled = false; btn.textContent = "今すぐ同期";
      await renderSync();
      if (res && res.ok) showToast(`単語を同期しました（${(res.keywords || 0).toLocaleString()}件）`, "ok");
      else showToast("同期に失敗しました。ネットワークを確認して、もう一度お試しください", "error");
    });
  });

  // マスタートグル
  getFeatureSettings((settings) => {
    const masterToggle = document.getElementById("masterMiniToggle");
    masterToggle.checked = settings.master;
    masterToggle.addEventListener("change", () => {
      settings.master = masterToggle.checked;
      // 自動では再読み込みしない（入力中のフォーム等が消えるため）。確認してから実行する
      saveFeatureSettings(settings, () => {
        const notice = document.getElementById("reloadNotice");
        if (notice) notice.hidden = false;
      });
    });

    document.getElementById("reloadNowBtn")?.addEventListener("click", () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) chrome.tabs.reload(tabs[0].id);
        window.close();
      });
    });
    document.getElementById("reloadLaterBtn")?.addEventListener("click", () => {
      document.getElementById("reloadNotice").hidden = true;
    });

    // OCR機能が無効の場合はOCRボタンを非表示
    if (!isFeatureActive(settings, "ocrScan")) {
      const ocrBtn = document.getElementById("ocrScanBtn");
      if (ocrBtn) ocrBtn.style.display = "none";
    }
  });

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (tab) currentTabId = tab.id;
  });

  // 手動OCRスキャン実行
  document.getElementById("ocrScanBtn")?.addEventListener("click", () => {
    if (!currentTabId) return;
    const btn = document.getElementById("ocrScanBtn");
    btn.textContent = "画像を解析中（OCR）...";
    btn.disabled = true;

    chrome.tabs.sendMessage(currentTabId, { type: "triggerImageOcr" }, (response) => {
      if (chrome.runtime.lastError) {
        btn.textContent = "このページでは実行できません";
        setTimeout(() => {
          btn.textContent = "ページ内画像のOCR再スキャン";
          btn.disabled = false;
        }, 2000);
        return;
      }

      btn.textContent = response?.newFound > 0
        ? `新たに画像から ${response.newFound} 件検出！`
        : "画像解析完了（新規なし）";

      setTimeout(() => {
        btn.textContent = "ページ内画像のOCR再スキャン";
        btn.disabled = false;
      }, 2000);
    });
  });
});

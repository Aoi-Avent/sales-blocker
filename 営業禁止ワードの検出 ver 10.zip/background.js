importScripts("featureConfig.js", "settingsBackup.js");

// TODO: 「営業禁止ワード」用スプレッドシートのGAS URLを設定してください
const SPREADSHEET_URL = "https://script.google.com/macros/s/AKfycbxh-Us-sm5ZbJn6pfY079Bv0FFu9A6zBGupggoh0Horlwhew7kuhtcezkdXHUG0r10K/exec";
// TODO: 除外フレーズ用スプレッドシートのGAS URLを設定してください（未設定可）
const EXCLUDED_PHRASES_URL = "https://script.google.com/macros/s/AKfycbx3fGsHyGQ7kDX3qsl9g6-5WgQY9dqZbT30bMncQfMuAnZGZWVDQhiZqxGetnKKNPeI/exec";
// TODO: 警告ダイアログ強化（営業/禁止・お断り/一発アウト）ワード用スプレッドシートのGAS URLを設定してください（未設定可）
// GASのdoGet()は { eigyo: [...], kotowari: [...], instant: [...] } 形式のJSONを返す必要があります
const CATEGORY_WORDS_URL = "https://script.google.com/macros/s/AKfycbwfKEoDI_FNXtnF1swGLeIreuuEAtm5TV6u5Aw2DJAl7DlysA_XdrFszoZm6hcQtbLx/exec";

// ===== 新しいGAS「共通API」（ver10.1：フィードバック送信・アップデート通知・危険サイトリスト） =====
// 値は、手順書.md のとおりにデプロイしたあと、依頼者が貼る（ここはダミー。README等には書かない）。
// 未設定のあいだは、これらの機能だけが動かない（ほかの部分は今までどおり）。
const SHARED_API_URL = "https://script.google.com/macros/s/AKfycbzv-heKIV0ahs5WpTry0SJP8ke8yvj1vx8atOKpG5_weveBown3zx2QoIwEl1abo8Wo/exec";
const SHARED_API_TOKEN = "aoi-apps-script-notify";
function isSharedApiConfigured() {
  return /^https:\/\/script\.google\.com\//.test(SHARED_API_URL) && !!SHARED_API_TOKEN && SHARED_API_TOKEN !== "ここに合言葉を貼る";
}
// ver10.2: Windows標準（Chrome）の通知は使わない。お知らせは、ページ上のカード・ポップアップ・バッジ「NEW」で出す
const UPDATE_SNOOZE_MS = 24 * 60 * 60 * 1000; // ［あとで］で見えなくする時間

// ===== 設定のバックアップ（Chrome同期）と、入れ直した直後の自動復元（ver9.13） =====
// 起動時・インストール／更新時：ローカルに無い項目だけ同期から戻し、そのあと現在の設定を同期へバックアップする。
// 普段の変更は、保存のたびに少し待ってから（まとめて）同期へ書く（同期の書き込み回数の上限に当たらないように）。
let backupPushTimer = null;
function restoreThenBackup() {
  restoreFromSync(false).then(() => pushLocalToSync()).catch(() => {});
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !BACKUP_SYNC_KEYS.some((k) => k in changes)) return;
  clearTimeout(backupPushTimer);
  backupPushTimer = setTimeout(() => { pushLocalToSync(); }, 1500);
});

chrome.runtime.onInstalled.addListener(() => {
  restoreThenBackup();
  fetchKeywords();
  fetchExcludedPhrases();
  fetchCategoryWords();
  fetchSharedInfo();
  fetchDangerList();
  // ver8.47までの「要注意フォームの記憶」機能を廃止したため、残っていれば掃除する
  chrome.storage.local.remove("knownOffenderForms");
});
chrome.runtime.onStartup.addListener(() => {
  restoreThenBackup();
  fetchKeywords();
  fetchExcludedPhrases();
  fetchCategoryWords();
  fetchSharedInfo();
  fetchDangerList();
});

// ===== 一時停止中のツールバーバッジ「OFF」（ver9.11） =====
// pausedUntil（ミリ秒）を現在時刻と比べて決める。alarms は使わない。
// サービスワーカーは随時止まるため「期限になったら消す」予約はできない。代わりに、次のきっかけのたびに比べ直す：
//  起動／ワーカーの復帰（このファイルの最後の呼び出し）・pausedUntil の変更・タブの切り替え・ページの読み込み・ウィンドウの切り替え・
//  期限が来たことを知った content.js からの refreshBadge
// ver9.14: 全体スイッチ（featureSettings.master）がオフのときも、同じ「OFF」バッジを出す
function updatePauseBadge() {
  chrome.storage.local.get({ pausedUntil: 0, featureSettings: null, updateInfo: null, noticeSnooze: null, noticeIgnored: [] }, (d) => {
    const paused = Number(d.pausedUntil) > Date.now();
    const masterOff = !!(d.featureSettings && d.featureSettings.master === false);
    const off = paused || masterOff;
    if (off) {
      // 「OFF」が優先（見落とし防止のため、NEW より目立たせる）
      chrome.action.setBadgeText({ text: "OFF" });
      chrome.action.setBadgeBackgroundColor({ color: "#757575" });
    } else if (pickNotices(d).length > 0) {
      chrome.action.setBadgeText({ text: "NEW" });
      chrome.action.setBadgeBackgroundColor({ color: "#1976d2" });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
  });
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.pausedUntil || changes.featureSettings || changes.updateInfo || changes.noticeSnooze || changes.noticeIgnored)) updatePauseBadge();
});
chrome.tabs.onActivated.addListener(updatePauseBadge);
chrome.tabs.onUpdated.addListener((_tabId, info) => { if (info.status === "loading") updatePauseBadge(); });
chrome.windows.onFocusChanged.addListener(updatePauseBadge);
updatePauseBadge();

// ===== 単語の自動同期（ver10：間隔は設定画面で変更可。標準15分） =====
// 同じ間隔のアラームが既にあるときは作り直さない（作り直すと、サービスワーカーが起動するたびに
// 次の同期までの時間が数え直しになり、間隔が長いと実行されにくくなるため）。
function scheduleSyncAlarm(force) {
  chrome.storage.local.get({ [SYNC_INTERVAL_KEY]: SYNC_INTERVAL_DEFAULT }, (d) => {
    const minutes = normalizeSyncInterval(d[SYNC_INTERVAL_KEY]);
    chrome.alarms.get("syncKeywords", (alarm) => {
      if (!force && alarm && alarm.periodInMinutes === minutes) return;
      chrome.alarms.create("syncKeywords", { periodInMinutes: minutes });
    });
  });
}
scheduleSyncAlarm(false);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[SYNC_INTERVAL_KEY]) scheduleSyncAlarm(true);
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "syncKeywords") {
    fetchKeywords();
    fetchExcludedPhrases();
    fetchCategoryWords();
    fetchSharedInfo();
    fetchDangerList();
  }
});

// ===== Offscreen Document 管理 (OCR処理用) =====
let creatingOffscreenPromise = null;
async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });
  if (existingContexts.length > 0) return;

  if (creatingOffscreenPromise) {
    await creatingOffscreenPromise;
    return;
  }

  creatingOffscreenPromise = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['WORKERS', 'BLOBS'],
    justification: 'Perform Tesseract OCR on webpage images to detect sales prohibition keywords',
  });
  await creatingOffscreenPromise;
  creatingOffscreenPromise = null;
}

// 画像URLをBase64 DataURLに変換（クロスオリジン画像対応）
async function fetchImageAsDataUrl(url) {
  if (url.startsWith("file://")) {
    return url;
  }
  try {
    const res = await fetch(url, { mode: 'cors' });
    const blob = await res.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  } catch (err) {
    return url;
  }
}

// ===== キーワード同期 =====
async function fetchKeywords() {
  try {
    const response = await fetch(SPREADSHEET_URL);
    const keywords = await response.json();

    chrome.storage.local.set({
      storedKeywords: keywords,
      lastSyncAt: Date.now(),
      lastSyncError: null,
    });
  } catch (e) {
    console.error("キーワードの同期に失敗しました", e);
    chrome.storage.local.set({ lastSyncError: String(e), lastSyncErrorAt: Date.now() });
    getFeatureSettings((settings) => {
      if (isFeatureActive(settings, "syncFailureNotify")) {
        notifySyncFailure("キーワード");
      }
    });
  }
}

// ===== 除外フレーズ同期 =====
async function fetchExcludedPhrases() {
  if (!EXCLUDED_PHRASES_URL) return;
  try {
    const response = await fetch(EXCLUDED_PHRASES_URL);
    const phrases = await response.json();
    chrome.storage.local.set({
      syncedExcludedPhrases: phrases,
      lastExcludedSyncAt: Date.now(),
      lastExcludedSyncError: null,
    });
  } catch (e) {
    console.error("除外フレーズの同期に失敗しました", e);
    chrome.storage.local.set({ lastExcludedSyncError: String(e), lastExcludedSyncErrorAt: Date.now() });
    getFeatureSettings((settings) => {
      if (isFeatureActive(settings, "syncFailureNotify")) {
        notifySyncFailure("除外フレーズ");
      }
    });
  }
}

// ===== 警告ダイアログ強化ワード同期（営業/禁止・お断り/一発アウト） =====
async function fetchCategoryWords() {
  if (!CATEGORY_WORDS_URL) return;
  try {
    const response = await fetch(CATEGORY_WORDS_URL);
    const data = await response.json();
    chrome.storage.local.set({
      syncedCategoryWords: {
        eigyo: Array.isArray(data?.eigyo) ? data.eigyo : [],
        kotowari: Array.isArray(data?.kotowari) ? data.kotowari : [],
        instant: Array.isArray(data?.instant) ? data.instant : [],
      },
      lastCategorySyncAt: Date.now(),
      lastCategorySyncError: null,
    });
  } catch (e) {
    console.error("カテゴリー別ワードの同期に失敗しました", e);
    chrome.storage.local.set({ lastCategorySyncError: String(e), lastCategorySyncErrorAt: Date.now() });
    getFeatureSettings((settings) => {
      if (isFeatureActive(settings, "syncFailureNotify")) {
        notifySyncFailure("カテゴリー別ワード");
      }
    });
  }
}

function notifySyncFailure(label) {
  if (!chrome.notifications) return;
  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon48.png",
    title: `${label}の同期に失敗しました`,
    message: "ネットワーク状況を確認するか、設定画面から手動で再同期してください。",
    priority: 2,
  });
}

// ===== 共通API：お知らせ（H）・危険サイトリスト（I）の取得 =====
// 単語の同期と同じタイミング（アラーム・起動時）に取る。失敗しても、ほかの同期には影響させない（通知も出さない）。
async function sharedApiGet(action) {
  const u = new URL(SHARED_API_URL);
  u.searchParams.set("action", action);
  u.searchParams.set("t", SHARED_API_TOKEN);
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 20000);
  try {
    const res = await fetch(u.toString(), { signal: ctl.signal });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const json = await res.json();
    if (!json || json.ok !== true) throw new Error("bad response");
    return json;
  } finally {
    clearTimeout(timer);
  }
}

// 「9.14」「10」「10.1」「10.10」を、ドットで区切った数字ごとに比べる（a>b:1, a<b:-1, 同じ:0）
function compareVersions(a, b) {
  const pa = String(a).split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b).split(".").map((x) => parseInt(x, 10) || 0);
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

// ===== お知らせカード（ver10.2：新仕様） =====
// 共通API（action=info）は { ok:true, items:[ {id, kind, version, title, message, sub, links:[{name,url}], start, end} ] } を返す。
// kind：stable（正式版）／beta（試験版）／notice（お知らせ）。古い形式 { stable:{...}, beta:{...} } も読める（GASを入れ替える前の互換）。
function sanitizeLinks(links) {
  const out = [];
  for (const l of Array.isArray(links) ? links : []) {
    if (!l || typeof l !== "object") continue;
    const name = String(l.name || "").trim().slice(0, 40);
    const url = String(l.url || "").trim();
    if (!name || !/^https:\/\//i.test(url)) continue; // 名前が空・https:// でないものは出さない
    out.push({ name, url: url.slice(0, 500) });
    if (out.length >= 3) break;
  }
  return out;
}
function sanitizeNoticeItem(n) {
  if (!n || typeof n !== "object") return null;
  const id = String(n.id || "").trim().slice(0, 60);
  if (!id) return null;
  const kind = n.kind === "stable" || n.kind === "beta" || n.kind === "notice" ? n.kind : "";
  if (!kind) return null;
  let version = String(n.version || "").trim();
  if (kind !== "notice") {
    if (!/^\d+(\.\d+)*$/.test(version)) return null; // 版のお知らせは、版の番号が必要
  } else if (!/^\d+(\.\d+)*$/.test(version)) {
    version = "";
  }
  const day = (v) => (/^\d{4}-\d{2}-\d{2}/.test(String(v || "")) ? String(v).slice(0, 10) : "");
  return {
    id, kind, version,
    title: String(n.title || "").slice(0, 100),
    message: String(n.message || "").slice(0, 1000),
    sub: String(n.sub || "").slice(0, 2000),
    links: sanitizeLinks(n.links),
    start: day(n.start), end: day(n.end),
  };
}
function sanitizeNoticeList(json) {
  const out = [];
  if (Array.isArray(json && json.items)) {
    for (const it of json.items) { const n = sanitizeNoticeItem(it); if (n) out.push(n); if (out.length >= 10) break; }
    return out;
  }
  // 古い形式（stable / beta）→ 新しい形に直す
  for (const kind of ["stable", "beta"]) {
    const o = json && json[kind];
    if (!o || typeof o !== "object") continue;
    const version = String(o.version || "").trim();
    const url = String(o.url || "").trim();
    const n = sanitizeNoticeItem({
      id: `${kind === "stable" ? "v" : "beta-v"}${version}`, kind, version,
      title: o.title, message: o.message,
      links: url ? [{ name: "手順を開く", url }] : [],
    });
    if (n) out.push(n);
  }
  return out;
}

function todayKey() {
  const d = new Date();
  const p = (x) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

// いま見せるべきお知らせの一覧（新しい順に最大10件。無ければ空）。
// 条件：正式版＝拡張機能の版より新しいときだけ／試験版＝新しく、かつスイッチ「試験版のお知らせも受け取る」がオン／お知らせ＝期間内なら常に
//       ＋［あとで］の24時間内でない／［この件は無視］のIDでない。版の新旧は compareVersions（9.14・10・10.1 を正しく比べる）
function pickNotices(d) {
  const info = d && d.updateInfo;
  const items = info && Array.isArray(info.items) ? info.items : [];
  if (!items.length) return [];
  const cur = chrome.runtime.getManifest().version;
  const betaOn = !!(d.featureSettings && d.featureSettings.features && d.featureSettings.features.betaNotice === true);
  const ignored = new Set(Array.isArray(d.noticeIgnored) ? d.noticeIgnored : []);
  const snooze = d.noticeSnooze && typeof d.noticeSnooze === "object" ? d.noticeSnooze : {};
  const today = todayKey();
  const now = Date.now();
  const out = [];
  for (const n of items) {
    if (!n || ignored.has(n.id)) continue;
    if (Number(snooze[n.id]) > now) continue;
    if (n.start && today < n.start) continue; // 表示開始日の前
    if (n.end && today > n.end) continue;     // 表示終了日の後（終了日の当日までは出す）
    if (n.kind === "stable" && compareVersions(n.version, cur) <= 0) continue;
    if (n.kind === "beta" && (!betaOn || compareVersions(n.version, cur) <= 0)) continue;
    out.push(n);
  }
  return out;
}

async function fetchSharedInfo() {
  if (!isSharedApiConfigured()) return;
  try {
    const json = await sharedApiGet("info");
    const items = sanitizeNoticeList(json);
    // 期限切れ・無くなったお知らせの「あとで」「無視」の記録を片づける（保存が増え続けないように）
    const d = await chrome.storage.local.get({ noticeSnooze: null, noticeIgnored: [] });
    const ids = new Set(items.map((n) => n.id));
    const snooze = {};
    for (const [k, v] of Object.entries(d.noticeSnooze && typeof d.noticeSnooze === "object" ? d.noticeSnooze : {})) {
      if (ids.has(k) && Number(v) > Date.now()) snooze[k] = v;
    }
    const keepIgnored = (Array.isArray(d.noticeIgnored) ? d.noticeIgnored : []).filter((k) => ids.has(k));
    await chrome.storage.local.set({ updateInfo: { items, fetchedAt: Date.now() }, noticeSnooze: snooze, noticeIgnored: keepIgnored });
  } catch (e) {
    console.warn("お知らせの取得に失敗しました", e);
  }
}

// 危険サイトのキーの正規化（content.js の normalizeDangerUrl と同じ規則）
// フォーム：スキーム・www.・?以降・#以降・末尾の/を除く（ホスト名は小文字、パスはそのまま）
function normalizeDangerUrlKey(raw) {
  try {
    let t = String(raw || "").trim();
    if (!t) return "";
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(t)) t = "https://" + t;
    const u = new URL(t);
    if (u.protocol !== "http:" && u.protocol !== "https:") return "";
    return u.hostname.toLowerCase().replace(/^www\./, "") + u.pathname.replace(/\/+$/, "");
  } catch (_e) { return ""; }
}
// ドメイン：ホスト名だけを小文字で（www.は除く）
function normalizeDangerDomainKey(raw) {
  try {
    let t = String(raw || "").trim();
    if (!t) return "";
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(t)) t = "https://" + t;
    return new URL(t).hostname.toLowerCase().replace(/^www\./, "");
  } catch (_e) { return ""; }
}

async function fetchDangerList() {
  if (!isSharedApiConfigured()) return;
  try {
    const json = await sharedApiGet("danger");
    // 数千件でも軽く照合できるよう、キーで引ける形（オブジェクト）で持つ。同じキーは先に書かれた行を優先
    const forms = Object.create(null), domains = Object.create(null);
    let count = 0;
    for (const it of Array.isArray(json.items) ? json.items : []) {
      if (!it || typeof it.key !== "string") continue;
      const reason = String(it.reason || "").slice(0, 200);
      if (it.type === "form") {
        const k = normalizeDangerUrlKey(it.key);
        if (k && !(k in forms)) { forms[k] = reason; count++; }
      } else if (it.type === "domain") {
        const k = normalizeDangerDomainKey(it.key);
        if (k && !(k in domains)) { domains[k] = reason; count++; }
      }
    }
    await chrome.storage.local.set({ dangerList: { forms: { ...forms }, domains: { ...domains }, count, fetchedAt: Date.now() } });
  } catch (e) {
    console.warn("危険サイトリストの取得に失敗しました", e);
  }
}

// フィードバックの送信（feedback.js から）。?以降・#以降のURL、ページ本文、Cookieは送らない
function stripQueryAndHash(url) {
  try {
    const u = new URL(String(url || ""));
    return u.origin + u.pathname;
  } catch (_e) { return ""; }
}
async function postFeedback(p) {
  if (!isSharedApiConfigured()) return { ok: false, error: "not configured" };
  if (!p || typeof p.kind !== "string" || !p.kind) return { ok: false, error: "invalid" };
  const shot = p.screenshot && typeof p.screenshot.data === "string" && p.screenshot.data ? { mime: "image/jpeg", data: p.screenshot.data } : null;
  const body = JSON.stringify({
    token: SHARED_API_TOKEN,
    type: "feedback",
    kind: p.kind,
    url: stripQueryAndHash(p.url),
    title: String(p.title || "").slice(0, 200),
    words: String(p.words || "").slice(0, 1000),
    comment: String(p.comment || "").slice(0, 500),
    reporter: String(p.reporter || "").slice(0, 50),
    version: chrome.runtime.getManifest().version,
    sentAt: new Date().toISOString(),
    screenshot: shot,
  });
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 45000);
  try {
    // text/plain で送る（GASで余計な確認＝プリフライトが入らないため）
    const res = await fetch(SHARED_API_URL, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body, signal: ctl.signal });
    if (!res.ok) return { ok: false, error: "HTTP " + res.status };
    const json = await res.json();
    return { ok: !!(json && json.ok === true), error: json && json.error };
  } catch (e) {
    return { ok: false, error: String(e) };
  } finally {
    clearTimeout(timer);
  }
}

// ===== サイト全体スキャン (Site-Wide Scan) =====
const SITE_SCAN_MAX_PAGES = 25;
const SITE_SCAN_CONCURRENCY = 3;
const SITE_SCAN_FETCH_TIMEOUT_MS = 8000;
const SITE_SCAN_REQUEST_DELAY_MS = 250;
const SITE_SCAN_TTL_MS = 1 * 24 * 60 * 60 * 1000; // 1日間キャッシュ
const SITE_SCAN_STORAGE_PREFIX = "siteScan_";

const SITE_SCAN_DEFAULT_KEYWORDS = [
  "営業お断り", "営業禁止", "営業はお断り", "営業目的のお断り",
  "セールスお断り", "勧誘お断り",
  "お断りしております", "お断りいたします", "お断りします",
  "お受けしておりません", "お受けできません", "受け付けておりません",
  "ご遠慮ください", "ご遠慮いただいております", "ご遠慮願います",
  "固くお断り", "固くお断りしております",
  "営業電話", "営業のお電話", "営業のお電話はお断り",
  "テレアポ", "テレアポお断り",
  "飛び込み営業", "訪問販売",
  "営業メール", "営業メールはお断り",
  "セールスメール", "ダイレクトメール", "DM",
  "営業のご連絡", "営業のご案内", "営業のご訪問",
  "営業目的", "営業目的の問い合わせ", "営業目的のご連絡",
  "営利目的", "営利目的の問い合わせ",
  "商用利用", "商用", "商業目的",
  "営業行為", "営業活動", "勧誘行為", "勧誘", "売り込み", "売りこみ",
  "おことわり", "お断り",
  "no sales", "no solicitation", "no cold calls", "no telemarketing",
  "sales prohibited", "solicitation prohibited",
  "do not contact", "no marketing", "no commercial",
  "unsolicited", "business inquiries only",

  // --- ここから ver8.31 追加分（警告ダイアログ強化） ---
  "ご提案", "うりこみ", "ご提案に関するメール", "営業を目的としたお問い合わせ",
  "お問い合わせフォームからのセールス", "セールス", "営業の電話", "サービス提案",
  "業者", "お客様以外のご利用", "広告の問い合わせ", "広告", "広告宣伝メール",
  "への営業は", "営利目的", "営利", "営業関連", "宣伝", "宣伝行為",
  "不適切な宣伝行為", "フォームの利用", "フォーム",
  "ご対応は致しかねます", "ご対応はいたしかねます", "ご遠慮いただいております",
  "お断りさせて", "遠慮", "ご遠慮", "ご遠慮下さい", "ご遠慮いただきますよう",
  "固くおことわり", "返信いたしかねます", "返信致しかねます", "返信いたしません",
  "返信しておりません", "返信を行わない", "返信をしない", "固くお断りいたします",
  "お控え", "お控えください", "お控え下さい", "拒否致します",
  "営業・ご提案のご連絡は、会社概要のメールよりお願いいたします",
  "業者等のご連絡はお断りさせていただきます", "業者等のご連絡はお断り",
  "営業権のご購入", "営業権", "への営業は専用窓口をご利用ください",
  "誠に恐れ入りますが、企業様からのお問い合わせは、こちらのフォームの利用はご遠慮ください",
  "このお問い合わせフォームでの特定電子メールの送信を拒否致します",
  "法第３条第１項[特定電子メールの送信の制限]に抵触しているのが確認された場合",
  "一般財団法人日本データ通信協会に迷惑メールとして情報提供しております。",
  "法第３条第１項", "特定電子メール法", "電子メール法", "メール法",
  "特定電子メール", "特定電子", "特定電子メールの送信の制限",
  "電子メール広告", "メールの送信の制限", "送信の制限",
];

const SITE_SCAN_LINK_HINTS = [
  "会社概要", "会社案内", "企業情報", "代表挨拶", "about", "company", "profile",
  "プライバシー", "個人情報", "privacy", "policy",
  "特定商取引", "特商法", "tokushoho",
  "利用規約", "規約", "terms", "kiyaku",
  "料金", "price", "plan",
  "よくある質問", "faq", "q-a", "qa",
  "サイトポリシー", "site-policy",
  "サイトマップ", "sitemap", "site-map",
];

const SITE_SCAN_EXCLUDED_PHRASES = [
  "営業時間", "営業受付時間", "営業所", "営業情報", "営業担当",
  "営業日中", "営業日", "年末年始の営業",
  "営業しております", "営業しています",
  "セールスエンジニア",
];

// 警告ダイアログ（content.js）側と同じ内蔵デフォルト。サイト全体スキャンでも
// 「営業」＋「禁止・お断り」の組み合わせ／一発アウトの判定に使う。
const SITE_SCAN_DEFAULT_EIGYO_WORDS = [
  "営業", "ご提案", "営業メール", "営業電話", "売り込み", "売りこみ", "うりこみ",
  "ご提案に関するメール", "営業を目的としたお問い合わせ", "お問い合わせフォームからのセールス",
  "セールス", "勧誘", "営業の電話", "サービス提案", "業者", "お客様以外のご利用",
  "広告の問い合わせ", "広告", "広告宣伝メール", "への営業は", "営業目的",
  "営利目的", "営利", "商用利用", "商用", "営業行為", "営業のご案内",
  "営業のご連絡", "営業関連", "営業活動", "宣伝", "宣伝行為",
  "不適切な宣伝行為", "フォームの利用", "フォーム",
];
const SITE_SCAN_DEFAULT_KOTOWARI_WORDS = [
  "ご対応は致しかねます", "ご対応はいたしかねます", "ご遠慮いただいております",
  "お断り", "おことわり", "お断りさせて", "遠慮", "ご遠慮", "ご遠慮下さい",
  "ご遠慮ください", "ご遠慮いただきますよう", "固くお断り", "固くおことわり",
  "返信いたしかねます", "お断りします", "返信致しかねます", "返信いたしません",
  "返信しておりません", "返信を行わない", "返信をしない", "固くお断りいたします",
  "お控え", "お控えください", "お控え下さい", "拒否致します",
];
const SITE_SCAN_DEFAULT_INSTANT_WORDS = [
  "営業・ご提案のご連絡は、会社概要のメールよりお願いいたします",
  "業者等のご連絡はお断りさせていただきます", "業者等のご連絡はお断り",
  "営業権のご購入", "営業権", "への営業は専用窓口をご利用ください",
  "誠に恐れ入りますが、企業様からのお問い合わせは、こちらのフォームの利用はご遠慮ください",
  "営業お断り", "営業禁止",
  "このお問い合わせフォームでの特定電子メールの送信を拒否致します",
  "法第３条第１項[特定電子メールの送信の制限]に抵触しているのが確認された場合",
  "一般財団法人日本データ通信協会に迷惑メールとして情報提供しております。",
  "法第３条第１項", "特定電子メール法", "電子メール法", "メール法",
  "特定電子メール", "特定電子", "特定電子メールの送信の制限",
  "電子メール広告", "広告宣伝メール", "メールの送信の制限", "送信の制限",
];

// 警告ダイアログ（content.js の checkCombinationAlert）と同じ判定基準：
// ①一発アウトワードが1つでもある、または②「営業」系と「禁止・お断り」系の
// 両方がそろっている場合のみ、そのページを「検出あり」として扱う。
// 単語が1つ該当しただけ（例：「営業時間」の「営業」のみ）では扱わない。
function siteScanIsAlertWorthy(matchedWords, eigyoWords, kotowariWords, instantWords) {
  if (matchedWords.some((w) => instantWords.includes(w))) return true;
  const hasEigyo = matchedWords.some((w) => w.includes("営業") || eigyoWords.includes(w));
  const hasKotowari = matchedWords.some(
    (w) =>
      w.includes("お断り") ||
      w.includes("おことわり") ||
      w.includes("禁止") ||
      w.includes("ご遠慮") ||
      kotowariWords.includes(w)
  );
  return hasEigyo && hasKotowari;
}

function siteScanEscapeRegex(w) {
  return w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

const siteScanNfkc = (s) => String(s).normalize("NFKC");

function siteScanBuildRegex(wordList) {
  const uniq0 = [...new Set(wordList.map((w) => siteScanNfkc(w).trim()).filter(Boolean))];
  if (uniq0.length === 0) return null;
  // 先に書いた語が優先されるため、長い語を先に並べる（content.js と同じ。同じ長さは登録順を維持）
  const uniq = uniq0
    .map((w, i) => ({ w, i }))
    .sort((a, b) => b.w.length - a.w.length || a.i - b.i)
    .map((x) => x.w);
  const pattern = uniq.map((w) => `(${siteScanEscapeRegex(w)})`).join("|");
  return { regex: new RegExp(pattern, "gi"), words: uniq };
}

function siteScanComputeExcludedRanges(text, excludedPhrases) {
  const ranges = [];
  for (const raw of excludedPhrases) {
    const phrase = siteScanNfkc(raw);
    if (!phrase) continue;
    let idx = text.indexOf(phrase);
    while (idx !== -1) {
      ranges.push([idx, idx + phrase.length]);
      idx = text.indexOf(phrase, idx + 1);
    }
  }
  return ranges;
}

function siteScanIsRangeExcluded(start, end, excludedRanges) {
  return excludedRanges.some(([exStart, exEnd]) => start >= exStart && end <= exEnd);
}

function siteScanExtractMatchedWords(rawText, compiled, excludedPhrases) {
  if (!compiled || !compiled.regex || !rawText) return [];
  const text = siteScanNfkc(rawText);
  compiled.regex.lastIndex = 0;
  const found = new Set();
  const excludedRanges = siteScanComputeExcludedRanges(text, excludedPhrases || SITE_SCAN_EXCLUDED_PHRASES);
  let m;
  while ((m = compiled.regex.exec(text)) !== null) {
    const groupIdx = m.slice(1).findIndex((g) => g !== undefined);
    if (groupIdx !== -1 && !siteScanIsRangeExcluded(m.index, m.index + m[0].length, excludedRanges)) {
      found.add(compiled.words[groupIdx]);
    }
    if (m[0].length === 0) compiled.regex.lastIndex++;
  }
  return [...found];
}

function siteScanHtmlToText(html) {
  let s = html;
  s = s.replace(/<script[\s\S]*?<\/script>/gi, " ");
  s = s.replace(/<style[\s\S]*?<\/style>/gi, " ");
  s = s.replace(/<!--[\s\S]*?-->/g, " ");
  s = s.replace(/<[^>]+>/g, " ");
  s = s
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'");
  s = s.replace(/&#(\d+);/g, (_, n) => {
    try { return String.fromCodePoint(parseInt(n, 10)); } catch { return ""; }
  });
  return s.replace(/\s+/g, " ").trim();
}

function siteScanExtractTitle(html) {
  const m = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html);
  return m ? siteScanHtmlToText(m[1]).slice(0, 100) : "";
}

function siteScanExtractLinks(html, baseUrl, hostname) {
  const links = [];
  const re = /<a\s+[^>]*href\s*=\s*["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html)) !== null) {
    const hrefRaw = m[1];
    const text = siteScanHtmlToText(m[2]).toLowerCase();
    let url;
    try {
      url = new URL(hrefRaw, baseUrl).toString();
    } catch {
      continue;
    }
    let u;
    try {
      u = new URL(url);
    } catch {
      continue;
    }
    if (u.hostname !== hostname) continue;
    if (!/^https?:$/.test(u.protocol)) continue;
    if (/\.(pdf|jpg|jpeg|png|gif|svg|zip|docx?|xlsx?|css|js)$/i.test(u.pathname)) continue;
    u.hash = "";
    const cleanUrl = u.toString();

    const pathLower = u.pathname.toLowerCase();
    let score = 0;
    for (const hint of SITE_SCAN_LINK_HINTS) {
      const h = hint.toLowerCase();
      if (text.includes(h)) score += 2;
      if (pathLower.includes(h)) score += 1;
    }
    links.push({ url: cleanUrl, score });
  }

  const byUrl = new Map();
  for (const l of links) {
    const existing = byUrl.get(l.url);
    if (!existing || l.score > existing.score) byUrl.set(l.url, l);
  }
  return [...byUrl.values()].sort((a, b) => b.score - a.score).map((l) => l.url);
}

function siteScanSleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function siteScanFetchPage(url) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), SITE_SCAN_FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, { signal: controller.signal, credentials: "omit", redirect: "follow" });
    clearTimeout(timeoutId);
    if (!res.ok) return null;
    const contentType = res.headers.get("content-type") || "";
    if (contentType && !contentType.includes("text/html") && !contentType.includes("text/plain")) return null;
    const html = await res.text();
    return { html, finalUrl: res.url || url };
  } catch (_e) {
    clearTimeout(timeoutId);
    return null;
  }
}

// ===== 先読みスキャンの画像OCR（ver9.14で追加／ver10で初期オンに変更。設定「siteScanOcr」） =====
// 重くしないための上限（すべてここで調整）
const SITE_OCR_MAX_IMAGES_PER_PAGE = 3;            // 1ページあたりの最大枚数
const SITE_OCR_MAX_IMAGES_PER_SITE = 10;           // 1サイトあたりの最大枚数
const SITE_OCR_TOTAL_TIME_MS = 60 * 1000;          // 1サイトの先読み全体（開始から）の時間の上限。超えたらそこまでの結果で終える
const SITE_OCR_MAX_BYTES = 2 * 1024 * 1024;        // 画像1枚の大きさの上限（超えたら対象外）
const SITE_OCR_MIN_WIDTH = 100;                    // これより小さい画像（アイコン等）は対象外
const SITE_OCR_MIN_HEIGHT = 30;
const SITE_OCR_PER_IMAGE_TIMEOUT_MS = 25 * 1000;   // 1枚の読み取りを待つ最長時間
const SITE_OCR_MAX_ENGINE_ERRORS = 3;              // 読み取りエンジンのエラーがこの回数続いたら打ち切る
const SITE_OCR_IMAGE_PREFIX = "【画像内】";         // content.js の stripImagePrefix と同じ表記
// OCRするページの語（会社概要・規約・ポリシー・お問い合わせ系）。ページのURLのパスまたはタイトルに含まれる場合だけ対象
const SITE_OCR_PAGE_HINTS = [
  "会社概要", "会社案内", "企業情報", "about", "company", "profile",
  "プライバシー", "個人情報", "privacy", "policy",
  "特定商取引", "特商法", "tokushoho",
  "利用規約", "規約", "terms", "kiyaku",
  "お問い合わせ", "お問合せ", "問い合わせ", "問合せ", "contact", "inquiry", "toiawase",
  "サイトマップ", "sitemap", "site-map",
];

function siteScanOcrEnabled() {
  return new Promise((resolve) => {
    try {
      getFeatureSettings((st) => resolve(isFeatureActive(st, "siteScanOcr")));
    } catch (_e) {
      resolve(false);
    }
  });
}

function isSiteOcrPriorityPage(url, title) {
  let path = "";
  try { path = decodeURIComponent(new URL(url).pathname).toLowerCase(); } catch (_e) { path = String(url).toLowerCase(); }
  const t = String(title || "").toLowerCase();
  return SITE_OCR_PAGE_HINTS.some((h) => { const k = h.toLowerCase(); return path.includes(k) || t.includes(k); });
}

// ページのHTMLから、OCR候補の画像URLを取り出す（img の data-src／src／srcset の最初の候補。相対URLは絶対URLにする）
function siteScanExtractImageUrls(html, baseUrl) {
  const out = [];
  const seen = new Set();
  const tagRe = /<img\b[^>]*>/gi;
  const attr = (tag, name) => {
    const m = new RegExp("[\\s\"']" + name + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))", "i").exec(tag);
    return m ? (m[1] ?? m[2] ?? m[3] ?? "").trim() : "";
  };
  let m;
  while ((m = tagRe.exec(html)) !== null && out.length < 60) {
    const tag = m[0];
    const w = parseInt(attr(tag, "width"), 10);
    const h = parseInt(attr(tag, "height"), 10);
    if ((Number.isFinite(w) && w > 0 && w < 60) || (Number.isFinite(h) && h > 0 && h < 20)) continue; // 小さな画像（アイコン等）
    const srcset = attr(tag, "srcset").split(",")[0].trim().split(/\s+/)[0];
    const candidates = [attr(tag, "data-src"), attr(tag, "data-lazy-src"), attr(tag, "data-original"), attr(tag, "src"), srcset];
    for (const c of candidates) {
      if (!c || /^data:/i.test(c)) continue;
      let u;
      try { u = new URL(c.replace(/&amp;/g, "&"), baseUrl); } catch (_e) { continue; }
      if (!/^https?:$/.test(u.protocol)) continue;
      if (/\.(svg|gif|ico)$/i.test(u.pathname)) continue;
      if (/(favicon|sprite|spacer|pixel|blank|1x1|tracking|loading)/i.test(u.pathname)) continue;
      u.hash = "";
      const href = u.toString();
      if (!seen.has(href)) { seen.add(href); out.push(href); }
      break;
    }
  }
  return out;
}

// 一時停止中／このサイトはオフ か（content.js の isHalted と同じ判定。OCRの途中で止めるために使う）
function siteScanIsHalted(domain) {
  return new Promise((resolve) => {
    chrome.storage.local.get({ pausedUntil: 0, disabledSites: [] }, (d) => {
      const key = String(domain || "").toLowerCase().replace(/^www\./, "");
      const paused = Number(d.pausedUntil) > Date.now();
      const off = Array.isArray(d.disabledSites) && !!key && d.disabledSites.includes(key);
      resolve(paused || off);
    });
  });
}

function siteScanOcrOneImage(imageUrl, waitMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve({ success: false, error: "timeout" }), Math.max(1000, waitMs));
    try {
      chrome.runtime.sendMessage(
        {
          target: "offscreen",
          type: "ocrSiteImage",
          imageUrl,
          maxBytes: SITE_OCR_MAX_BYTES,
          minWidth: SITE_OCR_MIN_WIDTH,
          minHeight: SITE_OCR_MIN_HEIGHT,
        },
        (resp) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
          else resolve(resp || { success: false, error: "no response" });
        }
      );
    } catch (e) {
      clearTimeout(timer);
      resolve({ success: false, error: String(e) });
    }
  });
}

// 画像を1枚ずつ順番に読む（並列にしない）。戻り値：{ ocrWords: Map(ページのindex → Set(語)), complete }
//   complete が false = エンジンの不調で打ち切った（この時はキャッシュに「OCR済み」と記録しない）
async function siteScanRunOcr(ocrPages, compiled, excludedPhrases, deadline, domain) {
  const ocrWords = new Map();
  let used = 0;
  let engineErrors = 0;
  let complete = true;
  try {
    await ensureOffscreenDocument();
  } catch (_e) {
    return { ocrWords, complete: false };
  }
  outer:
  for (let pi = 0; pi < ocrPages.length; pi++) {
    for (const imgUrl of ocrPages[pi].imgs) {
      if (used >= SITE_OCR_MAX_IMAGES_PER_SITE) break outer;
      const remain = deadline - Date.now();
      if (remain <= 0) break outer;                         // 時間切れ：そこまでの結果で終える
      if (await siteScanIsHalted(domain)) { complete = false; break outer; } // 一時停止／サイトオフ：OCRも止める（途中の結果なので「OCR済み」と記録しない）
      used++;
      const resp = await siteScanOcrOneImage(imgUrl, Math.min(remain, SITE_OCR_PER_IMAGE_TIMEOUT_MS));
      if (!resp.success) {
        if (++engineErrors >= SITE_OCR_MAX_ENGINE_ERRORS) { complete = false; break outer; }
        continue;
      }
      engineErrors = 0;
      if (resp.skipped || !resp.text) continue;
      const words = siteScanExtractMatchedWords(resp.text, compiled, excludedPhrases);
      if (words.length) {
        const set = ocrWords.get(pi) || new Set();
        words.forEach((w) => set.add(w));
        ocrWords.set(pi, set);
      }
    }
  }
  return { ocrWords, complete };
}

function siteScanStorageKey(domain) {
  return `${SITE_SCAN_STORAGE_PREFIX}${domain}`;
}

function saveSiteScanState(domain, state) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [siteScanStorageKey(domain)]: state }, resolve);
  });
}

function loadSiteScanState(domain) {
  return new Promise((resolve) => {
    chrome.storage.local.get({ [siteScanStorageKey(domain)]: null }, (data) => {
      resolve(data[siteScanStorageKey(domain)]);
    });
  });
}

async function performSiteWideScan(originUrl) {
  try {
    const originObj = new URL(originUrl);
    const domain = originObj.hostname;
    const base = `${originObj.protocol}//${originObj.host}`;
    const topUrl = `${base}/`;

    const scanStartedAt = Date.now();
    const ocrOn = await siteScanOcrEnabled(); // ver9.14：先読みの画像OCR（ver10から初期オン）
    const cached = await loadSiteScanState(domain);
    // OCRがオフの間にできたキャッシュは、OCRをオンにした後は使わずにやり直す（OCR済みのキャッシュは、オフの時にも使ってよい）
    if (cached && cached.scannedAt && (Date.now() - cached.scannedAt < SITE_SCAN_TTL_MS) && (!ocrOn || cached.ocr === true)) {
      return { success: true, totalScanned: cached.completedPages || 0, hits: cached.matches || [] };
    }

    const compiled = await new Promise((resolve) => {
      chrome.storage.local.get(
        { storedKeywords: [], userKeywords: [], syncedCategoryWords: { eigyo: [], kotowari: [], instant: [] } },
        (data) => {
          const activeUserWords = (data.userKeywords || [])
            .filter((u) => u.enabled !== false)
            .map((u) => u.word);
          const catWords = data.syncedCategoryWords || {};
          const allWords = [
            ...SITE_SCAN_DEFAULT_KEYWORDS,
            ...(data.storedKeywords || []),
            ...activeUserWords,
            ...(catWords.eigyo || []),
            ...(catWords.kotowari || []),
            ...(catWords.instant || []),
          ];
          resolve({
            compiled: siteScanBuildRegex(allWords),
            // 検出語は NFKC 正規化後の表記で返るため、比較に使う分類ワード側も正規化しておく
            eigyoWords: [...new Set([...SITE_SCAN_DEFAULT_EIGYO_WORDS, ...(catWords.eigyo || [])].map(siteScanNfkc))],
            kotowariWords: [...new Set([...SITE_SCAN_DEFAULT_KOTOWARI_WORDS, ...(catWords.kotowari || [])].map(siteScanNfkc))],
            instantWords: [...new Set([...SITE_SCAN_DEFAULT_INSTANT_WORDS, ...(catWords.instant || [])].map(siteScanNfkc))],
          });
        }
      );
    });
    const { compiled: regexCompiled, eigyoWords, kotowariWords, instantWords } = compiled;

    const excludedPhrases = await new Promise((resolve) => {
      chrome.storage.local.get({ syncedExcludedPhrases: [] }, (data) => {
        resolve([...new Set([...SITE_SCAN_EXCLUDED_PHRASES, ...(data.syncedExcludedPhrases || [])])]);
      });
    });

    const visited = new Set();
    const queue = [topUrl];
    const matches = [];
    let linksExpanded = false;
    const ocrPages = []; // ver9.14：OCRする画像を持つページ { url, title, textWords, imgs }
    const ocrSeenImages = new Set();
    let ocrCandidateCount = 0;

    while (queue.length > 0 && visited.size < SITE_SCAN_MAX_PAGES) {
      const batch = [];
      while (batch.length < SITE_SCAN_CONCURRENCY && queue.length > 0 && visited.size + batch.length < SITE_SCAN_MAX_PAGES) {
        const next = queue.shift();
        if (!visited.has(next) && !batch.includes(next)) batch.push(next);
      }
      if (batch.length === 0) break;

      const settled = await Promise.allSettled(batch.map((u) => siteScanFetchPage(u)));

      for (let i = 0; i < batch.length; i++) {
        const url = batch[i];
        visited.add(url);
        const result = settled[i].status === "fulfilled" ? settled[i].value : null;

        if (result && result.html) {
          const text = siteScanHtmlToText(result.html);
          const matchedWords = siteScanExtractMatchedWords(text, regexCompiled, excludedPhrases);
          if (matchedWords.length > 0 && siteScanIsAlertWorthy(matchedWords, eigyoWords, kotowariWords, instantWords)) {
            matches.push({
              url: result.finalUrl || url,
              title: siteScanExtractTitle(result.html) || url,
              words: matchedWords,
            });
          }
          if (ocrOn && url !== topUrl && ocrCandidateCount < SITE_OCR_MAX_IMAGES_PER_SITE) {
            const pageUrl = result.finalUrl || url;
            const pageTitle = siteScanExtractTitle(result.html) || url;
            if (isSiteOcrPriorityPage(pageUrl, pageTitle)) {
              const imgs = siteScanExtractImageUrls(result.html, pageUrl)
                .filter((u) => !ocrSeenImages.has(u))
                .slice(0, SITE_OCR_MAX_IMAGES_PER_PAGE);
              imgs.forEach((u) => ocrSeenImages.add(u));
              if (imgs.length) {
                ocrPages.push({ url: pageUrl, title: pageTitle, textWords: matchedWords, imgs });
                ocrCandidateCount += imgs.length;
              }
            }
          }
          if (url === topUrl && !linksExpanded) {
            linksExpanded = true;
            const links = siteScanExtractLinks(result.html, url, domain);
            for (const l of links) {
              if (!visited.has(l) && !queue.includes(l)) queue.push(l);
              if (visited.size + queue.length >= SITE_SCAN_MAX_PAGES) break;
            }
          }
        }
      }

      if (queue.length > 0) await siteScanSleep(SITE_SCAN_REQUEST_DELAY_MS);
    }

    // ver9.14：集めた画像を、1枚ずつ順番にOCR（時間・枚数の上限つき）。見つかった語は「【画像内】」を付けて結果に加える
    let ocrComplete = true;
    if (ocrOn && ocrPages.length > 0) {
      const compiledForOcr = regexCompiled;
      const ocrRes = await siteScanRunOcr(ocrPages, compiledForOcr, excludedPhrases, scanStartedAt + SITE_OCR_TOTAL_TIME_MS, domain);
      ocrComplete = ocrRes.complete;
      for (const [pi, wordSet] of ocrRes.ocrWords) {
        const page = ocrPages[pi];
        const ocrBare = [...wordSet];
        const existing = matches.find((m) => m.url === page.url);
        if (existing) {
          // 既に文字で検出済みのページ：画像の語だけで警告に値する場合に、画像の語を加える
          if (siteScanIsAlertWorthy(ocrBare, eigyoWords, kotowariWords, instantWords)) {
            for (const w of ocrBare) {
              const tagged = SITE_OCR_IMAGE_PREFIX + w;
              if (!existing.words.includes(tagged)) existing.words.push(tagged);
            }
          }
        } else if (siteScanIsAlertWorthy([...new Set([...page.textWords, ...ocrBare])], eigyoWords, kotowariWords, instantWords)) {
          // 文字だけでは足りないが、画像の語と合わせると判定ルールを満たすページ
          matches.push({
            url: page.url,
            title: page.title,
            words: [...page.textWords, ...ocrBare.map((w) => SITE_OCR_IMAGE_PREFIX + w)],
          });
        }
      }
    }

    const state = {
      domain,
      status: "done",
      scannedAt: Date.now(),
      completedPages: visited.size,
      matches,
      ocr: ocrOn && ocrComplete, // OCRをした結果か（オフの間のキャッシュと区別する）
    };
    await saveSiteScanState(domain, state);
    return { success: true, totalScanned: visited.size, hits: matches };
  } catch (err) {
    console.error("Site wide scan error:", err);
    return { success: false, error: String(err) };
  }
}

// ===== 一括スキャン（URLモード）が開いたタブの管理 =====
// 一括スキャン画面が開いたタブでは、content.js の通常動作（検出・表示・OCR・先読み）を止める。
const bulkTabs = new Set();
let bulkTabsLoaded = null;
const loadBulkTabs = () => {
  if (!bulkTabsLoaded) {
    bulkTabsLoaded = chrome.storage.session.get({ bulkTabIds: [] })
      .then((d) => { (d.bulkTabIds || []).forEach((id) => bulkTabs.add(id)); })
      .catch(() => {});
  }
  return bulkTabsLoaded;
};
const saveBulkTabs = () => chrome.storage.session.set({ bulkTabIds: [...bulkTabs] }).catch(() => {});
chrome.tabs.onRemoved.addListener((tabId) => {
  loadBulkTabs().then(() => { if (bulkTabs.delete(tabId)) saveBulkTabs(); });
});

// ===== メッセージハンドラー =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  // content.js から：一時停止の期限が来た／再開された → バッジを付け直す
  if (msg.type === "refreshBadge") {
    updatePauseBadge();
    return;
  }

  // feedback.js から：送信先（共通API）が設定済みか
  if (msg.type === "sharedApiStatus") {
    sendResponse({ configured: isSharedApiConfigured() });
    return;
  }
  // feedback.js から：フィードバックの送信
  if (msg.type === "submitFeedback") {
    postFeedback(msg.payload).then(sendResponse, (e) => sendResponse({ ok: false, error: String(e) }));
    return true;
  }
  // ポップアップから：いま見せるお知らせ（最大3件）
  if (msg.type === "getNotices") {
    chrome.storage.local.get({ updateInfo: null, featureSettings: null, noticeSnooze: null, noticeIgnored: [] }, (d) => {
      sendResponse({ notices: pickNotices(d).slice(0, 3) });
    });
    return true;
  }
  // content.js から：ページ上のカード。1日1回（その日、最初に開いたページで）だけ一覧を返し、返した時点で「今日は出した」と記録する
  if (msg.type === "getPageNotices") {
    chrome.storage.local.get({ updateInfo: null, featureSettings: null, noticeSnooze: null, noticeIgnored: [], noticeShownDay: "" }, (d) => {
      const today = todayKey();
      const list = d.noticeShownDay === today ? [] : pickNotices(d);
      if (!list.length) { sendResponse({ notices: [] }); return; }
      chrome.storage.local.set({ noticeShownDay: today }, () => sendResponse({ notices: list.slice(0, 10) }));
    });
    return true;
  }
  // ポップアップ／ページ上のカードから：［あとで］（そのカードを24時間見えなくする）／［この件は無視］（そのIDを二度と出さない）
  if (msg.type === "noticeAction") {
    (async () => {
      const id = String(msg.id || "").slice(0, 60);
      if (!id) { sendResponse({ ok: false }); return; }
      const d = await chrome.storage.local.get({ noticeSnooze: null, noticeIgnored: [] });
      if (msg.action === "later") {
        const snooze = d.noticeSnooze && typeof d.noticeSnooze === "object" ? d.noticeSnooze : {};
        snooze[id] = Date.now() + UPDATE_SNOOZE_MS;
        await chrome.storage.local.set({ noticeSnooze: snooze });
      } else if (msg.action === "ignore") {
        const ig = Array.isArray(d.noticeIgnored) ? d.noticeIgnored : [];
        if (!ig.includes(id)) ig.push(id);
        await chrome.storage.local.set({ noticeIgnored: ig.slice(-200) });
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  // ポップアップから：単語の同期を今すぐ実行（キーワード・除外フレーズ・警告ダイアログ用ワード）
  if (msg.type === "syncNow") {
    (async () => {
      try {
        await Promise.all([fetchKeywords(), fetchExcludedPhrases(), fetchCategoryWords()]);
        await new Promise((r) => setTimeout(r, 200)); // 保存の完了を待つ
        const d = await chrome.storage.local.get({ lastSyncAt: null, lastSyncError: null, storedKeywords: [] });
        sendResponse({ ok: !d.lastSyncError, lastSyncAt: d.lastSyncAt, error: d.lastSyncError, keywords: (d.storedKeywords || []).length });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    return true;
  }

  // content.js から：このタブは一括スキャンのタブか？
  if (msg.type === "isBulkTab") {
    loadBulkTabs().then(() => sendResponse({ bulk: !!(sender.tab && bulkTabs.has(sender.tab.id)) }));
    return true;
  }
  // 一括スキャン画面から：タブの登録・解除
  if (msg.type === "bulkTabs") {
    loadBulkTabs().then(() => {
      (msg.add || []).forEach((id) => bulkTabs.add(id));
      (msg.remove || []).forEach((id) => bulkTabs.delete(id));
      saveBulkTabs();
      sendResponse({ ok: true });
    });
    return true;
  }

  // OCRエンジンの事前準備（ページを開いた直後に呼ばれ、画像を読む頃には準備が済んでいるようにする）
  if (msg.type === "warmupOcr") {
    (async () => {
      try {
        await ensureOffscreenDocument();
        chrome.runtime.sendMessage({ target: 'offscreen', type: 'warmup' }, () => {
          void chrome.runtime.lastError;
          sendResponse({ success: true });
        });
      } catch (err) {
        sendResponse({ success: false, error: String(err) });
      }
    })();
    return true;
  }

  // OCRリクエストの処理
  if (msg.type === "requestImageOcr") {
    (async () => {
      try {
        await ensureOffscreenDocument();
        let imageData = msg.imageData;
        if (!imageData && msg.imageUrl) {
          imageData = await fetchImageAsDataUrl(msg.imageUrl);
        }

        chrome.runtime.sendMessage(
          {
            target: 'offscreen',
            type: 'performOcr',
            imageData,
            imageUrl: msg.imageUrl,
            stage: msg.stage,
          },
          (response) => {
            if (chrome.runtime.lastError) {
              sendResponse({ success: false, error: chrome.runtime.lastError.message });
            } else {
              sendResponse(response || { success: false, error: 'No response from OCR worker' });
            }
          }
        );
      } catch (err) {
        console.error('[営業禁止ワード検出/OCR] Error handling OCR request:', err);
        sendResponse({ success: false, error: String(err) });
      }
    })();
    return true; // 非同期レスポンス
  }

  // サイト全体スキャンリクエスト
  if (msg.type === "startSiteWideScan") {
    (async () => {
      const res = await performSiteWideScan(msg.url);
      sendResponse(res);
    })();
    return true; // 非同期レスポンス
  }
});

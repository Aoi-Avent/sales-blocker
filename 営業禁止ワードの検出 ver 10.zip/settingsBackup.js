// settingsBackup.js — ver 10
// 設定の「書き出し／読み込み」と「Chrome同期への自動バックアップ／復元」の共通処理。
// background.js（importScripts）と options.html（<script>）の両方から読み込む。
//
// 保存の考え方：
//  - 正本は chrome.storage.local。Chrome同期（chrome.storage.sync）は「バックアップ」として使う。
//  - 同期へは、容量の小さい設定だけを入れる（1項目8KB・全体100KBの上限があるため）。
//  - 復元は「ローカルにその項目が無い時だけ」行う（入れ直した直後など）。普段はローカルを上書きしない。
//  - シートから取得し直せるもの（登録キーワード・除外フレーズ・カテゴリー別ワード）や、
//    作り直せるもの（検出ログ・先読みのキャッシュ・一時停止・同期のエラー表示）は対象外。

// ファイルに書き出す／読み込む項目（ユーザーが決めた設定）
const BACKUP_FILE_KEYS = [
  "featureSettings",   // 全体ON/OFF・機能ごとのON/OFF
  "disabledSites",     // 「このサイトで検出をオフ」にしたドメイン
  "userKeywords",      // ユーザー追加キーワード（独自）
  "panelTransparency", // 常時表示パネルの透明度
  "panelPosition",     // 常時表示パネルの位置
  "bulkSettings",      // 一括スキャンの設定
  "syncIntervalMinutes", // 単語の自動同期の間隔（分）
];
// Chrome同期へ自動バックアップする項目（画面サイズに依存する位置・大きくなり得る一括スキャン設定は除く）
const BACKUP_SYNC_KEYS = ["featureSettings", "disabledSites", "userKeywords", "panelTransparency", "syncIntervalMinutes"];
const BACKUP_META_KEY = "settingsSyncMeta"; // { lastPushAt, skipped:[], error, lastRestoreAt, restored:[] }（ローカルのみ）
const BACKUP_FORMAT = "salesban-settings";
const BACKUP_SYNC_ITEM_LIMIT = 7800; // 同期の1項目の上限は8192バイト（キー名を含む）。余裕を見る

// 取り込む値の形を確かめて、使える形に整える（壊れたファイルで設定を壊さないため）
function sanitizeBackupValue(key, v) {
  switch (key) {
    case "featureSettings": {
      if (!v || typeof v !== "object" || Array.isArray(v)) return undefined;
      const features = {};
      if (v.features && typeof v.features === "object") {
        for (const [k, val] of Object.entries(v.features)) if (typeof val === "boolean") features[k] = val;
      }
      return { master: typeof v.master === "boolean" ? v.master : true, features };
    }
    case "disabledSites":
      return Array.isArray(v) ? [...new Set(v.filter((x) => typeof x === "string" && x.trim()).map((x) => x.trim().toLowerCase().replace(/^www\./, "")))] : undefined;
    case "userKeywords":
      return Array.isArray(v)
        ? v.filter((x) => x && typeof x.word === "string" && x.word.trim()).map((x) => ({ word: x.word.trim(), enabled: x.enabled !== false }))
        : undefined;
    case "panelTransparency": {
      const n = Number(v);
      return Number.isFinite(n) ? Math.min(80, Math.max(0, Math.round(n / 5) * 5)) : undefined;
    }
    case "syncIntervalMinutes": {
      const n = Number(v);
      return Number.isFinite(n) ? Math.min(1440, Math.max(15, Math.round(n))) : undefined; // 使うときに、選べる間隔へ丸める
    }
    case "panelPosition":
      return v && Number.isFinite(Number(v.left)) && Number.isFinite(Number(v.top)) ? { left: Number(v.left), top: Number(v.top) } : undefined;
    case "bulkSettings":
      return v && typeof v === "object" && !Array.isArray(v) ? v : undefined;
    default:
      return undefined;
  }
}

// ---- ファイルの書き出し／読み込み ----
async function buildBackupFile() {
  const local = await chrome.storage.local.get(BACKUP_FILE_KEYS);
  const data = {};
  for (const k of BACKUP_FILE_KEYS) {
    if (local[k] === undefined) continue;
    const clean = sanitizeBackupValue(k, local[k]);
    if (clean !== undefined) data[k] = clean;
  }
  return {
    format: BACKUP_FORMAT,
    appVersion: chrome.runtime.getManifest().version,
    exportedAt: new Date().toISOString(),
    data,
  };
}

// ファイルの中身を検査して、取り込める項目だけを返す。{ ok, data, error }
function parseBackupFile(text) {
  let obj;
  try { obj = JSON.parse(text); } catch (_e) { return { ok: false, error: "ファイルの形式が正しくありません（JSONとして読めません）。" }; }
  if (!obj || obj.format !== BACKUP_FORMAT || !obj.data || typeof obj.data !== "object") {
    return { ok: false, error: "この拡張機能の設定ファイルではありません。" };
  }
  const data = {};
  for (const k of BACKUP_FILE_KEYS) {
    if (obj.data[k] === undefined) continue;
    const clean = sanitizeBackupValue(k, obj.data[k]);
    if (clean !== undefined) data[k] = clean;
  }
  if (!Object.keys(data).length) return { ok: false, error: "取り込める設定が見つかりませんでした。" };
  return { ok: true, data, appVersion: obj.appVersion || "", exportedAt: obj.exportedAt || "" };
}

async function applyBackupData(data) {
  await chrome.storage.local.set(data);
}

// ---- Chrome同期へのバックアップ／復元 ----
function backupSyncItemFits(key, value) {
  try {
    return new TextEncoder().encode(key + JSON.stringify(value)).length <= BACKUP_SYNC_ITEM_LIMIT;
  } catch (_e) { return false; }
}

async function patchBackupMeta(patch) {
  const cur = (await chrome.storage.local.get({ [BACKUP_META_KEY]: {} }))[BACKUP_META_KEY] || {};
  await chrome.storage.local.set({ [BACKUP_META_KEY]: { ...cur, ...patch } });
}

// ローカル → 同期（バックアップ）。入らない項目は skipped に記録して、設定画面に出す
async function pushLocalToSync() {
  try {
    const local = await chrome.storage.local.get(BACKUP_SYNC_KEYS);
    const put = {};
    const skipped = [];
    for (const k of BACKUP_SYNC_KEYS) {
      if (local[k] === undefined) continue;
      if (backupSyncItemFits(k, local[k])) put[k] = local[k]; else skipped.push(k);
    }
    if (Object.keys(put).length) await chrome.storage.sync.set(put);
    await patchBackupMeta({ lastPushAt: Date.now(), skipped, error: null });
    return { ok: true, skipped };
  } catch (e) {
    await patchBackupMeta({ error: String(e && e.message ? e.message : e) }).catch(() => {});
    return { ok: false, error: String(e) };
  }
}

// 同期 → ローカル（復元）。force=false：ローカルに無い項目だけ／force=true：同期にある項目で上書き
async function restoreFromSync(force) {
  try {
    const [local, remote] = await Promise.all([
      chrome.storage.local.get(BACKUP_SYNC_KEYS),
      chrome.storage.sync.get(BACKUP_SYNC_KEYS),
    ]);
    const set = {};
    for (const k of BACKUP_SYNC_KEYS) {
      if (remote[k] === undefined) continue;
      if (!force && local[k] !== undefined) continue;
      const clean = sanitizeBackupValue(k, remote[k]);
      if (clean !== undefined) set[k] = clean;
    }
    const restored = Object.keys(set);
    if (restored.length) {
      await chrome.storage.local.set(set);
      await patchBackupMeta({ lastRestoreAt: Date.now(), restored });
    }
    return { ok: true, restored };
  } catch (e) {
    return { ok: false, error: String(e && e.message ? e.message : e), restored: [] };
  }
}

if (typeof module !== "undefined") {
  module.exports = { BACKUP_FILE_KEYS, BACKUP_SYNC_KEYS, sanitizeBackupValue, parseBackupFile };
}

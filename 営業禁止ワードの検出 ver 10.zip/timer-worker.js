// timer-worker.js — タイマー専用のWorker
// 一括スキャン画面が裏のタブになると、ブラウザは画面内の setTimeout を大きく間引く（最大1分に1回など）。
// Workerの中のタイマーは間引かれないので、待ち時間の計測をここに任せる。
self.onmessage = (e) => {
  const { id, ms } = e.data || {};
  setTimeout(() => self.postMessage({ id }), Math.max(0, ms || 0));
};

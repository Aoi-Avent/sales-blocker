// bulk.js — 一括スキャン画面
//   ① フォルダ：保存したHTML・スクリーンショットのフォルダを、会社ごとにまとめて判定
//   ② URL一覧：拡張機能がChromeで自動でサイトを開き、表示された内容を判定（JavaScript描画・iframeにも対応）
// 判定ロジックは scanCore.js（拡張機能と同じルール）。単語は拡張機能が同期済みのものを使う。
(() => {
  "use strict";
  const C = window.SalesbanScanCore;
  const $ = (id) => document.getElementById(id);
  const PAGE_SIZE = 100;
  const CHUNK_OVERLAP = 120;           // 縦長のスクショを切り分けるときの重なり（px）
  const URL_IMAGE_MAX_BYTES = 12 * 1024 * 1024;
  const MAX_OCR_WIDTH = 3200;          // 拡大後の横幅の上限（メモリ対策）

  const state = {
    mode: "folder", urlMeta: null,
    groups: [], sites: [], ignored: 0,
    rows: [], cursor: 0, done: 0, total: 0,
    running: false, stopRequested: false,
    det: null, ocr: null, ocrN: 0,
    elapsedMs: 0, filter: "ALL", search: "", page: 0, openDetail: new Set(),
    active: new Map(),
    retryQueue: [], retrying: new Set(), retryRunning: false,
    stats: { ocrChunks: 0, ocrSkipped: 0, active: 0, maxActive: 0 },
  };
  window.__BULK_STATS__ = state.stats; // テスト・調整用

  // ---------- タイマー ----------
  // この画面が裏のタブになっても、待ち時間が間引かれないよう、Workerのタイマーを使う
  let timerWorker = null;
  const timerWaiters = new Map();
  let timerSeq = 0;
  try {
    timerWorker = new Worker("timer-worker.js");
    timerWorker.onmessage = (e) => { const r = timerWaiters.get(e.data && e.data.id); if (r) { timerWaiters.delete(e.data.id); r(); } };
  } catch (_e) { timerWorker = null; }
  const sleep = (ms) => (timerWorker
    ? new Promise((r) => { const id = ++timerSeq; timerWaiters.set(id, r); timerWorker.postMessage({ id, ms }); })
    : new Promise((r) => setTimeout(r, ms)));
  // 画面の更新に処理を譲る（setTimeoutと違い、裏のタブでも間引かれない）
  const yieldUI = () => new Promise((r) => { const ch = new MessageChannel(); ch.port1.onmessage = () => { ch.port1.close(); r(); }; ch.port2.postMessage(0); });

  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmtTime = (ms) => {
    const s = Math.max(0, Math.round(ms / 1000));
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
    return h ? `${h}時間${m}分` : m ? `${m}分${String(ss).padStart(2, "0")}秒` : `${ss}秒`;
  };
  const badgeClass = (label) => (label.startsWith("アウト") ? "out" : label.startsWith("警告") ? "warn" : label.startsWith("検出のみ") ? "info" : label === "検出なし" ? "none" : "fail");
  const shortLabel = (label) => label.replace(/（.*）/, "");
  const shortUrl = (u) => { try { const x = new URL(u); return x.host + (x.pathname === "/" ? "" : x.pathname) + x.search; } catch (_e) { return u; } };

  function showError(msg) {
    const box = $("errorBox");
    box.textContent = msg;
    box.hidden = !msg;
  }

  // ---------- 判定に使う単語の読み込み（拡張機能の中身と同期済みのシートの単語） ----------
  async function loadDetector() {
    const res = await fetch(chrome.runtime.getURL("content.js"));
    const def = C.parseExtensionDefaults(await res.text());
    const data = await chrome.storage.local.get({
      storedKeywords: [], userKeywords: [], syncedExcludedPhrases: [],
      syncedCategoryWords: { eigyo: [], kotowari: [], instant: [] }, lastSyncAt: null,
    });
    const cat = data.syncedCategoryWords || {};
    const userWords = (data.userKeywords || []).filter((u) => u.enabled !== false).map((u) => u.word);
    const det = new C.Detector({
      keywords: [...def.keywords, ...(data.storedKeywords || []), ...userWords],
      eigyo: [...def.eigyo, ...(cat.eigyo || [])],
      kotowari: [...def.kotowari, ...(cat.kotowari || [])],
      instant: [...def.instant, ...(cat.instant || [])],
      excluded: [...def.excluded, ...(data.syncedExcludedPhrases || [])],
    });
    return { det, lastSyncAt: data.lastSyncAt, synced: (data.storedKeywords || []).length > 0 };
  }

  function showWordInfo(info) {
    const el = $("wordInfo");
    const when = info.lastSyncAt ? new Date(info.lastSyncAt).toLocaleString("ja-JP") : null;
    if (!info.synced) {
      el.className = "info warn";
      el.textContent = "⚠ 管理スプレッドシートの単語がまだ取り込まれていません。内蔵の単語だけで判定します。拡張機能の設定画面で同期してから、この画面を開き直すことをおすすめします。";
    } else {
      el.className = "info";
      el.textContent = `使用する単語：${info.det.words.length}語 / 除外フレーズ ${info.det.excluded.length}件（管理スプレッドシートの最終取り込み：${when}）`;
    }
  }

  // ---------- 処理の強さ（プリセット）と詳細設定 ----------
  const HW = { threads: navigator.hardwareConcurrency || 4, mem: navigator.deviceMemory || null };
  const PRESET_LABEL = { max: "全速力", standard: "標準", relaxed: "まったり", custom: "カスタム" };
  const SCALE_LABEL = { 1: "等倍で1回", 2: "2倍に拡大して1回", 3: "等倍と2倍の2回読み" };
  const CFG_KEYS = ["ocrWorkers", "folderConc", "urlWorkers", "itemDelay", "pageDelay", "paintMs", "ocrScale", "chunkHeight", "maxChunks", "urlImages", "pages", "settleMs", "timeoutSec"];
  function presetValues(name) {
    switch (name) {
      case "max": // 高性能PC（例：Core i5-10400）で、PCをフルに使う。精度は高め（等倍と2倍の2回読み・細かく切り分け・多めに読む）
        return { ocrWorkers: 6, folderConc: 4, urlWorkers: 6, itemDelay: 0, pageDelay: 0, paintMs: 500, ocrScale: 3, chunkHeight: 1200, maxChunks: 30, urlImages: 10, pages: 6, settleMs: 1500, timeoutSec: 25 };
      case "relaxed": // 古いPC（例：Core i7-2600）で、作業しながら。負荷は低く、精度は「全速力」と同じ（時間をかけて着実に）
        return { ocrWorkers: 2, folderConc: 1, urlWorkers: 2, itemDelay: 400, pageDelay: 1000, paintMs: 1000, ocrScale: 3, chunkHeight: 1200, maxChunks: 30, urlImages: 10, pages: 6, settleMs: 2500, timeoutSec: 40 };
      default: // 標準
        return { ocrWorkers: Math.max(2, Math.min(4, Math.floor(HW.threads / 2))), folderConc: 2, urlWorkers: 3, itemDelay: 0, pageDelay: 300, paintMs: 300, ocrScale: 1, chunkHeight: 1800, maxChunks: 12, urlImages: 6, pages: 4, settleMs: 1500, timeoutSec: 25 };
    }
  }
  const recommendedPreset = () => (HW.threads >= 12 ? "max" : HW.threads >= 8 ? "standard" : "relaxed");
  const cfgEl = (k) => $("cfg_" + k);
  function readCfg() { const v = {}; for (const k of CFG_KEYS) v[k] = Number(cfgEl(k).value); return v; }
  function writeCfg(v) {
    for (const k of CFG_KEYS) {
      const el = cfgEl(k);
      if (!el || v[k] == null) continue;
      if (![...el.options].some((o) => Number(o.value) === Number(v[k]))) { const o = document.createElement("option"); o.value = String(v[k]); o.textContent = String(v[k]); el.appendChild(o); }
      el.value = String(v[k]);
    }
  }
  const currentPreset = () => { const r = document.querySelector('input[name="preset"]:checked'); return r ? r.value : "standard"; };
  function setPreset(name) { const r = document.querySelector(`input[name="preset"][value="${name}"]`); if (r) r.checked = true; }
  function updateCfgSummary() {
    const v = readCfg();
    const brief = $("presetBrief");
    if (brief) brief.textContent = `処理の強さ：${PRESET_LABEL[currentPreset()]}（変えたいときは下の「上級者向け設定」を開きます）`;
    const dl = (ms) => (ms ? `${ms / 1000}秒` : "なし");
    $("cfgSummary").textContent = `【${PRESET_LABEL[currentPreset()]}】 速度・負荷：文字読み取り${v.ocrWorkers}並列／フォルダ${v.folderConc}社同時／URL${v.urlWorkers}サイト同時／1件ごとの休み${dl(v.itemDelay)}　` +
      `精度：画像の文字は${SCALE_LABEL[v.ocrScale] || v.ocrScale}・${v.chunkHeight}pxずつ最大${v.maxChunks}片・1サイト${v.pages}ページ・読み込み後${v.settleMs / 1000}秒待つ`;
  }
  function showHwInfo() {
    const rec = recommendedPreset();
    $("hwInfo").textContent = `このPC：論理プロセッサ ${HW.threads}個` + (HW.mem ? `・メモリ ${HW.mem}GB以上` : "") +
      ` → 「${PRESET_LABEL[rec]}」がおすすめです。古いPCや、他の作業をしながら使うときは「まったり」が快適です。`;
    const card = document.querySelector(`.preset[data-preset="${rec}"] .p-rec`);
    if (card) card.hidden = false;
  }
  let saveTimer = null;
  function saveSettings() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        const p = chrome.storage.local.set({ bulkSettings: { preset: currentPreset(), values: readCfg(), checks: { ocr: $("optOcr").checked, skipOcr: $("optSkipOcr").checked, line: $("optLine").checked, retryCareful: $("optRetryCareful").checked } } });
        if (p && p.catch) p.catch(() => {});
      } catch (_e) { /* 保存できなくても動作には影響しない */ }
    }, 250);
  }
  async function loadSettings() {
    let saved = null;
    try { saved = (await chrome.storage.local.get({ bulkSettings: null })).bulkSettings; } catch (_e) { /* 無視 */ }
    const preset = saved && PRESET_LABEL[saved.preset] ? saved.preset : recommendedPreset();
    setPreset(preset);
    writeCfg(preset === "custom" && saved && saved.values ? saved.values : presetValues(preset));
    if (saved && saved.checks) {
      $("optOcr").checked = saved.checks.ocr !== false; $("optSkipOcr").checked = saved.checks.skipOcr !== false;
      $("optLine").checked = saved.checks.line !== false; $("optRetryCareful").checked = saved.checks.retryCareful !== false;
    }
    updateCfgSummary();
  }
  function onPresetChange() {
    const p = currentPreset();
    if (p !== "custom") writeCfg(presetValues(p));
    updateCfgSummary(); saveSettings();
  }
  function onCfgInput() { setPreset("custom"); updateCfgSummary(); saveSettings(); }

  // ---------- OCR（画像 → 文字） ----------
  async function getOcr(n) {
    n = Math.max(1, n || 2);
    if (state.ocr && state.ocrN === n) return state.ocr;
    if (state.ocr) { try { await state.ocr.terminate(); } catch (_e) { /* 無視 */ } state.ocr = null; }
    const scheduler = Tesseract.createScheduler();
    for (let i = 0; i < n; i++) {
      const w = await Tesseract.createWorker(["jpn", "eng"], 1, {
        workerPath: chrome.runtime.getURL("lib/worker.min.js"),
        corePath: chrome.runtime.getURL("lib/tesseract-core-simd-lstm.wasm.js"),
        langPath: chrome.runtime.getURL("lib/traineddata"),
        gzip: true,
        workerBlobURL: false,
        logger: () => {},
      });
      scheduler.addWorker(w);
    }
    state.ocr = scheduler;
    state.ocrN = n;
    return scheduler;
  }

  // 文字が（ほぼ）ない真っ白・単色の部分か？ 背景色と違う画素が少なければ空白とみなす（読み取りを省く）
  function isBlankCanvas(ctx, w, h) {
    const data = ctx.getImageData(0, 0, w, h).data;
    const at = (x, y) => { const i = (y * w + x) * 4; return [data[i], data[i + 1], data[i + 2]]; };
    const pts = [at(0, 0), at(w - 1, 0), at(0, h - 1), at(w - 1, h - 1), at(w >> 1, h >> 1), at(w >> 2, h >> 2), at((w * 3) >> 2, (h * 3) >> 2)];
    let bg = pts[0], best = 0;
    for (const p of pts) { const n = pts.filter((q) => Math.abs(q[0] - p[0]) + Math.abs(q[1] - p[1]) + Math.abs(q[2] - p[2]) < 30).length; if (n > best) { best = n; bg = p; } }
    let ink = 0;
    for (let i = 0; i < data.length; i += 4) {
      if (Math.abs(data[i] - bg[0]) + Math.abs(data[i + 1] - bg[1]) + Math.abs(data[i + 2] - bg[2]) > 60 && ++ink >= 60) return false;
    }
    return true;
  }

  // File / Blob の画像を読む。縦に長い画像は切り分け、空白の部分は省く。
  // ocrScale: 1=等倍 / 2=2倍に拡大 / 3=等倍と2倍の2回読み（両方の結果を合わせる。読み取りの取りこぼしが減る）
  async function ocrImageBlob(blob, o) {
    const scheduler = await getOcr(o.ocrWorkers);
    const bmp = await createImageBitmap(blob);
    try {
      const W = bmp.width, H = bmp.height;
      if (!W || !H) throw new Error("画像のサイズを読み取れません");
      const scales = o.ocrScale === 3 ? [1, 2] : [o.ocrScale || 1];
      const chunkH = o.chunkHeight || 1800;
      const maxChunks = o.maxChunks || 12;
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d", { willReadFrequently: true });
      const jobs = [];
      let chunks = 0, skipped = 0, covered = 0, truncated = false;
      for (const sc of scales) {
        let scale = sc;
        if (W * scale > MAX_OCR_WIDTH) scale = Math.max(1, MAX_OCR_WIDTH / W);
        let top = 0, cov = 0;
        while (top < H && cov < maxChunks) {
          const h = Math.min(chunkH, H - top);
          if (h < 12) break;
          const cw = Math.round(W * scale), chh = Math.round(h * scale);
          canvas.width = cw; canvas.height = chh;
          ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, cw, chh);
          ctx.imageSmoothingQuality = "high";
          ctx.drawImage(bmp, 0, top, W, h, 0, 0, cw, chh);
          cov++;
          if (isBlankCanvas(ctx, cw, chh)) skipped++;
          else {
            const part = await new Promise((r) => canvas.toBlob(r, "image/png"));
            jobs.push(scheduler.addJob("recognize", part));
            chunks++;
          }
          if (top + h >= H) break;
          top += chunkH - CHUNK_OVERLAP;
        }
        covered = Math.max(covered, cov);
        if (cov >= maxChunks && top + chunkH < H) truncated = true;
      }
      state.stats.ocrChunks += chunks; state.stats.ocrSkipped += skipped;
      const results = await Promise.all(jobs);
      return { text: results.map((r) => (r.data && r.data.text) || "").join("\n"), chunks, skipped, covered, truncated, chunkH };
    } finally {
      if (bmp.close) bmp.close();
    }
  }
  const ocrJoined = (r) => C.squashOcrSpaces(r.text).replace(/[ \t]*\r?\n[ \t]*/g, "");

  // =====================================================================
  //  ① フォルダモード
  // =====================================================================
  function onFolderChosen(fileList) {
    const files = [...fileList].map((f) => ({ name: f.name, ref: f }));
    const { groups, ignored } = C.groupFiles(files);
    state.groups = groups; state.ignored = ignored;
    resetResults();
    const nHtml = groups.reduce((n, g) => n + g.htmls.length, 0);
    const nImg = groups.reduce((n, g) => n + g.images.length, 0);
    const loose = groups.filter((g) => !g.grouped).length;
    const box = $("folderSummary");
    box.hidden = false;
    if (!groups.length) {
      box.innerHTML = "HTML・画像のファイルが見つかりませんでした。フォルダを選び直してください。";
    } else {
      box.innerHTML = `<strong>${groups.length.toLocaleString()}社</strong> を読み込みました（HTML ${nHtml.toLocaleString()}件・画像 ${nImg.toLocaleString()}件）` +
        (loose ? `<br><span class="note">名前の形式が「番号_会社名_main」と違うファイルは、1ファイルごとに別扱い：${loose}件</span>` : "") +
        (ignored ? `<br><span class="note">HTML・画像以外のファイル（対象外）：${ignored}件</span>` : "");
    }
    refreshStartButton();
  }

  async function processGroup(g, opts) {
    const det = state.det;
    const hits = new Map();
    const meta = { htmlCount: g.htmls.length, imageCount: g.images.length, notes: [], textChars: undefined, gotAnyText: false, ocrChunks: 0 };
    const errors = [];
    try {
      let chars = 0;
      for (const h of g.htmls) {
        try {
          const html = C.decodeHtmlBuffer(await h.ref.arrayBuffer());
          const ex = C.extractFromDocument(new DOMParser().parseFromString(html, "text/html"));
          chars += ex.textChars;
          meta.gotAnyText = true;
          det.scanSegments(ex.nodes, { source: "node", page: h.page, hits });
          det.scanSegments(ex.placeholders, { source: "placeholder", page: h.page, hits });
          if (opts.line) det.scanSegments(ex.lines, { source: "line", page: h.page, hits });
        } catch (e) {
          errors.push(`${h.name}: ${(e && e.message) || e}`);
        }
      }
      if (g.htmls.length) meta.textChars = chars;

      if (opts.ocr && g.images.length) {
        const pre = det.judge([...hits.keys()]);
        if (opts.skipOcr && /^(アウト|警告)/.test(pre.label)) {
          meta.ocrNote = "省略（HTMLで判定済み）";
        } else {
          for (const img of g.images) {
            try {
              const r = await ocrImageBlob(img.ref, opts);
              const joined = ocrJoined(r);
              det.scanSegments([joined], { source: "ocr", page: `${img.page}(画像)`, hits });
              meta.ocrDone = true;
              meta.ocrChunks += r.chunks;
              meta.gotAnyText = true;
              if (!g.htmls.length) meta.textChars = (meta.textChars || 0) + joined.length;
              if (r.truncated) meta.notes.push(`${img.name}：縦に長いため上から${r.covered * r.chunkH}px付近までOCR`);
            } catch (e) {
              errors.push(`${img.name}(OCR): ${(e && e.message) || e}`);
            }
          }
        }
      } else if (!opts.ocr && g.images.length) {
        meta.ocrNote = "画像は読み取らない設定";
      }
    } catch (e) {
      errors.push(String((e && e.message) || e));
    }
    if (errors.length) meta.error = errors.join(" ; ").slice(0, 400);
    return C.buildResult(det, g, hits, meta);
  }

  // =====================================================================
  //  ② URLモード（Chromeで自動でサイトを開いて判定）
  // =====================================================================

  // ページの中で実行される関数（chrome.scripting.executeScript に渡す。この関数の中身だけがページ側で動く）
  function PAGE_EXTRACT() {
    try {
      const core = window.SalesbanScanCore;
      const d = core.extractFromDocument(document, { images: true });
      return { url: location.href, title: document.title, top: window === window.top, ...d };
    } catch (e) {
      return { url: location.href, top: window === window.top, error: String((e && e.message) || e) };
    }
  }
  window.__BULK_PAGE_EXTRACT__ = PAGE_EXTRACT.toString(); // テスト用

  // 実際のChromeを操作する部分（タブを開く・読み込みを待つ・中身を取り出す）
  const realDriver = {
    async start(n) {
      if (!chrome.windows || !chrome.tabs || !chrome.scripting) throw new Error("必要な権限（windows / tabs / scripting）がありません。拡張機能を更新して再読み込みしてください");
      const w = await chrome.windows.create({ url: "about:blank", focused: false, width: 1000, height: 760 });
      const tabIds = [w.tabs[0].id];
      for (let i = 1; i < n; i++) {
        const t = await chrome.tabs.create({ windowId: w.id, url: "about:blank", active: false });
        tabIds.push(t.id);
      }
      // 登録してから開く：このタブでは、通常の検出・表示・OCR・先読みを止める
      await chrome.runtime.sendMessage({ type: "bulkTabs", add: tabIds });
      try { await chrome.windows.update(w.id, { state: "minimized" }); } catch (_e) { /* 最小化できなくても動作は同じ */ }
      return { winId: w.id, tabIds };
    },
    navigate(tabId, url, timeoutMs) {
      return new Promise((resolve) => {
        let finished = false;
        let sawLoading = false;
        const done = (r) => { if (finished) return; finished = true; chrome.tabs.onUpdated.removeListener(onUpd); resolve(r); };
        const onUpd = (id, info, tab) => {
          if (id !== tabId) return;
          if (info.status === "loading") sawLoading = true;
          if (info.status === "complete" && sawLoading) {
            const u = (tab && tab.url) || "";
            if (/^chrome-error:/i.test(u)) done({ ok: false, error: "接続できません（サイトが見つからない・応答がない・証明書の問題など）" });
            else done({ ok: true, finalUrl: u });
          }
        };
        chrome.tabs.onUpdated.addListener(onUpd);
        chrome.tabs.update(tabId, { url }).catch((e) => done({ ok: false, error: String((e && e.message) || e) }));
        sleep(timeoutMs).then(async () => {
          if (finished) return;
          try {
            const t = await chrome.tabs.get(tabId);
            const u = t.url || "";
            if (!u || /^(chrome-error:|about:blank)/i.test(u)) done({ ok: false, error: "読み込みがタイムアウトしました" });
            else done({ ok: true, finalUrl: u, partial: true });
          } catch (e) {
            done({ ok: false, error: "読み込みがタイムアウトしました" });
          }
        });
      });
    },
    async extract(tabId) {
      await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ["scanCore.js"] });
      const res = await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: PAGE_EXTRACT });
      return res.filter((r) => r && r.result).map((r) => ({ frameId: r.frameId, ...r.result }));
    },
    async finish(ctx) {
      try { await chrome.runtime.sendMessage({ type: "bulkTabs", remove: ctx.tabIds }); } catch (_e) { /* 無視 */ }
      try { await chrome.windows.remove(ctx.winId); } catch (_e) { /* すでに閉じている */ }
    },
  };
  const getDriver = () => window.__BULK_TEST_DRIVER__ || realDriver;

  async function fetchImageBlob(src) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    try {
      const res = await fetch(src, { credentials: "omit", signal: ctrl.signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const blob = await res.blob();
      if (blob.size > URL_IMAGE_MAX_BYTES) throw new Error("画像が大きすぎます");
      return blob;
    } finally { clearTimeout(timer); }
  }

  // 1サイトぶん：トップ → お問い合わせ・会社概要など → 画像の文字、の順に見る
  async function processSite(site, opts, drv, tabId, log) {
    const det = state.det;
    const hits = new Map();
    const meta = { htmlCount: 0, imageCount: 0, notes: [], textChars: 0, gotAnyText: false, ocrChunks: 0 };
    const errors = [];
    const queue = [{ url: site.startUrl, kind: "トップ" }];
    const visited = new Set();
    const seenImages = new Set(); // 同じサイトの複数ページに出てくる同じ画像（ロゴ・バナー）は、1回だけ読む
    let isTop = true;
    let stopEarly = false;

    while (queue.length && meta.htmlCount < opts.pages && !stopEarly) {
      const p = queue.shift();
      const key = p.url.replace(/#.*$/, "").replace(/\/$/, "");
      if (visited.has(key)) continue;
      visited.add(key);

      if (meta.htmlCount > 0 && opts.pageDelayMs) await sleep(opts.pageDelayMs); // 同じサイトへの連続アクセスの間隔
      log(`[${p.kind}] 開く: ${p.url}`);
      const t0 = performance.now();
      let nav = await drv.navigate(tabId, p.url, opts.timeoutMs);
      if (!nav.ok && isTop) {
        const alt = /^https:/i.test(p.url) ? p.url.replace(/^https:/i, "http:") : p.url.replace(/^http:/i, "https:");
        log(`  → 失敗（${nav.error}）。${alt.split(":")[0]} で再挑戦`);
        const nav2 = await drv.navigate(tabId, alt, opts.timeoutMs);
        if (nav2.ok) nav = nav2; else errors.push(`${p.url}: ${nav.error} ／ ${alt}: ${nav2.error}`);
      } else if (!nav.ok) {
        errors.push(`${p.url}: ${nav.error}`);
      }
      if (!nav.ok) { log(`  → 失敗: ${nav.error}`); if (isTop) break; continue; }
      log(`  → 読み込み完了（${((performance.now() - t0) / 1000).toFixed(1)}秒）${nav.partial ? "※タイムアウトまで待って途中の状態を取得" : ""} ${nav.finalUrl}`);
      await sleep(opts.settleMs); // 遅れて表示される内容を待つ

      let frames = [];
      try {
        frames = await drv.extract(tabId);
      } catch (e) {
        errors.push(`${p.url}: 内容を取り出せませんでした（${(e && e.message) || e}）`);
        log(`  → 取り出し失敗: ${(e && e.message) || e}`);
        if (isTop) break;
        continue;
      }
      const label = nav.finalUrl || p.url;
      meta.htmlCount++;
      meta.gotAnyText = true;
      const topFrame = frames.find((f) => f.top) || frames[0];
      let chars = 0;
      for (const f of frames) {
        if (f.error) { log(`  → フレームの取り出しエラー: ${f.error}`); continue; }
        const page = f.top ? label : `${label}（埋め込み:${shortUrl(f.url)}）`;
        chars += f.textChars || 0;
        det.scanSegments(f.nodes || [], { source: "node", page, hits });
        det.scanSegments(f.placeholders || [], { source: "placeholder", page, hits });
        if (opts.line) det.scanSegments(f.lines || [], { source: "line", page, hits });
      }
      meta.textChars += chars;
      log(`  → 本文 ${chars.toLocaleString()}文字（フレーム${frames.length}個）／画像候補 ${(topFrame && topFrame.images ? topFrame.images.length : 0)}枚`);

      const afterText = det.judge([...hits.keys()]);
      const alertNow = /^(アウト|警告)/.test(afterText.label);

      // 画像の文字（バナーなど）
      if (opts.ocr && topFrame && topFrame.images && topFrame.images.length) {
        if (opts.skipOcr && alertNow) {
          meta.ocrNote = "省略（本文で判定済み）";
        } else {
          const imgs = [...topFrame.images].filter((im) => !seenImages.has(im.src)).sort((a, b) => b.w * b.h - a.w * a.h).slice(0, opts.urlImages || 6);
          for (const im of imgs) {
            seenImages.add(im.src);
            try {
              const blob = await fetchImageBlob(im.src);
              const r = await ocrImageBlob(blob, opts);
              const joined = ocrJoined(r);
              det.scanSegments([joined], { source: "ocr", page: `${label}（画像:${shortUrl(im.src)}）`, hits });
              meta.ocrDone = true; meta.ocrChunks += r.chunks; meta.imageCount++;
              log(`  → 画像OCR: ${shortUrl(im.src)}（${im.w}×${im.h}）${joined.length}文字`);
            } catch (e) {
              log(`  → 画像OCR失敗: ${shortUrl(im.src)}（${(e && e.message) || e}）`);
            }
          }
        }
      }

      // 次に見るページ（トップのリンクから、お問い合わせ・会社概要などを優先）
      if (isTop && topFrame && topFrame.links) {
        const picks = C.pickLinks(label, topFrame.links, Math.max(0, opts.pages - 1));
        log(`  → 次に見るページ: ${picks.length ? picks.map((x) => shortUrl(x.url)).join(" , ") : "なし"}`);
        for (const pk of picks) queue.push({ url: pk.url, kind: pk.isContact ? "問い合わせ系" : "会社情報等" });
      }
      isTop = false;

      const now = det.judge([...hits.keys()]);
      if (opts.skipOcr && /^(アウト|警告)/.test(now.label) && queue.length) {
        stopEarly = true;
        meta.notes.push("アウト／警告が出たため、残りのページは確認していません");
        log("  → アウト／警告が出たので、このサイトはここで終了");
      }
    }
    if (errors.length) meta.error = errors.join(" ; ").slice(0, 400);
    return C.buildResult(det, { no: site.no, company: site.company, url: site.url, line: site.line }, hits, meta);
  }

  // ---------- URL入力 ----------
  function onUrlTextChanged() {
    const { rows, skipped, duplicates, lineCount, headerLine } = C.parseUrlList($("urlText").value);
    state.sites = rows.map((r, i) => ({ ...r, index: i }));
    state.urlMeta = { lineCount, headerLine }; // 元のシートの行との対応（比較用コピーで使う）
    resetResults();
    const box = $("urlSummary");
    if (!$("urlText").value.trim()) { box.hidden = true; refreshStartButton(); return; }
    box.hidden = false;
    box.innerHTML = rows.length
      ? `<strong>${rows.length.toLocaleString()}件</strong> のURLを読み取りました` +
        (duplicates ? `<br><span class="note">同じURLが重複：${duplicates}件（それぞれ判定します）</span>` : "") +
        (skipped.length ? `<br><span class="note">URLとして読めない行（除外）：${skipped.length}件　例：${esc(skipped[0].slice(0, 40))}</span>` : "")
      : `URLが見つかりませんでした。${skipped.length ? `<br><span class="note">読めなかった行の例：${esc(skipped[0].slice(0, 40))}</span>` : ""}`;
    refreshStartButton();
  }

  // ---------- 1件だけ試す ----------
  async function runUrlTest() {
    if (state.running || state.retryRunning || !state.sites.length || !state.det) return;
    state.running = true;
    showError("");
    const opts = readOptions();
    const site = state.sites[0];
    $("testBtn").disabled = true; $("startBtn").disabled = true;
    $("testBox").hidden = false;
    $("testResult").innerHTML = "試しています…（サイトを開いて判定します）";
    const lines = [];
    const log = (m) => { lines.push(m); $("testLog").textContent = lines.join("\n"); };
    log(`試すサイト: ${site.company}  ${site.url}`);
    log(`設定【${PRESET_LABEL[currentPreset()]}】: ページ数${opts.pages}／読み込み後の待ち${opts.settleMs / 1000}秒／上限${opts.timeoutMs / 1000}秒／画像の文字読み取り ${opts.ocr ? "あり" : "なし"}`);
    const drv = getDriver();
    let ctx = null;
    try {
      ctx = await drv.start(1);
      log("専用のウィンドウとタブを用意しました");
      const res = await processSite(site, opts, drv, ctx.tabIds[0], log);
      $("testResult").innerHTML = `<span class="badge ${badgeClass(res.label)}">${esc(shortLabel(res.label))}</span> ${esc(res.reason || "")}` +
        (res.snippets.length ? "<ul>" + res.snippets.slice(0, 3).map((s) => `<li>${esc(s.text)}</li>`).join("") + "</ul>" : "") +
        (res.error ? `<div class="note">エラー：${esc(res.error)}</div>` : "") +
        `<div class="note">問題なければ「スキャン開始」で全件を実行できます。</div>`;
    } catch (e) {
      $("testResult").innerHTML = `<span class="badge fail">失敗</span> ${esc((e && e.message) || e)}`;
      log("エラー: " + ((e && e.message) || e));
    } finally {
      if (ctx) { try { await drv.finish(ctx); } catch (_e) { /* 無視 */ } }
      state.running = false;
      refreshStartButton();
    }
  }

  // ---------- 実行（共通部分） ----------
  function readOptions() {
    const v = readCfg();
    return {
      ocr: $("optOcr").checked, skipOcr: $("optSkipOcr").checked, line: $("optLine").checked,
      ocrWorkers: v.ocrWorkers, folderConc: v.folderConc, workers: v.urlWorkers,
      itemDelayMs: v.itemDelay, pageDelayMs: v.pageDelay, paintMs: v.paintMs,
      ocrScale: v.ocrScale, chunkHeight: v.chunkHeight, maxChunks: v.maxChunks, urlImages: v.urlImages,
      pages: v.pages, timeoutMs: v.timeoutSec * 1000,
      settleMs: window.__BULK_SETTLE_MS__ != null ? window.__BULK_SETTLE_MS__ : v.settleMs,
    };
  }
  // 再試行：慎重モードなら、待ち時間を2倍・画像を高精度で読む・全ページ確認する
  function retryOptions(opts) {
    if (!$("optRetryCareful").checked) return opts;
    return { ...opts, timeoutMs: opts.timeoutMs * 2, settleMs: opts.settleMs * 2, skipOcr: false, ocrScale: 3, chunkHeight: Math.min(opts.chunkHeight, 1200), maxChunks: Math.max(opts.maxChunks, 30), pageDelayMs: Math.max(opts.pageDelayMs, 500) };
  }
  const unitsOfMode = () => (state.mode === "url" ? state.sites : state.groups);
  const pace = (opts) => (opts.itemDelayMs ? sleep(opts.itemDelayMs) : Promise.resolve());

  const LOCK_IDS = ["optOcr", "optSkipOcr", "optLine", "folderInput", "urlText", "urlFile", "urlClearBtn", "tabFolder", "tabUrl"];
  function setLocked(locked) {
    LOCK_IDS.forEach((id) => { const el = $(id); if (el) el.disabled = locked; });
    document.querySelectorAll("[data-cfg], input[name='preset']").forEach((el) => { el.disabled = locked; });
  }

  async function keepAwake() {
    try { return navigator.wakeLock ? await navigator.wakeLock.request("screen") : null; } catch (_e) { return null; }
  }

  function insertRow(res) {
    const rows = state.rows;
    let lo = 0, hi = rows.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (rows[mid].order <= res.order) lo = mid + 1; else hi = mid; }
    rows.splice(lo, 0, res);
  }
  function replaceRow(res) {
    const i = state.rows.findIndex((r) => r.order === res.order);
    if (i >= 0) state.rows[i] = res; else insertRow(res);
  }

  function updateProgress() {
    const total = state.total, done = state.done;
    const pct = total ? Math.round((done / total) * 100) : 0;
    $("barFill").style.width = pct + "%";
    let eta = "";
    if (done > 0 && done < total) eta = ` ／ 残り約${fmtTime((state.elapsedMs / done) * (total - done))}`;
    $("progressText").textContent = `${done.toLocaleString()} / ${total.toLocaleString()}${state.mode === "url" ? "件" : "社"}（${pct}%） 経過 ${fmtTime(state.elapsedMs)}${eta}`;
    if (state.running) {
      const act = [...state.active.values()];
      const st = state.stats;
      $("progressCurrent").textContent = (act.length ? `処理中：${act.slice(0, 3).join("、")}${act.length > 3 ? ` ほか${act.length - 3}件` : ""}` : "") +
        (st.ocrChunks + st.ocrSkipped ? `　／　画像の文字読み取り ${st.ocrChunks.toLocaleString()}片（空白 ${st.ocrSkipped.toLocaleString()}片は省略）` : "");
    }
  }

  const failResult = (unit, e) => C.buildResult(state.det, { no: unit.no, company: unit.company, url: unit.url, line: unit.line }, new Map(), { htmlCount: 0, notes: [], error: String((e && e.message) || e).slice(0, 300) });

  // 1件を処理する（通常・再試行共通）
  async function processUnit(unit, opts, drv, slot) {
    state.stats.active++; state.stats.maxActive = Math.max(state.stats.maxActive, state.stats.active);
    try {
      return state.mode === "url" ? await processSite(unit, opts, drv, slot, () => {}) : await processGroup(unit, opts);
    } catch (e) {
      return failResult(unit, e);
    } finally { state.stats.active--; }
  }

  // 再試行を1件処理して、表の行を差し替える
  async function doRetryOne(order, slot, opts, drv) {
    const unit = unitsOfMode()[order];
    if (!unit) return;
    state.retrying.add(order); updateRetryBar(); renderResults(true);
    const ropts = retryOptions(opts);
    let res = await processUnit(unit, ropts, drv, slot);
    const old = state.rows.find((r) => r.order === order);
    const n = ((old && old.retries) || 0) + 1;
    res.order = order; res.retries = n;
    const ni = C.RESULT_COLUMNS.indexOf("備考");
    if (ni >= 0) res.cells[ni] = (res.cells[ni] ? res.cells[ni] + " / " : "") + `再試行${n}回目の結果`;
    replaceRow(res);
    state.retrying.delete(order);
    updateRetryBar(); renderResults(true);
  }

  async function run() {
    if (state.running || state.retryRunning || !state.det) return;
    const isUrl = state.mode === "url";
    const units = unitsOfMode();
    if (!units.length) return;
    state.running = true;
    state.stopRequested = false;
    state.total = units.length;
    state.stats.ocrChunks = 0; state.stats.ocrSkipped = 0;
    showError("");
    $("testBox").hidden = true;
    const opts = readOptions();
    $("startBtn").hidden = true; $("testBtn").hidden = true;
    $("stopBtn").hidden = false; $("stopBtn").disabled = false; $("stopBtn").textContent = "一時停止";
    $("resetBtn").hidden = true;
    $("progressBox").hidden = false;
    $("progressCurrent").textContent = "";
    $("stepResults").hidden = false;
    setLocked(true);
    const lock = await keepAwake();
    const t0 = performance.now();
    const base = state.elapsedMs;
    let lastPaint = 0;
    const tick = async (force) => {
      state.elapsedMs = base + (performance.now() - t0);
      const now = performance.now();
      if (force || now - lastPaint > opts.paintMs) { lastPaint = now; updateProgress(); renderResults(false); await yieldUI(); }
    };

    const drv = isUrl ? getDriver() : null;
    let ctx = null;
    try {
      let slots;
      if (isUrl) {
        try { ctx = await drv.start(opts.workers); } catch (e) { throw new Error("サイトを開くためのウィンドウを用意できませんでした：" + ((e && e.message) || e)); }
        slots = ctx.tabIds;
      } else {
        slots = Array.from({ length: Math.max(1, Math.min(opts.folderConc, units.length)) }, (_, i) => `f${i}`);
      }
      let next = state.cursor;
      const worker = async (slot) => {
        for (;;) {
          if (state.stopRequested) return;
          // 再試行の依頼があれば、先にそれを処理する
          const rq = state.retryQueue.shift();
          if (rq != null) { await doRetryOne(rq, slot, opts, drv); await pace(opts); continue; }
          const i = next++;
          if (i >= units.length) { next = units.length; if (state.retryQueue.length) continue; return; }
          const unit = units[i];
          state.active.set(slot, `${unit.no ? unit.no + "_" : ""}${unit.company}`);
          const res = await processUnit(unit, opts, drv, slot);
          res.order = i;
          insertRow(res);
          state.done++;
          state.active.delete(slot);
          await tick(false);
          await pace(opts);
        }
      };
      await Promise.all(slots.map(worker));
      state.cursor = Math.min(next, units.length);
      state.active.clear();
      await tick(true);
    } catch (e) {
      showError("途中でエラーが起きました：" + ((e && e.message) || e) + "\nここまでの結果はCSVで保存できます。");
    } finally {
      if (ctx) { try { await drv.finish(ctx); } catch (_e) { /* 無視 */ } }
    }
    state.elapsedMs = base + (performance.now() - t0);
    if (lock && lock.release) { try { await lock.release(); } catch (_e) { /* 無視 */ } }
    state.running = false;
    setLocked(false);
    $("stopBtn").hidden = true;
    updateProgress();
    renderResults(true);

    const finished = state.cursor >= units.length;
    if (finished) {
      $("startBtn").hidden = true;
      $("resetBtn").hidden = false;
      $("progressCurrent").textContent = "完了しました。";
      if (state.rows.length) downloadCsv(true);
    } else {
      $("startBtn").hidden = false;
      $("startBtn").textContent = "続きから再開";
      $("resetBtn").hidden = false;
      $("progressCurrent").textContent = "一時停止中です。「続きから再開」で続けられます。ここまでの結果はCSVで保存できます。";
    }
    refreshStartButton();
    if (state.retryQueue.length) runRetries(); // 終了間際に依頼された再試行
  }

  // ---------- 再試行（個別・まとめて。スキャンが止まっているときも、実行中でも依頼できる） ----------
  const isRetryable = (r) => r.label === "読み取り失敗" || !!r.error;
  const isBusy = (order) => state.retryQueue.includes(order) || state.retrying.has(order);

  function requestRetry(orders) {
    let added = 0;
    for (const o of orders) { if (isBusy(o)) continue; state.retryQueue.push(o); added++; }
    if (!added) return;
    updateRetryBar(); renderResults(true);
    if (!state.running) runRetries();
  }

  // スキャンが動いていないとき：再試行だけを専用に実行する
  async function runRetries() {
    if (state.running || state.retryRunning || !state.retryQueue.length || !state.det) return;
    state.retryRunning = true;
    setLocked(true);
    const isUrl = state.mode === "url";
    const opts = readOptions();
    const ropts = retryOptions(opts);
    const lock = await keepAwake();
    const t0 = performance.now();
    $("progressCurrent").textContent = "再試行中です…";
    const drv = isUrl ? getDriver() : null;
    let ctx = null;
    try {
      const n = Math.max(1, Math.min(state.retryQueue.length, isUrl ? Math.min(ropts.workers, $("optRetryCareful").checked ? 2 : 99) : opts.folderConc));
      let slots;
      if (isUrl) { ctx = await drv.start(n); slots = ctx.tabIds; } else slots = Array.from({ length: n }, (_, i) => `r${i}`);
      await Promise.all(slots.map(async (slot) => {
        while (state.retryQueue.length) {
          const o = state.retryQueue.shift();
          await doRetryOne(o, slot, opts, drv);
          await pace(opts);
        }
      }));
    } catch (e) {
      // 開始できなかった分は、待ち行列から外す
      state.retryQueue.length = 0;
      showError("再試行を始められませんでした：" + ((e && e.message) || e));
    } finally {
      if (ctx) { try { await drv.finish(ctx); } catch (_e) { /* 無視 */ } }
      if (lock && lock.release) { try { await lock.release(); } catch (_e) { /* 無視 */ } }
    }
    state.retryRunning = false;
    setLocked(false);
    state.elapsedMs += performance.now() - t0;
    $("progressCurrent").textContent = state.cursor >= unitsOfMode().length ? "完了しました（再試行を反映しました。CSVを保存し直してください）。" : $("progressCurrent").textContent;
    updateRetryBar(); renderResults(true);
    if (state.retryQueue.length) runRetries();
  }

  function updateRetryBar() {
    const n = state.rows.filter((r) => isRetryable(r) && !isBusy(r.order)).length;
    const busy = state.retryQueue.length + state.retrying.size;
    $("retryBar").hidden = !(n || busy);
    $("retryInfo").textContent = `エラー・読み取り失敗のあった項目：${n}件` + (busy ? `（再試行中・待ち ${busy}件）` : "");
    $("retryAllBtn").disabled = n === 0;
  }

  function resetResults() {
    state.rows = []; state.cursor = 0; state.done = 0; state.total = 0; state.elapsedMs = 0; state.page = 0;
    state.filter = "ALL"; state.search = ""; state.openDetail.clear(); state.active.clear();
    state.retryQueue.length = 0; state.retrying.clear();
    $("searchBox").value = "";
    showError("");
    $("startBtn").hidden = false; $("startBtn").textContent = "スキャン開始";
    $("resetBtn").hidden = true;
    $("progressBox").hidden = true;
    $("progressText").textContent = "";
    $("progressCurrent").textContent = "";
    $("barFill").style.width = "0%";
    $("stepResults").hidden = true;
    $("testBox").hidden = true;
    $("retryBar").hidden = true;
  }

  function refreshStartButton() {
    const n = state.mode === "url" ? state.sites.length : state.groups.length;
    const ok = !!n && !!state.det && !state.running && !state.retryRunning;
    $("startBtn").disabled = !ok;
    $("testBtn").disabled = !ok;
    $("testBtn").hidden = state.mode !== "url" || ($("startBtn").hidden && !$("resetBtn").hidden);
  }

  function setMode(mode) {
    if (state.running || state.retryRunning || state.mode === mode) return;
    if (state.rows.length && !confirm("今の結果は消えます（CSVを保存していない場合は、先に保存してください）。切り替えますか？")) return;
    state.mode = mode;
    resetResults();
    $("tabFolder").classList.toggle("active", mode === "folder");
    $("tabUrl").classList.toggle("active", mode === "url");
    $("modeFolder").hidden = mode !== "folder";
    $("modeUrl").hidden = mode !== "url";
    refreshStartButton();
  }

  // ---------- 結果の表示 ----------
  const FILTERS = [["ALL", "すべて"], ["アウト", "アウト"], ["警告", "警告"], ["検出のみ", "検出のみ"], ["検出なし", "検出なし"], ["読み取り失敗", "読み取り失敗"]];
  const matchFilter = (r) => state.filter === "ALL" || r.label.startsWith(state.filter);
  const matchSearch = (r) => {
    const q = state.search.trim().normalize("NFKC").toLowerCase();
    if (!q) return true;
    return (r.group.no + " " + r.group.company + " " + (r.group.url || "") + " " + r.reason + " " + r.snippets.map((s) => s.word).join(" ")).normalize("NFKC").toLowerCase().includes(q);
  };

  function renderChips() {
    const counts = new Map();
    for (const r of state.rows) { const k = FILTERS.find(([key]) => key !== "ALL" && r.label.startsWith(key)); const key = k ? k[0] : "読み取り失敗"; counts.set(key, (counts.get(key) || 0) + 1); }
    $("chips").innerHTML = FILTERS.map(([key, name]) => {
      const n = key === "ALL" ? state.rows.length : counts.get(key) || 0;
      return `<button class="chip${state.filter === key ? " active" : ""}" data-filter="${esc(key)}">${esc(name)}<span class="n">${n.toLocaleString()}</span></button>`;
    }).join("");
  }

  function highlight(text, word) {
    const t = esc(text), w = esc(word);
    return w ? t.split(w).join(`<mark>${w}</mark>`) : t;
  }

  function renderResults(force) {
    renderChips();
    updateRetryBar();
    const list = state.rows.filter((r) => matchFilter(r) && matchSearch(r));
    const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
    if (state.page >= pages) state.page = pages - 1;
    const slice = list.slice(state.page * PAGE_SIZE, (state.page + 1) * PAGE_SIZE);
    $("countText").textContent = `${list.length.toLocaleString()}件を表示`;
    $("pageText").textContent = `${state.page + 1} / ${pages} ページ`;
    $("prevBtn").disabled = state.page <= 0;
    $("nextBtn").disabled = state.page >= pages - 1;
    $("resultBody").innerHTML = slice.map((r) => {
      const firstWords = r.snippets.slice(0, 3).map((s) => s.word).join(" / ");
      const open = state.openDetail.has(r.order);
      const busyWait = state.retryQueue.includes(r.order), busyRun = state.retrying.has(r.order);
      const urlLine = r.group.url ? `<span class="co-url"><a href="${esc(r.group.url)}" target="_blank" rel="noopener noreferrer">${esc(shortUrl(r.group.url))}</a></span>` : "";
      const badge = busyRun ? `<span class="badge wait">再試行中…</span>` : busyWait ? `<span class="badge wait">再試行待ち</span>` : `<span class="badge ${badgeClass(r.label)}">${esc(shortLabel(r.label))}</span>`;
      const retries = r.retries ? ` <span class="note">再試行${r.retries}回</span>` : "";
      const retryBtn = isRetryable(r) && !busyWait && !busyRun ? ` <button class="btn small warnbtn" data-retry="${r.order}">再試行</button>` : "";
      const detail = open
        ? `<tr class="detail"><td colspan="5"><div class="detail-box">
            <div class="detail-actions"><button class="btn small" data-retry="${r.order}"${busyWait || busyRun ? " disabled" : ""}>この項目をもう一度スキャン</button></div>
            <h4>判定の理由</h4><div>${esc(r.reason || "（なし）")}</div>
            <h4>見つかった前後の文</h4><ul>${r.snippets.map((s) => `<li>${highlight(s.text, s.word)}</li>`).join("") || "<li>（なし）</li>"}</ul>
            <h4>見つかったページ</h4><div>${r.pages.length ? r.pages.map((p) => esc(p)).join("<br>") : "（なし）"}</div>
            ${r.parityLabel !== r.label ? `<h4>拡張機能と同じ基準だと</h4><div>${esc(r.parityLabel)}</div>` : ""}
            ${r.notes.length ? `<h4>備考</h4><div>${esc(r.notes.join(" / "))}</div>` : ""}
            ${r.error ? `<h4>エラー</h4><div>${esc(r.error)}</div>` : ""}
          </div></td></tr>`
        : "";
      return `<tr><td class="no">${esc(r.group.no)}</td><td>${esc(r.group.company)}${urlLine}</td>
        <td>${badge}${retries}</td>
        <td class="words">${esc(firstWords)}${r.error && !r.snippets.length ? `<span class="note">${esc(r.error.slice(0, 60))}</span>` : ""}</td>
        <td><button class="btn small" data-detail="${r.order}">${open ? "閉じる" : "詳細"}</button>${retryBtn}</td></tr>${detail}`;
    }).join("");
  }

  // ---------- 保存・コピー ----------
  function stamp() {
    const d = new Date(); const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  }
  function downloadCsv(auto) {
    if (!state.rows.length) return;
    const blob = new Blob([C.resultsToCsv(state.rows)], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `営業禁止スキャン結果_${stamp()}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
    $("copyMsg").textContent = auto ? "完了したので、結果のCSVを自動で保存しました（ダウンロードフォルダ）" : "CSVを保存しました（ダウンロードフォルダ）";
  }
  async function copyTable() {
    if (!state.rows.length) return;
    try {
      await navigator.clipboard.writeText(C.resultsToTsv(state.rows));
      $("copyMsg").textContent = `${state.rows.length.toLocaleString()}件分をコピーしました。スプレッドシートに貼り付けてください`;
    } catch (e) {
      $("copyMsg").textContent = "コピーできませんでした。CSVをダウンロードしてください";
    }
  }

  // ---------- 元のシートと比べる（色だけ／判定の列のコピー） ----------
  const CMP_KEYS = { order: "cmpOrder", color: "cmpColor", detect: "cmpDetect", fail: "cmpFail" };
  function loadCompareSettings() {
    try {
      const o = JSON.parse(localStorage.getItem("bulkCompare") || "null");
      if (!o) return;
      if (o.order) $("cmpOrder").value = o.order;
      if (o.color) $("cmpColor").value = o.color;
      $("cmpDetect").checked = !!o.detect; $("cmpFail").checked = !!o.fail;
    } catch (_e) { /* 無視 */ }
  }
  function saveCompareSettings() {
    try { localStorage.setItem("bulkCompare", JSON.stringify({ order: $("cmpOrder").value, color: $("cmpColor").value, detect: $("cmpDetect").checked, fail: $("cmpFail").checked })); } catch (_e) { /* 無視 */ }
  }
  async function writeHtmlClipboard(html, text) {
    try {
      await navigator.clipboard.write([new ClipboardItem({
        "text/html": new Blob([html], { type: "text/html" }),
        "text/plain": new Blob([text], { type: "text/plain" }),
      })]);
      return true;
    } catch (_e) { /* 下の方法を試す */ }
    try {
      const div = document.createElement("div");
      div.contentEditable = "true";
      div.style.cssText = "position:fixed;left:-9999px;top:0;";
      div.innerHTML = html;
      document.body.appendChild(div);
      const sel = window.getSelection();
      const rg = document.createRange();
      rg.selectNodeContents(div);
      sel.removeAllRanges(); sel.addRange(rg);
      const ok = document.execCommand("copy");
      sel.removeAllRanges(); div.remove();
      return ok;
    } catch (_e) { return false; }
  }
  async function copyCompare(kind) {
    if (!state.rows.length) return;
    const out = C.buildCompareOutput(state.rows, {
      kind, mode: $("cmpOrder").value, isUrl: state.mode === "url", urlMeta: state.urlMeta,
      color: $("cmpColor").value, colorDetect: $("cmpDetect").checked, colorFail: $("cmpFail").checked,
    });
    const ok = await writeHtmlClipboard(out.html, out.text);
    const partial = state.running || state.retryRunning ? "（スキャン中のため、途中までの結果です）" : "";
    $("cmpMsg").textContent = ok
      ? `${out.lines.toLocaleString()}行分（色付き ${out.colored.toLocaleString()}行）をコピーしました${partial}。` +
        (kind === "format" ? "元のシートの列を選んで「書式のみ貼り付け」してください。" : "貼り付けてください。") + (out.notes.length ? "　※" + out.notes.join("／") : "")
      : "コピーできませんでした。CSVをダウンロードしてください";
  }

  // ---------- 初期化 ----------
  async function init() {
    try { $("verBadge").textContent = "v" + chrome.runtime.getManifest().version; } catch (_e) { /* 無視 */ }
    showHwInfo();
    $("tabFolder").addEventListener("click", () => setMode("folder"));
    $("tabUrl").addEventListener("click", () => setMode("url"));
    $("folderInput").addEventListener("change", (e) => onFolderChosen(e.target.files));
    let urlTimer = null;
    $("urlText").addEventListener("input", () => { clearTimeout(urlTimer); urlTimer = setTimeout(onUrlTextChanged, 200); });
    $("urlFile").addEventListener("change", async (e) => { const f = e.target.files[0]; if (f) { $("urlText").value = await f.text(); onUrlTextChanged(); } e.target.value = ""; });
    $("urlClearBtn").addEventListener("click", () => { $("urlText").value = ""; onUrlTextChanged(); });
    document.querySelectorAll("input[name='preset']").forEach((r) => r.addEventListener("change", onPresetChange));
    document.querySelectorAll("[data-cfg]").forEach((el) => el.addEventListener("change", onCfgInput));
    ["optOcr", "optSkipOcr", "optLine", "optRetryCareful"].forEach((id) => $(id).addEventListener("change", saveSettings));
    $("startBtn").addEventListener("click", run);
    $("testBtn").addEventListener("click", runUrlTest);
    $("stopBtn").addEventListener("click", () => { state.stopRequested = true; $("stopBtn").disabled = true; $("stopBtn").textContent = "停止しています…（実行中の分が終わるまでお待ちください）"; });
    $("resetBtn").addEventListener("click", () => {
      if (state.running || state.retryRunning) return;
      resetResults();
      refreshStartButton();
    });
    $("csvBtn").addEventListener("click", () => downloadCsv(false));
    $("copyBtn").addEventListener("click", copyTable);
    loadCompareSettings();
    Object.values(CMP_KEYS).forEach((id) => $(id).addEventListener("change", saveCompareSettings));
    $("fmtBtn").addEventListener("click", () => copyCompare("format"));
    $("colsBtn").addEventListener("click", () => copyCompare("cols"));
    $("retryAllBtn").addEventListener("click", () => requestRetry(state.rows.filter((r) => isRetryable(r) && !isBusy(r.order)).map((r) => r.order)));
    $("chips").addEventListener("click", (e) => { const b = e.target.closest("[data-filter]"); if (b) { state.filter = b.dataset.filter; state.page = 0; renderResults(true); } });
    $("searchBox").addEventListener("input", (e) => { state.search = e.target.value; state.page = 0; renderResults(true); });
    $("prevBtn").addEventListener("click", () => { state.page = Math.max(0, state.page - 1); renderResults(true); });
    $("nextBtn").addEventListener("click", () => { state.page++; renderResults(true); });
    $("resultBody").addEventListener("click", (e) => {
      const rb = e.target.closest("[data-retry]");
      if (rb) { requestRetry([Number(rb.dataset.retry)]); return; }
      const b = e.target.closest("[data-detail]");
      if (!b) return;
      const k = Number(b.dataset.detail);
      if (state.openDetail.has(k)) state.openDetail.delete(k); else state.openDetail.add(k);
      renderResults(true);
    });
    window.addEventListener("beforeunload", (e) => { if (state.running || state.retryRunning) { e.preventDefault(); e.returnValue = ""; } });
    await loadSettings();
    try {
      const info = await loadDetector();
      state.det = info.det;
      showWordInfo(info);
      refreshStartButton();
    } catch (e) {
      const msg = "判定用の単語を読み込めませんでした：" + ((e && e.message) || e);
      showError(msg);
      $("wordInfo").className = "info warn";
      $("wordInfo").textContent = "⚠ " + msg;
    }
  }
  init();
})();

// urlcheck.js — URL不備チェック（ver9.14）
// 作業用シートのURLの列を貼り付け → 各URLにアクセス → 入力と同じ順番・同じ行数で判定を返す。
// 拡張機能のページ（この画面）から fetch で行う（<all_urls> の権限があるため CORS の制限を受けない）。
// 外部のサーバー・GAS・スプレッドシートへの書き込みは一切しない。貼り付けたURLと結果は chrome.storage.local だけに保存する。
(() => {
  "use strict";

  // ===== 調整用の定数 =====
  const CONCURRENCY = 8;            // 同時に処理する数（古いPCでも固まらないように控えめ）
  const TIMEOUT_MS = 10000;         // 1回のアクセスを待つ最長時間（ヘッダーが届くまで）
  const MAX_REQUESTS_PER_URL = 2;   // 1つのURLにつき、リクエストは最大2回
  const SAVE_EVERY = 200;           // 何件ごとに途中経過を保存するか
  const REASON_WAIT_MS = 500;       // 失敗の理由（webRequest）が届くのを待つ最長時間
  const STORAGE_KEY = "urlCheckState";
  // ボット対策などの可能性がある（ブラウザでは開けるかもしれない）HTTPステータス
  const REVIEW_STATUS = new Set([401, 403, 405, 406, 429, 999]);

  const L = {
    OK: "OK",
    ERROR: "エラー",
    UNREACH: "接続できない",
    UNKNOWN: "接続できない（種類不明）",
    REVIEW: "要確認",
    EXCLUDED: "除外",
    INVALID: "URL不正",
  };
  const COUNT_ORDER = [L.OK, L.ERROR, L.UNREACH, L.UNKNOWN, L.REVIEW, L.EXCLUDED, L.INVALID];

  const $ = (id) => document.getElementById(id);

  // ===== タイマー（裏のタブでも間引かれないよう Worker を使う。bulk.js と同じ仕組み） =====
  let tw = null;
  const tWaiters = new Map();
  let tSeq = 0;
  try {
    tw = new Worker("timer-worker.js");
    tw.onmessage = (e) => {
      const id = e.data && e.data.id;
      const f = tWaiters.get(id);
      if (f) { tWaiters.delete(id); f(); }
    };
  } catch (_e) { tw = null; }
  function startTimer(ms, fn) {
    if (!tw) { const h = setTimeout(fn, ms); return () => clearTimeout(h); }
    const id = ++tSeq;
    tWaiters.set(id, fn);
    tw.postMessage({ id, ms });
    return () => tWaiters.delete(id);
  }
  const sleep = (ms) => new Promise((r) => startTimer(ms, r));

  // ===== 失敗の理由の取得（webRequest） =====
  // fetch の失敗は理由（net::ERR_CERT_* など）が取れないため、chrome.webRequest.onErrorOccurred で種類を取る。
  // 取れるかどうかは実機で確認が必要。取れない場合は「接続できない（種類不明）」として出す（下の judgeNet）。
  const originByRequest = new Map(); // requestId -> 最初のURL（リダイレクトしても同じ requestId）
  const lastErrorByUrl = new Map();  // 最初のURL -> エラー文字列
  let webRequestReady = false;
  try {
    if (chrome.webRequest && chrome.webRequest.onErrorOccurred) {
      const filter = { urls: ["<all_urls>"], types: ["xmlhttprequest"] };
      chrome.webRequest.onBeforeRequest.addListener((d) => {
        if (d.tabId !== -1) return;
        if (!originByRequest.has(d.requestId)) originByRequest.set(d.requestId, d.url);
      }, filter);
      chrome.webRequest.onErrorOccurred.addListener((d) => {
        if (d.tabId !== -1) return;
        const o = originByRequest.get(d.requestId) || d.url;
        originByRequest.delete(d.requestId);
        if (lastErrorByUrl.size > 5000) lastErrorByUrl.clear();
        lastErrorByUrl.set(o, String(d.error || ""));
      }, filter);
      chrome.webRequest.onCompleted.addListener((d) => { originByRequest.delete(d.requestId); }, filter);
      webRequestReady = true;
    }
  } catch (_e) { webRequestReady = false; }

  async function waitForReason(url) {
    if (!webRequestReady) return null;
    const until = Date.now() + REASON_WAIT_MS;
    for (;;) {
      const e = lastErrorByUrl.get(url);
      if (e && e !== "net::ERR_ABORTED") { lastErrorByUrl.delete(url); return e; }
      if (Date.now() >= until) return null;
      await sleep(50);
    }
  }

  // ===== URLの解釈 =====
  function parseLine(raw) {
    const t = String(raw == null ? "" : raw).replace(/^\uFEFF/, "").trim();
    if (!t) return { invalid: "空行" };
    if (/\s/.test(t)) return { invalid: "空白を含む" };
    if (/^(mailto|tel|javascript|data|file|ftp|blob):/i.test(t)) return { invalid: "http/https以外" };
    let s = t;
    let inferred = false;
    if (!/^[a-z][a-z0-9+.\-]*:\/\//i.test(s)) { s = "https://" + s.replace(/^\/\//, ""); inferred = true; }
    let u;
    try { u = new URL(s); } catch (_e) { return { invalid: "URLとして読めない" }; }
    if (u.protocol !== "http:" && u.protocol !== "https:") return { invalid: "http/https以外" };
    if (!u.hostname) return { invalid: "ホスト名が無い" };
    u.hash = "";
    return { href: u.href, inferred };
  }

  // ===== 状態 =====
  let rows = [];      // { raw, href|null, inferred }
  let results = [];   // null | { l: ラベル, d: 詳細, net?: true, known?: true }
  let counts = {};
  let running = false;
  let cancelRequested = false;
  let startedAt = 0;
  let doneAtStart = 0;
  let sinceSave = 0;
  let saving = false;
  const activeCtrls = new Set();
  const doneByKey = new Map();
  const inflight = new Map();

  function resetCounts() {
    counts = {};
    for (const k of COUNT_ORDER) counts[k] = 0;
    counts.pending = 0;
    counts.netFail = 0;
    counts.netKnown = 0;
  }
  function recount() {
    resetCounts();
    for (let i = 0; i < rows.length; i++) {
      const r = results[i];
      if (!r) { counts.pending++; continue; }
      counts[r.l] = (counts[r.l] || 0) + 1;
      if (r.net) { counts.netFail++; if (r.known) counts.netKnown++; }
    }
  }

  // ===== アクセス =====
  // 戻り値： { kind: "http", status } | { kind: "net", reason|null, timedOut? } | { kind: "aborted" }
  async function doFetch(url, method) {
    lastErrorByUrl.delete(url);
    const ctrl = new AbortController();
    activeCtrls.add(ctrl);
    let timedOut = false;
    const cancelTimer = startTimer(TIMEOUT_MS, () => { timedOut = true; try { ctrl.abort(); } catch (_e) { /* 無視 */ } });
    try {
      const res = await fetch(url, { method, signal: ctrl.signal, credentials: "omit", redirect: "follow", cache: "no-store" });
      cancelTimer();
      const status = res.status;
      try { ctrl.abort(); } catch (_e) { /* ボディは読まずに中断する（ヘッダーを受け取った時点で十分） */ }
      return { kind: "http", status };
    } catch (_e) {
      cancelTimer();
      if (cancelRequested) return { kind: "aborted" };
      if (timedOut) return { kind: "net", timedOut: true, reason: null };
      return { kind: "net", reason: await waitForReason(url) };
    } finally {
      activeCtrls.delete(ctrl);
    }
  }

  const isCertOrSsl = (reason) => /ERR_CERT_|ERR_SSL_|ERR_BAD_SSL|ERR_SSL/i.test(reason || "");
  const isDns = (reason) => /ERR_NAME_NOT_RESOLVED|ERR_NAME_RESOLUTION_FAILED/i.test(reason || "");
  const isNetworkDown = (reason) => /ERR_INTERNET_DISCONNECTED|ERR_NETWORK_CHANGED|ERR_NETWORK_ACCESS_DENIED/i.test(reason || "");
  const shortReason = (reason) => String(reason || "").replace(/^net::/, "");

  function judgeHttp(status) {
    if (status >= 200 && status < 400) return { l: L.OK, d: "HTTP " + status };
    if (REVIEW_STATUS.has(status)) return { l: L.REVIEW, d: "HTTP " + status };
    return { l: L.ERROR, d: "HTTP " + status };
  }
  function judgeNet(r) {
    if (r.timedOut) return { l: L.UNREACH, d: "タイムアウト（" + TIMEOUT_MS / 1000 + "秒）", net: true };
    if (!r.reason) return { l: L.UNKNOWN, d: "種類不明", net: true };
    if (isCertOrSsl(r.reason)) return { l: L.EXCLUDED, d: shortReason(r.reason), net: true, known: true };
    if (isNetworkDown(r.reason) || /ERR_BLOCKED_BY/i.test(r.reason)) return { l: L.REVIEW, d: shortReason(r.reason), net: true, known: true };
    return { l: L.UNREACH, d: shortReason(r.reason), net: true, known: true };
  }

  // 1つのURLを判定（リクエストは最大2回）
  //  1回目：HEAD。2xxならOK。それ以外のHTTPステータス（405など）ならGETでやり直す
  //  ネットワーク失敗：証明書／HTTPSの設定エラー・名前が解決できない、は確定（やり直さない）。
  //   それ以外（タイムアウト・切断・種類不明）はGETでやり直す。https:// を補ったURLは、やり直しを http:// で行う
  async function checkUrl(href, inferred) {
    let requests = 0;
    const go = async (url, method) => { requests++; return await doFetch(url, method); };

    let r1 = await go(href, "HEAD");
    if (r1.kind === "aborted") return null;
    if (r1.kind === "http") {
      if (r1.status >= 200 && r1.status < 400) return judgeHttp(r1.status);
      if (requests >= MAX_REQUESTS_PER_URL) return judgeHttp(r1.status);
      const r2 = await go(href, "GET");
      if (r2.kind === "aborted") return null;
      return r2.kind === "http" ? judgeHttp(r2.status) : judgeNet(r2);
    }
    // ネットワーク失敗
    if (isCertOrSsl(r1.reason) || isDns(r1.reason) || isNetworkDown(r1.reason) || requests >= MAX_REQUESTS_PER_URL) return judgeNet(r1);
    const url2 = inferred && href.startsWith("https:") ? "http:" + href.slice(6) : href;
    const r2 = await go(url2, "GET");
    if (r2.kind === "aborted") return null;
    if (r2.kind === "http") {
      const j = judgeHttp(r2.status);
      if (url2 !== href && j.l === L.OK) j.d += "（httpで到達）";
      return j;
    }
    // 2回とも失敗：理由が分かった方を使う
    return judgeNet(r1.reason || r1.timedOut ? r1 : r2);
  }

  async function processRow(i) {
    const row = rows[i];
    const key = (row.inferred ? "1|" : "0|") + row.href;
    let res = doneByKey.get(key);
    if (!res) {
      let p = inflight.get(key);
      if (!p) {
        p = checkUrl(row.href, row.inferred).then((r) => { inflight.delete(key); if (r) doneByKey.set(key, r); return r; });
        inflight.set(key, p);
      }
      res = await p;
    }
    if (!res) return; // 中断
    setResult(i, res);
  }

  function setResult(i, res) {
    if (results[i]) return;
    results[i] = res;
    counts.pending--;
    counts[res.l] = (counts[res.l] || 0) + 1;
    if (res.net) { counts.netFail++; if (res.known) counts.netKnown++; }
    sinceSave++;
    renderProgress();
    if (sinceSave >= SAVE_EVERY) saveState();
  }

  // ===== 実行 =====
  async function runChecks() {
    running = true;
    cancelRequested = false;
    startedAt = Date.now();
    doneAtStart = rows.length - counts.pending;
    updateButtons();
    renderProgress();

    const todo = [];
    for (let i = 0; i < rows.length; i++) if (!results[i]) todo.push(i);
    let next = 0;
    const worker = async () => {
      while (!cancelRequested) {
        const i = todo[next++];
        if (i === undefined) return;
        while (!navigator.onLine && !cancelRequested) {
          $("status").textContent = "ネットワークに接続されていません。再接続を待っています…";
          await sleep(2000);
        }
        if (cancelRequested) return;
        try { await processRow(i); } catch (_e) { /* 1件の失敗で全体を止めない */ }
      }
    };
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, Math.max(1, todo.length)) }, worker));

    running = false;
    await saveState();
    updateButtons();
    renderProgress(true);
  }

  // ===== 保存・復元 =====
  async function saveState() {
    if (saving) return;
    saving = true;
    sinceSave = 0;
    try {
      await chrome.storage.local.set({
        [STORAGE_KEY]: { v: 1, lines: rows.map((r) => r.raw), results, updatedAt: Date.now() },
      });
    } catch (e) {
      $("status").textContent = "途中経過を保存できませんでした：" + String(e && e.message || e);
    } finally {
      saving = false;
    }
  }

  function loadRows(lines) {
    rows = lines.map((raw) => {
      const p = parseLine(raw);
      return p.invalid ? { raw, href: null, inferred: false, invalid: p.invalid } : { raw, href: p.href, inferred: p.inferred };
    });
    results = rows.map((r) => (r.href ? null : { l: L.INVALID, d: r.invalid }));
    doneByKey.clear();
    inflight.clear();
    recount();
  }

  function inputLines() {
    const lines = $("input").value.split(/\r?\n/);
    while (lines.length && !lines[lines.length - 1].trim()) lines.pop(); // 末尾の空行（貼り付け時の改行）は行に数えない
    return lines;
  }

  // ===== 画面 =====
  function updateButtons() {
    const hasResults = rows.length > 0;
    $("startBtn").disabled = running;
    $("resumeBtn").disabled = running;
    $("stopBtn").disabled = !running;
    $("copyBtn").disabled = !hasResults;
    $("csvBtn").disabled = !hasResults;
    $("clearBtn").disabled = running;
    $("input").disabled = running;
  }

  function fmtTime(ms) {
    const s = Math.max(0, Math.round(ms / 1000));
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
    return h ? h + "時間" + m + "分" : m ? m + "分" + String(ss).padStart(2, "0") + "秒" : ss + "秒";
  }

  function renderProgress(finished) {
    const total = rows.length;
    const done = total - counts.pending;
    $("bar").max = Math.max(1, total);
    $("bar").value = done;
    let msg;
    if (!total) msg = "待機中";
    else if (running) {
      const processed = done - doneAtStart;
      const elapsed = Date.now() - startedAt;
      const eta = processed > 5 ? "　残り約" + fmtTime((elapsed / processed) * counts.pending) : "";
      msg = "処理中… " + done + " / " + total + " 行" + eta;
    } else if (counts.pending === 0) msg = "完了：" + total + " 行";
    else msg = (finished ? "中断しました：" : "未完了：") + done + " / " + total + " 行（［続きから再開］で続行できます）";
    $("status").textContent = msg;

    const box = $("counts");
    box.textContent = "";
    for (const k of COUNT_ORDER) {
      if (!counts[k] && k !== L.OK) continue;
      const s = document.createElement("span");
      const b = document.createElement("b");
      b.textContent = String(counts[k] || 0);
      s.append(k + " ", b);
      box.appendChild(s);
    }
    if (counts.pending) {
      const s = document.createElement("span");
      const b = document.createElement("b");
      b.textContent = String(counts.pending);
      s.append("未処理 ", b);
      box.appendChild(s);
    }

    // 「どこまで分かるか」の正直な表示
    const note = $("detailNote");
    if (counts.netFail > 0 && !running) {
      note.hidden = false;
      note.textContent = "接続の失敗 " + counts.netFail + " 件のうち、失敗の種類（証明書／名前が解決できない／接続拒否 など）が取れたのは " + counts.netKnown + " 件です。" +
        (counts.netKnown === 0 && counts.netFail - counts.netKnown > 0
          ? "種類を取得できなかったため、証明書エラーのサイトが「接続できない（種類不明）」に含まれている可能性があります。"
          : "「接続できない（種類不明）」は、種類が取れなかった失敗です（タイムアウトは種類不明に含めず「接続できない」にしています）。");
    } else {
      note.hidden = true;
    }
  }

  function showResumeNote() {
    const note = $("resumeNote");
    const total = rows.length;
    if (!total) { note.hidden = true; $("resumeBtn").hidden = true; return; }
    const done = total - counts.pending;
    note.hidden = false;
    note.textContent = counts.pending
      ? "前回の途中結果が残っています（" + done + " / " + total + " 行が処理済み）。［続きから再開］で続行、［チェック開始］で最初からやり直します。"
      : "前回の結果が残っています（" + total + " 行）。コピー／CSVで取り出せます。新しくチェックするときは、URLを貼り直して［チェック開始］を押してください。";
    $("resumeBtn").hidden = counts.pending === 0;
  }

  // ===== 出力 =====
  function resultsAsText() {
    const withDetail = $("withDetail").checked;
    return rows.map((_r, i) => {
      const r = results[i];
      if (!r) return withDetail ? "\t" : "";
      return withDetail ? r.l + "\t" + r.d : r.l;
    }).join("\n");
  }

  async function copyResults() {
    const text = resultsAsText();
    try {
      await navigator.clipboard.writeText(text);
    } catch (_e) {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    $("status").textContent = rows.length + " 行分の結果をコピーしました（シートの1列に貼り付けてください）";
  }

  function csvCell(v) {
    const s = String(v == null ? "" : v);
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function downloadCsv() {
    const lines = ["行,URL,判定,詳細"];
    rows.forEach((r, i) => {
      const x = results[i];
      lines.push([i + 1, r.raw, x ? x.l : "", x ? x.d : ""].map(csvCell).join(","));
    });
    const blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    a.download = "url_check_" + d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + "_" + p(d.getHours()) + p(d.getMinutes()) + ".csv";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 5000);
  }

  // ===== ボタン =====
  $("startBtn").addEventListener("click", () => {
    const lines = inputLines();
    if (!lines.length) { $("status").textContent = "URLを貼り付けてください"; return; }
    loadRows(lines);
    $("resumeNote").hidden = true;
    $("resumeBtn").hidden = true;
    saveState();
    runChecks();
  });
  $("resumeBtn").addEventListener("click", () => {
    $("resumeNote").hidden = true;
    $("resumeBtn").hidden = true;
    runChecks();
  });
  $("stopBtn").addEventListener("click", () => {
    cancelRequested = true;
    for (const c of activeCtrls) { try { c.abort(); } catch (_e) { /* 無視 */ } }
    $("status").textContent = "中断しています…";
  });
  $("copyBtn").addEventListener("click", copyResults);
  $("csvBtn").addEventListener("click", downloadCsv);
  $("clearBtn").addEventListener("click", async () => {
    if (rows.length && !confirm("貼り付けたURLと結果を消します。よろしいですか？")) return;
    rows = []; results = []; doneByKey.clear(); inflight.clear();
    resetCounts();
    $("input").value = "";
    try { await chrome.storage.local.remove(STORAGE_KEY); } catch (_e) { /* 無視 */ }
    $("resumeNote").hidden = true;
    $("resumeBtn").hidden = true;
    updateButtons();
    renderProgress();
  });
  window.addEventListener("beforeunload", (e) => { if (running) { e.preventDefault(); e.returnValue = ""; } });
  window.addEventListener("pagehide", () => { if (rows.length) saveState(); });

  // ===== 起動時：前回の状態を復元 =====
  resetCounts();
  updateButtons();
  renderProgress();
  chrome.storage.local.get({ [STORAGE_KEY]: null }, (d) => {
    const st = d && d[STORAGE_KEY];
    if (!st || !Array.isArray(st.lines) || !Array.isArray(st.results) || st.lines.length !== st.results.length) return;
    loadRows(st.lines);
    // 保存済みの結果を戻す（URL不正の行は loadRows で付与済み）
    st.results.forEach((r, i) => {
      if (r && typeof r.l === "string" && !results[i]) results[i] = { l: r.l, d: String(r.d || ""), net: !!r.net, known: !!r.known };
    });
    recount();
    for (let i = 0; i < rows.length; i++) {
      const r = results[i];
      if (r && rows[i].href) doneByKey.set((rows[i].inferred ? "1|" : "0|") + rows[i].href, r);
    }
    $("input").value = st.lines.join("\n");
    updateButtons();
    renderProgress();
    showResumeNote();
  });
})();

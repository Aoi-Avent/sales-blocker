// options.js — ver 10

// content.js内のデフォルト除外フレーズと同一（除外フレーズ一覧表示用）
const DEFAULT_EXCLUDED_PHRASES = [
  "営業時間", "営業受付時間", "営業所", "営業情報", "営業担当",
  "営業日中", "営業日", "年末年始の営業",
  "営業しております", "営業しています",
  "セールスエンジニア",
];

// content.js内のデフォルトカテゴリー別ワードと同一（カテゴリー別ワード一覧表示用）
const DEFAULT_EIGYO_CATEGORY_WORDS = [
  "営業", "ご提案", "営業メール", "営業電話", "売り込み", "売りこみ", "うりこみ",
  "ご提案に関するメール", "営業を目的としたお問い合わせ", "お問い合わせフォームからのセールス",
  "セールス", "勧誘", "営業の電話", "サービス提案", "業者", "お客様以外のご利用",
  "広告の問い合わせ", "広告", "広告宣伝メール", "への営業は", "営業目的",
  "営利目的", "営利", "商用利用", "商用", "営業行為", "営業のご案内",
  "営業のご連絡", "営業関連", "営業活動", "宣伝", "宣伝行為",
  "不適切な宣伝行為", "フォームの利用", "フォーム",
];
const DEFAULT_KOTOWARI_CATEGORY_WORDS = [
  "ご対応は致しかねます", "ご対応はいたしかねます", "ご遠慮いただいております",
  "お断り", "おことわり", "お断りさせて", "遠慮", "ご遠慮", "ご遠慮下さい",
  "ご遠慮ください", "ご遠慮いただきますよう", "固くお断り", "固くおことわり",
  "返信いたしかねます", "お断りします", "返信致しかねます", "返信いたしません",
  "返信しておりません", "返信を行わない", "返信をしない", "固くお断りいたします",
  "お控え", "お控えください", "お控え下さい", "拒否致します",
];
const DEFAULT_INSTANT_ALERT_PHRASES = [
  "営業・ご提案のご連絡は、会社概要のメールよりお願いいたします",
  "業者等のご連絡はお断りさせていただきます", "業者等のご連絡はお断り",
  "営業権のご購入", "営業権", "への営業は専用窓口をご利用ください",
  "誠に恐れ入りますが、企業様からのお問い合わせは、こちらのフォームの利用はご遠慮ください",
  "営業お断り", "営業禁止",
  "このお問い合わせフォームでの特定電子メールの送信を拒否致します",
  "法第３条第１項[特定電子メールの送信の制限]に抵触しているのが確認された場合",
  "一般財団法人日本データ通信協会に迷惑メールとして情報提供しております。",
  "法第３条第１項", "特定電子メール法", "電子メール法", "メール法",
  "特定電子メール", "特定電子", "特定電子メールの送信の制限",
  "電子メール広告", "広告宣伝メール", "メールの送信の制限", "送信の制限",
];

const SPREADSHEET_URL = "https://script.google.com/macros/s/AKfycbxh-Us-sm5ZbJn6pfY079Bv0FFu9A6zBGupggoh0Horlwhew7kuhtcezkdXHUG0r10K/exec";
const SHEET_URL = "https://docs.google.com/spreadsheets/d/13TsZkazILYwR0tX60QRBlszroEdAfHEj02AhQdZdc9U/edit?usp=sharing";

const EXCLUDED_PHRASES_URL = "https://script.google.com/macros/s/AKfycbx3fGsHyGQ7kDX3qsl9g6-5WgQY9dqZbT30bMncQfMuAnZGZWVDQhiZqxGetnKKNPeI/exec";
const EXCLUDED_SHEET_URL = "https://docs.google.com/spreadsheets/d/1izX0eYIK2IBpJ2PyL1f_2j1tE0cOJ6uj0Xz8Fv1uvV0/edit?usp=sharing";

// TODO: 警告ダイアログ強化ワード用スプレッドシートのGAS URL・シートURLを設定してください
const CATEGORY_WORDS_URL = "https://script.google.com/macros/s/AKfycbwfKEoDI_FNXtnF1swGLeIreuuEAtm5TV6u5Aw2DJAl7DlysA_XdrFszoZm6hcQtbLx/exec";
const CATEGORY_SHEET_URL = "https://docs.google.com/spreadsheets/d/1QVLvXFNrRWHwjUDr3Vu-oupPvMeVBz_oyuM32U861Mw/edit?usp=sharing";

document.addEventListener("DOMContentLoaded", () => {
  // タブ切り替え
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".tab-content").forEach((c) => c.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById("tab-" + btn.dataset.tab).classList.add("active");
    });
  });

  renderStatus();
  setupDataTab();
  renderMasterAndFeatures();
  renderWordList();
  renderExcludedPhrasesList();
  renderCategoryWordsList();

  // スプレッドシートを開く
  // 常時表示パネルの透明度スライダー
  const transSlider = document.getElementById("panelTransSlider");
  const transVal = document.getElementById("panelTransVal");
  if (transSlider && transVal) {
    const showTrans = (v) => { transVal.textContent = `${v}%`; };
    getPanelTransparency((v) => { transSlider.value = String(v); showTrans(v); });
    transSlider.addEventListener("input", () => {
      const v = normalizePanelTransparency(transSlider.value);
      showTrans(v);
      setPanelTransparency(v);
    });
    // ポップアップ側で変更された場合も追従
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes.panelTransparency) {
        const v = normalizePanelTransparency(changes.panelTransparency.newValue);
        transSlider.value = String(v);
        showTrans(v);
      }
    });
  }

  // 単語の自動同期の間隔（高度な設定）。保存するとバックグラウンド側が自動で取り込み間隔を切り替える
  const syncSel = document.getElementById("syncIntervalSelect");
  if (syncSel) {
    const labelOf = (m) => (m < 60 ? `${m}分ごと` : m % 60 === 0 && m < 1440 ? `${m / 60}時間ごと` : "1日ごと") + (m === SYNC_INTERVAL_DEFAULT ? "（標準）" : "");
    SYNC_INTERVAL_CHOICES.forEach((m) => {
      const opt = document.createElement("option");
      opt.value = String(m);
      opt.textContent = labelOf(m);
      syncSel.appendChild(opt);
    });
    const syncMsg = document.getElementById("syncIntervalMsg");
    getSyncInterval((m) => { syncSel.value = String(m); });
    syncSel.addEventListener("change", () => {
      setSyncInterval(syncSel.value, () => {
        syncMsg.textContent = "保存しました。";
        syncMsg.dataset.kind = "ok";
      });
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[SYNC_INTERVAL_KEY]) syncSel.value = String(normalizeSyncInterval(changes[SYNC_INTERVAL_KEY].newValue));
    });
  }

  document.getElementById("openSheetBtn")?.addEventListener("click", () => window.open(SHEET_URL, "_blank"));
  document.getElementById("openExcludedSheetBtn")?.addEventListener("click", () => window.open(EXCLUDED_SHEET_URL, "_blank"));
  document.getElementById("openCategorySheetBtn")?.addEventListener("click", () => {
    if (!CATEGORY_SHEET_URL) {
      alert("カテゴリー別ワード管理シートのURLがまだ設定されていません。");
      return;
    }
    window.open(CATEGORY_SHEET_URL, "_blank");
  });

  // ===== 同期（個別 / すべて）=====
  async function doSyncKeywords() {
    const response = await fetch(SPREADSHEET_URL);
    const keywords = await response.json();
    await chrome.storage.local.set({ storedKeywords: keywords, lastSyncAt: Date.now(), lastSyncError: null });
    renderWordList();
  }
  async function doSyncExcluded() {
    const response = await fetch(EXCLUDED_PHRASES_URL);
    const phrases = await response.json();
    await chrome.storage.local.set({ syncedExcludedPhrases: phrases, lastExcludedSyncAt: Date.now(), lastExcludedSyncError: null });
    renderExcludedPhrasesList();
  }
  async function doSyncCategory() {
    if (!CATEGORY_WORDS_URL) throw new Error("カテゴリー別ワード用スプレッドシートのURLが未設定です");
    const response = await fetch(CATEGORY_WORDS_URL);
    const data = await response.json();
    const syncedCategoryWords = {
      eigyo: Array.isArray(data?.eigyo) ? data.eigyo : [],
      kotowari: Array.isArray(data?.kotowari) ? data.kotowari : [],
      instant: Array.isArray(data?.instant) ? data.instant : [],
    };
    await chrome.storage.local.set({ syncedCategoryWords, lastCategorySyncAt: Date.now(), lastCategorySyncError: null });
    renderCategoryWordsList();
  }

  function bindSyncButton(btnId, idleLabel, job) {
    document.getElementById(btnId)?.addEventListener("click", async () => {
      const btn = document.getElementById(btnId);
      btn.textContent = "同期中...";
      btn.disabled = true;
      let ok = true;
      try {
        await job();
        btn.textContent = "同期完了";
      } catch (e) {
        ok = false;
        console.error("同期エラー:", e);
        btn.textContent = "同期失敗";
      }
      btn.disabled = false;
      renderStatus();
      setTimeout(() => (btn.textContent = idleLabel), ok ? 2000 : 3000);
    });
  }
  bindSyncButton("syncBtn", "キーワードを手動同期", doSyncKeywords);
  bindSyncButton("syncExcludedBtn", "除外フレーズを手動同期", doSyncExcluded);
  bindSyncButton("syncCategoryBtn", "カテゴリー別ワードを手動同期", doSyncCategory);

  // すべて同期（3種類を順番に実行。失敗した項目名は消えずに表示する）
  document.getElementById("syncAllBtn")?.addEventListener("click", async () => {
    const btn = document.getElementById("syncAllBtn");
    const msg = document.getElementById("syncAllMsg");
    btn.disabled = true;
    btn.textContent = "同期中...";
    msg.className = "sync-msg";
    msg.textContent = "";
    const jobs = [["キーワード", doSyncKeywords], ["除外フレーズ", doSyncExcluded], ["カテゴリー別ワード", doSyncCategory]];
    const failed = [];
    for (const [name, job] of jobs) {
      try { await job(); } catch (e) { console.error(name + "の同期エラー:", e); failed.push(name); }
    }
    btn.disabled = false;
    btn.textContent = "すべて同期";
    renderStatus();
    if (failed.length === 0) {
      msg.classList.add("ok");
      msg.textContent = "すべて同期しました";
    } else {
      msg.classList.add("ng");
      msg.textContent = "同期に失敗：" + failed.join("、") + "（通信状態を確認して、もう一度お試しください）";
    }
  });

  // キーワード追加
  document.getElementById("addBtn")?.addEventListener("click", () => {
    const input = document.getElementById("wordInput");
    const word = input.value.trim();
    if (!word) return;
    chrome.storage.local.get({ userKeywords: [] }, (data) => {
      if (data.userKeywords.some((u) => u.word === word)) {
        alert(`「${word}」はすでに登録されています。`);
        return;
      }
      data.userKeywords.push({ word, enabled: true });
      chrome.storage.local.set({ userKeywords: data.userKeywords }, () => {
        input.value = "";
        renderWordList();
        renderStatus();
      });
    });
  });

  document.getElementById("wordInput")?.addEventListener("keydown", (e) => {
    if (e.key === "Enter") document.getElementById("addBtn")?.click();
  });
});

// ===== オフにしたサイト一覧／バックアップ（ver9.13） =====
function setupDataTab() {
  const $ = (id) => document.getElementById(id);
  const badge = $("versionBadge");
  if (badge) badge.textContent = "ver " + chrome.runtime.getManifest().version;

  const fmt = (t) => (t ? new Date(t).toLocaleString("ja-JP") : "まだありません");
  const say = (el, text, ok) => { el.textContent = text; el.className = "sync-msg " + (ok ? "ok" : "ng"); };

  // --- ④ オフにしたいサイトの入力欄（ver10：一覧＋［削除］ボタンから、メモ帳風の入力欄に置き換え） ---
  // 保存・コピー・他タブでの変更の反映は共通モジュール disabledSitesEditor.js が行う
  const dsEditor = setupDisabledSitesEditor({
    textarea: $("disabledSitesText"),
    saveBtn: $("disabledSitesSaveBtn"),
    copyBtn: $("disabledSitesCopyBtn"),
    msg: $("disabledSitesMsg"),
    count: $("disabledSitesCount"),
  });
  const renderDisabledSites = () => dsEditor.refresh(true); // 読み込み・復元のあとは、入力中の内容より保存内容を優先して表示

  // --- ① ファイルの書き出し／読み込み ---
  $("exportBtn").addEventListener("click", async () => {
    const msg = $("backupFileMsg");
    try {
      const file = await buildBackupFile();
      const blob = new Blob([JSON.stringify(file, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      const d = new Date();
      const p = (n) => String(n).padStart(2, "0");
      a.href = URL.createObjectURL(blob);
      a.download = `salesban_settings_${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}.json`; // 英数字のみ（環境によって日本語名が落ちるため）
      a.hidden = true;
      document.body.appendChild(a); // 画面に付けてから押す（ブラウザによってはこうしないと保存されない）
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      say(msg, "書き出しました。", true);
    } catch (e) {
      say(msg, "書き出しに失敗しました：" + e, false);
    }
  });
  $("importBtn").addEventListener("click", () => $("importFile").click());
  $("importFile").addEventListener("change", async (e) => {
    const msg = $("backupFileMsg");
    const f = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!f) return;
    const res = parseBackupFile(await f.text());
    if (!res.ok) { say(msg, res.error, false); return; }
    const d = res.data;
    const lines = [];
    if (d.featureSettings) lines.push("・全体／機能ごとのON/OFF");
    if (d.disabledSites) lines.push(`・オフにしたサイト（${d.disabledSites.length}件）`);
    if (d.userKeywords) lines.push(`・ユーザー追加キーワード（${d.userKeywords.length}件）`);
    if (d.panelTransparency !== undefined) lines.push("・パネルの透明度");
    if (d.panelPosition) lines.push("・パネルの位置");
    if (d.bulkSettings) lines.push("・一括スキャンの設定");
    if (d.syncIntervalMinutes !== undefined) lines.push("・単語の自動同期の間隔");
    if (!confirm(`次の設定を、いまの設定に上書きして読み込みます。よろしいですか？\n\n${lines.join("\n")}`)) {
      say(msg, "読み込みを取りやめました。", false);
      return;
    }
    await applyBackupData(d);
    say(msg, "読み込みました。", true);
    renderDisabledSites();
    renderMasterAndFeatures();
    renderWordList();
    renderStatus();
    getPanelTransparency((v) => {
      const sl = $("panelTransSlider");
      if (sl) { sl.value = String(v); $("panelTransVal").textContent = `${v}%`; }
    });
  });

  // --- ② Chrome同期バックアップの状態表示・手動操作 ---
  const SKIP_LABEL = { featureSettings: "機能のON/OFF", disabledSites: "オフにしたサイト", userKeywords: "ユーザー追加キーワード", panelTransparency: "パネルの透明度", syncIntervalMinutes: "単語の同期の間隔" };
  function renderBackupMeta() {
    chrome.storage.local.get({ [BACKUP_META_KEY]: {} }, (data) => {
      const m = data[BACKUP_META_KEY] || {};
      $("syncBackupAt").textContent = m.error ? `失敗：${m.error}` : fmt(m.lastPushAt);
      $("syncRestoreAt").textContent = m.lastRestoreAt ? `${fmt(m.lastRestoreAt)}（${(m.restored || []).map((k) => SKIP_LABEL[k] || k).join("・")}）` : "まだありません";
      $("syncBackupSkipped").textContent = m.skipped && m.skipped.length ? m.skipped.map((k) => SKIP_LABEL[k] || k).join("・") + "（容量が大きすぎるため同期には入りません。ファイルの書き出しをご利用ください）" : "なし";
    });
  }
  $("extensionIdText").textContent = chrome.runtime.id;
  renderBackupMeta();
  $("syncPushBtn").addEventListener("click", async () => {
    const r = await pushLocalToSync();
    say($("syncBackupMsg"), r.ok ? "バックアップしました。" : "失敗しました：" + r.error, r.ok);
    renderBackupMeta();
  });
  $("syncRestoreBtn").addEventListener("click", async () => {
    if (!confirm("Chromeの同期にあるバックアップで、いまの設定を上書きします。よろしいですか？")) return;
    const r = await restoreFromSync(true);
    if (!r.ok) say($("syncBackupMsg"), "失敗しました：" + r.error, false);
    else if (!r.restored.length) say($("syncBackupMsg"), "同期にバックアップがありません。", false);
    else {
      say($("syncBackupMsg"), "復元しました。", true);
      renderDisabledSites();
      renderMasterAndFeatures();
      renderWordList();
      renderStatus();
    }
    renderBackupMeta();
  });

  // 他のタブ（常時パネルの［再開］など）での変更も一覧に反映
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[BACKUP_META_KEY]) renderBackupMeta();
  });
}

// ===== ステータス表示 =====
function renderStatus() {
  document.getElementById("versionText").textContent = chrome.runtime.getManifest().version;
  chrome.storage.local.get(
    { storedKeywords: [], userKeywords: [], lastSyncAt: null, lastExcludedSyncAt: null, lastCategorySyncAt: null },
    (data) => {
      document.getElementById("lastSyncText").textContent = data.lastSyncAt
        ? new Date(data.lastSyncAt).toLocaleString("ja-JP")
        : "未同期";
      document.getElementById("lastExcludedSyncText").textContent = data.lastExcludedSyncAt
        ? new Date(data.lastExcludedSyncAt).toLocaleString("ja-JP")
        : "未同期";
      document.getElementById("lastCategorySyncText").textContent = data.lastCategorySyncAt
        ? new Date(data.lastCategorySyncAt).toLocaleString("ja-JP")
        : "未同期";
      const enabledUser = (data.userKeywords || []).filter((u) => u.enabled !== false).length;
      document.getElementById("keywordCountText").textContent =
        `${(data.storedKeywords || []).length + enabledUser} 件（シート ${(data.storedKeywords || []).length} ＋ 独自 ${enabledUser}）`;

      // 1行サマリー（3種類のうち一番古い同期日時を表示。未同期があれば明示）
      const sumEl = document.getElementById("syncSummary");
      if (sumEl) {
        const times = [data.lastSyncAt, data.lastExcludedSyncAt, data.lastCategorySyncAt];
        const total = (data.storedKeywords || []).length + enabledUser;
        sumEl.textContent = times.some((t) => !t)
          ? `未同期の項目があります／登録キーワード ${total} 件`
          : `最終同期：${new Date(Math.min(...times)).toLocaleString("ja-JP")}／登録キーワード ${total} 件`;
      }
    }
  );
}

// ===== メイン・高度な設定レンダリング =====
function renderMasterAndFeatures() {
  getFeatureSettings((settings) => {
    const masterToggle = document.getElementById("masterToggle");
    masterToggle.checked = settings.master;
    masterToggle.addEventListener("change", () => {
      settings.master = masterToggle.checked;
      saveFeatureSettings(settings, () => updateFeatureRowsDisabled(settings.master));
    });

    const mainContainer = document.getElementById("mainFeatureCards");
    const advContainer = document.getElementById("advancedFeatureCards");
    mainContainer.innerHTML = "";
    advContainer.innerHTML = "";

    const mainCard = document.createElement("div");
    mainCard.className = "card";
    const advCard = document.createElement("div");
    advCard.className = "card";

    FEATURE_DEFS.forEach((f) => {
      const row = document.createElement("div");
      row.className = "feature-row";

      const textDiv = document.createElement("div");
      textDiv.className = "feature-text";
      const labelEl = document.createElement("div");
      labelEl.className = "label";
      labelEl.textContent = f.label;
      const descEl = document.createElement("div");
      descEl.className = "desc";
      descEl.textContent = f.desc;
      textDiv.appendChild(labelEl);
      textDiv.appendChild(descEl);

      const switchLabel = document.createElement("label");
      switchLabel.className = "switch";
      const input = document.createElement("input");
      input.type = "checkbox";
      input.checked = !!settings.features[f.id];
      input.disabled = !settings.master;
      input.dataset.featureId = f.id;
      input.addEventListener("change", () => {
        settings.features[f.id] = input.checked;
        saveFeatureSettings(settings);
      });
      const slider = document.createElement("span");
      slider.className = "slider";
      switchLabel.appendChild(input);
      switchLabel.appendChild(slider);

      row.appendChild(textDiv);
      row.appendChild(switchLabel);

      if (f.isAdvanced) {
        advCard.appendChild(row);
      } else {
        mainCard.appendChild(row);
      }
    });

    mainContainer.appendChild(mainCard);
    advContainer.appendChild(advCard);
  });
}

function updateFeatureRowsDisabled(masterOn) {
  document.querySelectorAll('.tab-content input[type="checkbox"]').forEach((el) => {
    el.disabled = !masterOn;
  });
}

// ===== キーワード一覧 =====
function renderWordList() {
  chrome.storage.local.get({ storedKeywords: [], userKeywords: [], syncedExcludedPhrases: [] }, (data) => {
    const wordList = document.getElementById("wordList");
    wordList.innerHTML = "";

    if (data.storedKeywords?.length > 0) {
      const h3 = document.createElement("h3");
      h3.textContent = `同期済みキーワード（${data.storedKeywords.length} 件）`;
      wordList.appendChild(h3);
      data.storedKeywords.forEach((word, index) => {
        const li = document.createElement("li");
        li.innerHTML = `<span>${index + 1}. ${escapeHtml(word)}</span><span class="tag-auto">シート同期</span>`;
        wordList.appendChild(li);
      });
    }

    const h3User = document.createElement("h3");
    h3User.textContent = `独自追加キーワード（${(data.userKeywords || []).length} 件）`;
    wordList.appendChild(h3User);

    if (!data.userKeywords || data.userKeywords.length === 0) {
      const note = document.createElement("div");
      note.className = "empty-note";
      note.textContent = "独自追加キーワードはありません。";
      wordList.appendChild(note);
      return;
    }

    data.userKeywords.forEach((item, index) => {
      const li = document.createElement("li");

      const leftDiv = document.createElement("div");
      leftDiv.style.cssText = "display:flex;align-items:center;gap:8px;flex:1;";
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = item.enabled !== false;
      checkbox.addEventListener("change", () => toggleWord(index, checkbox.checked));
      const textSpan = document.createElement("span");
      textSpan.textContent = item.word;
      if (!item.enabled) textSpan.style.textDecoration = "line-through";
      leftDiv.appendChild(checkbox);
      leftDiv.appendChild(textSpan);

      const rightDiv = document.createElement("div");
      rightDiv.style.cssText = "display:flex;gap:4px;flex-shrink:0;";

      const delBtn = document.createElement("button");
      delBtn.className = "secondary danger-btn";
      delBtn.textContent = "削除";
      delBtn.addEventListener("click", () => {
        if (confirm(`「${item.word}」を削除しますか？`)) deleteWord(index);
      });

      rightDiv.appendChild(delBtn);
      li.appendChild(leftDiv);
      li.appendChild(rightDiv);
      wordList.appendChild(li);
    });
  });
}

// ===== 除外フレーズ一覧 =====
function renderExcludedPhrasesList() {
  chrome.storage.local.get({ syncedExcludedPhrases: [] }, (data) => {
    const listEl = document.getElementById("excludedPhrasesList");
    if (!listEl) return;
    listEl.innerHTML = "";

    const h3Default = document.createElement("h3");
    h3Default.textContent = `内蔵の除外フレーズ（${DEFAULT_EXCLUDED_PHRASES.length} 件）`;
    listEl.appendChild(h3Default);
    DEFAULT_EXCLUDED_PHRASES.forEach((phrase, index) => {
      const li = document.createElement("li");
      li.innerHTML = `<span>${index + 1}. ${escapeHtml(phrase)}</span><span class="tag-auto">内蔵</span>`;
      listEl.appendChild(li);
    });

    const synced = data.syncedExcludedPhrases || [];
    const h3Synced = document.createElement("h3");
    h3Synced.textContent = `シート同期の除外フレーズ（${synced.length} 件）`;
    listEl.appendChild(h3Synced);

    if (synced.length === 0) {
      const note = document.createElement("div");
      note.className = "empty-note";
      note.textContent = "シートから同期された除外フレーズはありません。";
      listEl.appendChild(note);
      return;
    }

    synced.forEach((phrase, index) => {
      const li = document.createElement("li");
      li.innerHTML = `<span>${index + 1}. ${escapeHtml(phrase)}</span><span class="tag-auto">シート同期</span>`;
      listEl.appendChild(li);
    });
  });
}

// ===== カテゴリー別ワード一覧（営業/禁止・お断り/一発アウト） =====
function renderCategoryWordsList() {
  chrome.storage.local.get(
    { syncedCategoryWords: { eigyo: [], kotowari: [], instant: [] } },
    (data) => {
      const synced = data.syncedCategoryWords || {};
      renderOneCategoryList("eigyoWordsList", DEFAULT_EIGYO_CATEGORY_WORDS, synced.eigyo || []);
      renderOneCategoryList("kotowariWordsList", DEFAULT_KOTOWARI_CATEGORY_WORDS, synced.kotowari || []);
      renderOneCategoryList("instantWordsList", DEFAULT_INSTANT_ALERT_PHRASES, synced.instant || []);
    }
  );
}

function renderOneCategoryList(elementId, defaultWords, syncedWords) {
  const listEl = document.getElementById(elementId);
  if (!listEl) return;
  listEl.innerHTML = "";

  const h3Default = document.createElement("h3");
  h3Default.textContent = `内蔵ワード（${defaultWords.length} 件）`;
  listEl.appendChild(h3Default);
  defaultWords.forEach((word, index) => {
    const li = document.createElement("li");
    li.innerHTML = `<span>${index + 1}. ${escapeHtml(word)}</span><span class="tag-auto">内蔵</span>`;
    listEl.appendChild(li);
  });

  const h3Synced = document.createElement("h3");
  h3Synced.textContent = `シート同期ワード（${syncedWords.length} 件）`;
  listEl.appendChild(h3Synced);

  if (syncedWords.length === 0) {
    const note = document.createElement("div");
    note.className = "empty-note";
    note.textContent = "シートから同期されたワードはありません。";
    listEl.appendChild(note);
    return;
  }

  syncedWords.forEach((word, index) => {
    const li = document.createElement("li");
    li.innerHTML = `<span>${index + 1}. ${escapeHtml(word)}</span><span class="tag-auto">シート同期</span>`;
    listEl.appendChild(li);
  });
}

function toggleWord(index, enabled) {
  chrome.storage.local.get({ userKeywords: [] }, (data) => {
    data.userKeywords[index].enabled = enabled;
    chrome.storage.local.set({ userKeywords: data.userKeywords }, renderWordList);
  });
}

function deleteWord(index) {
  chrome.storage.local.get({ userKeywords: [] }, (data) => {
    data.userKeywords.splice(index, 1);
    chrome.storage.local.set({ userKeywords: data.userKeywords }, () => {
      renderWordList();
      renderStatus();
    });
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}

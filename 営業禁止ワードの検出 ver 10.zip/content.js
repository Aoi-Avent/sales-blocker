(() => {
  // ===== 内蔵デフォルトワード =====
  const DEFAULT_KEYWORDS = [
    // --- 直接的な禁止表現 ---
    "営業お断り", "営業禁止", "営業はお断り", "営業目的のお断り",
    "セールスお断り", "勧誘お断り",
    "お断りしております", "お断りいたします", "お断りします",
    "お受けしておりません", "お受けできません", "受け付けておりません",
    "ご遠慮ください", "ご遠慮いただいております", "ご遠慮願います",
    "固くお断り", "固くお断りしております",

    // --- 業態別表現 ---
    "営業電話", "営業のお電話", "営業のお電話はお断り",
    "テレアポ", "テレアポお断り",
    "飛び込み営業", "訪問販売",
    "営業メール", "営業メールはお断り",
    "セールスメール", "ダイレクトメール",
    "営業のご連絡", "営業のご案内", "営業のご訪問",

    // --- 用途・目的の限定 ---
    "営業目的", "営業目的の問い合わせ", "営業目的のご連絡",
    "営利目的", "営利目的の問い合わせ",
    "商用利用", "商用", "商業目的",

    // --- 行為の禁止 ---
    "営業行為", "営業活動", "勧誘行為", "勧誘", "売り込み", "売りこみ",

    // --- 一般的な断り表現 ---
    "おことわり", "お断り",

    // --- 英語 ---
    "no sales", "no solicitation", "no cold calls", "no telemarketing",
    "sales prohibited", "solicitation prohibited",
    "do not contact", "no marketing", "no commercial",
    "unsolicited", "business inquiries only",

    // --- ここから ver8.31 追加分（警告ダイアログ強化） ---
    // 「営業」カテゴリ追加ワード
    "ご提案", "うりこみ", "ご提案に関するメール", "営業を目的としたお問い合わせ",
    "お問い合わせフォームからのセールス", "セールス", "営業の電話", "サービス提案",
    "業者", "お客様以外のご利用", "広告の問い合わせ", "広告", "広告宣伝メール",
    "への営業は", "営利目的", "営利", "営業関連", "宣伝", "宣伝行為",
    "不適切な宣伝行為", "フォームの利用", "フォーム",

    // 「禁止・お断り」カテゴリ追加ワード
    "ご対応は致しかねます", "ご対応はいたしかねます", "ご遠慮いただいております",
    "お断りさせて", "遠慮", "ご遠慮", "ご遠慮下さい", "ご遠慮いただきますよう",
    "固くおことわり", "返信いたしかねます", "返信致しかねます", "返信いたしません",
    "返信しておりません", "返信を行わない", "返信をしない", "固くお断りいたします",
    "お控え", "お控えください", "お控え下さい", "拒否致します",

    // 組み合わせ不要・単体で警告する表現（一発アウト）
    "営業・ご提案のご連絡は、会社概要のメールよりお願いいたします",
    "業者等のご連絡はお断りさせていただきます", "業者等のご連絡はお断り",
    "営業権のご購入", "営業権", "への営業は専用窓口をご利用ください",
    "誠に恐れ入りますが、企業様からのお問い合わせは、こちらのフォームの利用はご遠慮ください",
    "このお問い合わせフォームでの特定電子メールの送信を拒否致します",
    "法第３条第１項[特定電子メールの送信の制限]に抵触しているのが確認された場合",
    "一般財団法人日本データ通信協会に迷惑メールとして情報提供しております。",
    "法第３条第１項", "特定電子メール法", "電子メール法", "メール法",
    "特定電子メール", "特定電子", "特定電子メールの送信の制限",
    "電子メール広告", "メールの送信の制限", "送信の制限",
  ];

  // 「営業」カテゴリ（組み合わせ警告の判定に使用。ハイライトはDEFAULT_KEYWORDS側で行う）
  let EIGYO_CATEGORY_WORDS = [
    "営業", "ご提案", "営業メール", "営業電話", "売り込み", "売りこみ", "うりこみ",
    "ご提案に関するメール", "営業を目的としたお問い合わせ", "お問い合わせフォームからのセールス",
    "セールス", "勧誘", "営業の電話", "サービス提案", "業者", "お客様以外のご利用",
    "広告の問い合わせ", "広告", "広告宣伝メール", "への営業は", "営業目的",
    "営利目的", "営利", "商用利用", "商用", "営業行為", "営業のご案内",
    "営業のご連絡", "営業関連", "営業活動", "宣伝", "宣伝行為",
    "不適切な宣伝行為", "フォームの利用", "フォーム",
  ];

  // 「禁止・お断り」カテゴリ（組み合わせ警告の判定に使用）
  let KOTOWARI_CATEGORY_WORDS = [
    "ご対応は致しかねます", "ご対応はいたしかねます", "ご遠慮いただいております",
    "お断り", "おことわり", "お断りさせて", "遠慮", "ご遠慮", "ご遠慮下さい",
    "ご遠慮ください", "ご遠慮いただきますよう", "固くお断り", "固くおことわり",
    "返信いたしかねます", "お断りします", "返信致しかねます", "返信いたしません",
    "返信しておりません", "返信を行わない", "返信をしない", "固くお断りいたします",
    "お控え", "お控えください", "お控え下さい", "拒否致します",
  ];

  // 組み合わせ不要・この語だけで即警告するフレーズ（一発アウト）
  let INSTANT_ALERT_PHRASES = [
    "営業・ご提案のご連絡は、会社概要のメールよりお願いいたします",
    "業者等のご連絡はお断りさせていただきます", "業者等のご連絡はお断り",
    "営業権のご購入", "営業権", "への営業は専用窓口をご利用ください",
    "誠に恐れ入りますが、企業様からのお問い合わせは、こちらのフォームの利用はご遠慮ください",
    "営業お断り", "営業禁止",
    "このお問い合わせフォームでの特定電子メールの送信を拒否致します",
    "法第３条第１項[特定電子メールの送信の制限]に抵触しているのが確認された場合",
    "一般財団法人日本データ通信協会に迷惑メールとして情報提供しております。",
    "法第３条第１項", "特定電子メール法", "電子メール法", "メール法",
    "特定電子メール", "特定電子", "特定電子メールの送信の制限",
    "電子メール広告", "広告宣伝メール", "メールの送信の制限", "送信の制限",
  ];

  // 除外フレーズリスト（「営業時間」「営業所」等、営業禁止と無関係な表現を誤検知しないための完全一致除外）
  const DEFAULT_EXCLUDED_PHRASES = [
    "営業時間", "営業受付時間", "営業所", "営業情報", "営業担当",
    "営業日中", "営業日", "年末年始の営業",
    "営業しております", "営業しています",
    "セールスエンジニア",
  ];
  let EXCLUDED_PHRASES = [...DEFAULT_EXCLUDED_PHRASES];

  function computeExcludedRanges(text) {
    const ranges = [];
    // text は呼び出し側で NFKC 正規化済み。除外フレーズ側も正規化して比較する
    for (const raw of EXCLUDED_PHRASES) {
      const phrase = nfkc(raw);
      if (!phrase) continue;
      let idx = text.indexOf(phrase);
      while (idx !== -1) {
        ranges.push([idx, idx + phrase.length]);
        idx = text.indexOf(phrase, idx + 1);
      }
    }
    return ranges;
  }

  function isRangeExcluded(start, end, excludedRanges) {
    return excludedRanges.some(([exStart, exEnd]) => start >= exStart && end <= exEnd);
  }

  // 除外タグ
  const EXCLUDE_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "META", "TITLE", "LINK", "DIALOG"]);
  const MARK_CLASS = "salesban-highlight";
  const MARK_ATTR = "data-sbh-done";
  const OCR_DONE_ATTR = "data-sbh-ocr-done";
  const BATCH_LIMIT = 2000;
  const OCR_MAX_IMAGES_PER_PAGE = 30; // ver9.2: 15→30（画像が多いページで末尾の画像が読まれない問題の対策）

  // 自作UI要素の除外セレクタ（二重検出・無限ループ防止）
  function isOurUiElement(node) {
    if (!node) return false;
    const el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    if (!el) return false;
    return !!el.closest(
      "#salesban-banner, #salesban-onpage-panel, .salesban-ocr-badge, .salesban-ocr-wrapper, .salesban-dialog, .salesban-occurrence-badge, #salesban-off-notice, #salesban-scrollcheck-toast, #salesban-notice-card"
    );
  }

  // ===== Tampermonkey「Domain Blocker」との干渉対策（ver9.9） =====
  // Domain Blocker は他事業所のスタッフが作った自動更新のスクリプトで、こちらからは変更できない。本拡張の側だけで対応する。
  // 自作UI（isOurUiElement）とは役割が違う（自作UI＝二重検出・無限ループ防止／こちら＝他人のスクリプトの表示を見ない）ため、別の関数にしている。
  // 【除外するもの】Domain Blocker の2つの全画面表示（#block-notification-overlay／#full-page-block-overlay）とその子孫
  // 【除外しないもの】.text-blocked ……これは Domain Blocker が「営業禁止の語を含む元ページの要素」に付けるクラス。
  //   除外すると、本拡張が本来の検出対象（元ページの文言）まで見逃してしまうため、あえて対象にしていない。
  const FOREIGN_BLOCKER_WORD_OVERLAY_ID = "block-notification-overlay";
  const FOREIGN_BLOCKER_FULLPAGE_OVERLAY_ID = "full-page-block-overlay";

  // ★切り替えスイッチ（ここ1か所）
  //   true : Domain Blocker の全画面表示が出ている間は、警告ダイアログ・バナー・トーストを出さない（常時パネルは出したまま）
  //   false: 従来どおり（全画面表示の有無に関係なく出す）
  const SUPPRESS_ALERTS_WHILE_FOREIGN_BLOCKER_SHOWS = true;

  function isForeignBlockerElement(node) {
    if (!node) return false;
    const el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    if (!el) return false;
    // 速い判定：そのノードのドキュメントに2つのidがどちらも無ければ該当しない（Domain Blockerが無いページでは closest を呼ばない。古いPC対策）
    const doc = el.ownerDocument;
    if (!doc || (!doc.getElementById(FOREIGN_BLOCKER_WORD_OVERLAY_ID) && !doc.getElementById(FOREIGN_BLOCKER_FULLPAGE_OVERLAY_ID))) return false;
    return !!el.closest(`#${FOREIGN_BLOCKER_WORD_OVERLAY_ID}, #${FOREIGN_BLOCKER_FULLPAGE_OVERLAY_ID}`);
  }

  // Domain Blocker の全画面表示が出ているか（#full-page-block-overlay がある／#block-notification-overlay が display:none 以外）
  function isForeignBlockerShowing() {
    if (document.getElementById(FOREIGN_BLOCKER_FULLPAGE_OVERLAY_ID)) return true;
    const wordOverlay = document.getElementById(FOREIGN_BLOCKER_WORD_OVERLAY_ID);
    if (!wordOverlay) return false;
    try {
      return getComputedStyle(wordOverlay).display !== "none";
    } catch (_e) {
      return false;
    }
  }

  // 警告ダイアログ・バナー・トーストを出さない状態か（フラグ＋全画面表示の有無）
  function shouldSuppressAlerts() {
    return SUPPRESS_ALERTS_WHILE_FOREIGN_BLOCKER_SHOWS && isForeignBlockerShowing();
  }

  // ===== 全体スイッチがオフのときの「オフだけど大丈夫？」通知（ver9.14） =====
  // 全体スイッチ（featureSettings.master）がオフのときは検出・OCR・先読みを一切動かさない（従来どおり）。
  // 代わりに、うっかりオフのまま使い続けないよう、画面の下端付近に1行の小さな通知だけを出す。
  // ★切り替えスイッチ（ここ1か所）  true: 通知を出す／false: 従来どおり何も出さない
  const SHOW_OFF_NOTICE = true;
  const OFF_NOTICE_ID = "salesban-off-notice"; // isOurUiElement の除外に登録済み
  let offNoticeEl = null;

  function showMasterOffNotice() {
    if (!SHOW_OFF_NOTICE || !IS_TOP || offNoticeEl) return; // 最上位ページだけ（iframeの中には出さない）
    if (shouldSuppressAlerts()) return;                      // Domain Blocker の全画面表示中は出さない（既存の判定）
    if (!document.documentElement) return;

    const box = document.createElement("div");
    box.id = OFF_NOTICE_ID;
    const text = document.createElement("span");
    text.className = "salesban-off-notice-text";
    text.textContent = "検出がオフです。営業禁止のサイトでも警告は出ません";
    const on = document.createElement("button");
    on.type = "button";
    on.className = "salesban-off-notice-on";
    on.textContent = "オンにする";
    const close = document.createElement("button");
    close.type = "button";
    close.className = "salesban-off-notice-close";
    close.setAttribute("aria-label", "閉じる");
    close.textContent = "×";
    box.append(text, on, close);

    // 閉じる：このタブ・このページだけ（保存しない。再読み込みするとまた出る）
    const remove = () => {
      try { chrome.storage.onChanged.removeListener(onSettingsChanged); } catch (_e) { /* 無視 */ }
      box.remove();
      offNoticeEl = null;
    };
    close.addEventListener("click", remove);

    // ［オンにする］：全体スイッチをオンにして保存。ページの検出はここでは始めず、再読み込みの案内を出す
    on.addEventListener("click", () => {
      on.disabled = true;
      try {
        getFeatureSettings((s) => {
          s.master = true;
          saveFeatureSettings(s, () => { void chrome.runtime.lastError; });
        });
      } catch (_e) {
        text.textContent = "オンにできませんでした。拡張機能のアイコンからオンにしてください";
        on.disabled = false;
      }
    });

    // 他の場所（ポップアップ・設定画面）でオンにされた時も、再読み込みの案内に切り替える
    function onSettingsChanged(changes, area) {
      if (area !== "local" || !changes.featureSettings) return;
      const nv = changes.featureSettings.newValue;
      if (nv && nv.master === true) {
        text.textContent = "オンにしました。ページを再読み込みすると検出が始まります";
        on.remove();
      }
    }
    chrome.storage.onChanged.addListener(onSettingsChanged);

    document.documentElement.appendChild(box);
    offNoticeEl = box;
  }

  // ===== 一時停止（ver9.11） =====
  // 保存するのは「いつまで停止か」（pausedUntil：ミリ秒）だけ。残り時間は使うたびに現在時刻と比べて求める（alarms は使わない）。
  // ポップアップの全体ON/OFF（featureSettings.master）とは別の仕組み。master は一切触らない。
  // 止めるもの：新しい検出（監視・OCR・サイト先読み）と、割り込み表示（警告ダイアログ・上部バナー・他ページ確認ダイアログ・トースト）
  // 止めないもの：送信完了ページの先読みチェック（runThanksPagePrecheck／showThanksPrecheckDialog）
  //   ※この版には compose-guard.js は無い。「送信前のチェック」に当たるのは上記の送信完了ページ先読みのみ。
  const PAUSE_UNDO_MS = 5000;
  let pausedUntil = 0;
  let pauseUndo = null; // { until, label }：「元に戻す」を出している間だけ。クリックしたタブの中だけで持つ
  let lastPausedState = false;
  let pauseTicker = null;

  function normalizePausedUntil(v) {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? n : 0;
  }
  function isPaused() {
    // 設定画面の「一時停止ボタンを表示」がオフなら、保存されている期限があっても停止として扱わない
    return isFeat("panelPause") && pausedUntil > Date.now();
  }

  // ===== このサイトで検出をオフ（ver9.12） =====
  // ドメイン単位（www. を除いたホスト名）で chrome.storage.local の disabledSites（配列）に保存する。期限は無く、［再開］で外す。
  // 止める範囲は一時停止と同じ（検出・OCR・先読み・割り込み表示）。送信完了ページの先読みチェックは止めない。
  let disabledSites = [];
  let siteOffConfirming = false; // パネル内の2段階確認の途中か
  let lastSiteOff = false;       // 直前の「このサイトはオフ」状態（オフになった瞬間にパネルを折りたたむ判定用）
  function normalizeDisabledSites(v) {
    return Array.isArray(v) ? [...new Set(v.filter((x) => typeof x === "string" && x))] : [];
  }
  function currentSiteKey() {
    let host = location.hostname;
    if (!IS_TOP) {
      // iframe の中では、最上位ページのドメインで判定する（フォームの埋め込み先でも「このサイト」と同じ扱いにする）
      try {
        const o = location.ancestorOrigins;
        if (o && o.length) host = new URL(o[o.length - 1]).hostname;
      } catch (_e) { /* 自分のホスト名で判定 */ }
    }
    return String(host || "").toLowerCase().replace(/^www\./, "");
  }
  function isSiteOff() {
    const key = currentSiteKey();
    return !!key && disabledSites.includes(key);
  }
  // 検出を止めている状態か（一時停止中 or このサイトはオフ）。各所の「止める」判定はこちらを使う
  function isHalted() {
    return isPaused() || isSiteOff();
  }
  // 割り込み表示を出さない状態か（Domain Blocker の全画面表示中 ＋ 一時停止中）
  function shouldSuppressInterrupts() {
    return shouldSuppressAlerts() || isHalted();
  }
  function formatPauseRemaining(ms) {
    const mins = Math.max(1, Math.ceil(ms / 60000));
    if (mins < 60) return `${mins}分`;
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return m ? `${h}時間${m}分` : `${h}時間`;
  }

  let queue = new Set();
  let scheduled = false;

  let settings = null;
  let ALL_WORDS = [];
  let COMBINED_REGEX = null;
  let totalDetections = 0;
  let ocrDetectionsCount = 0;
  const detectedSamples = [];
  let isOcrRunning = false;

  // ===== 常時表示パネル用の状態 =====
  const wordRegistry = new Map();
  const panelCycleIndex = new Map();
  const currentOccurrenceByKey = new Map();
  let firstFlushDone = false;
  let panelCollapsed = false;

  // ===== フレーム（iframe）連携 =====
  // 別ドメインのiframe内（外部フォームサービス等）は親ページから中身を読めないため、
  // 各フレームでも本スクリプトを動かして検出し、結果を postMessage で親へ集約する。
  // UI（パネル・警告ダイアログ・バナー）とOCR・サイト全体スキャンは最上位フレームのみ。
  const IS_TOP = window === window.top;
  const frameReports = new Map(); // iframe要素 → { 単語: 件数 }
  const frameJumpCycle = new Map();
  let lastPostedSig = null;

  function ownWordCounts() {
    const o = {};
    for (const [w, arr] of wordRegistry.entries()) if (arr.length) o[w] = arr.length;
    return o;
  }

  function frameWordCounts() {
    const m = new Map();
    for (const words of frameReports.values()) {
      for (const [w, c] of Object.entries(words)) m.set(w, (m.get(w) || 0) + c);
    }
    return m;
  }

  function frameDetectionTotal() {
    let n = 0;
    for (const c of frameWordCounts().values()) n += c;
    return n;
  }

  function getTotalDetections() {
    return totalDetections + frameDetectionTotal();
  }

  function postDetectionsToParent() {
    if (IS_TOP) return;
    const merged = ownWordCounts();
    for (const [w, c] of frameWordCounts()) merged[w] = (merged[w] || 0) + c;
    const sig = JSON.stringify(merged);
    if (sig === lastPostedSig) return;
    if (sig === "{}" && lastPostedSig === null) return;
    lastPostedSig = sig;
    try {
      window.parent.postMessage({ __salesban: 1, type: "frame-detect", words: merged }, "*");
    } catch (_e) {}
  }

  function sanitizeWords(obj) {
    const out = {};
    if (!obj || typeof obj !== "object") return out;
    let n = 0;
    for (const [w, c] of Object.entries(obj)) {
      if (n >= 100) break;
      if (typeof w !== "string" || w.length > 200) continue;
      if (!Number.isInteger(c) || c < 1 || c > 10000) continue;
      out[w] = c;
      n++;
    }
    return out;
  }

  function findFrameElBySource(source) {
    for (const f of document.querySelectorAll("iframe, frame")) {
      try {
        if (f.contentWindow === source) return f;
      } catch (_e) {}
    }
    return null;
  }

  function pingChildFrames() {
    for (const f of document.querySelectorAll("iframe, frame")) {
      try {
        f.contentWindow?.postMessage({ __salesban: 1, type: "hello" }, "*");
      } catch (_e) {}
    }
  }

  // iframe内の検出箇所へ：iframe自体までスクロールし、中身のジャンプは子フレームに依頼
  function jumpToFrameOccurrence(word) {
    const candidates = [];
    for (const [el, words] of frameReports.entries()) {
      if (words[word] && el.isConnected) candidates.push(el);
    }
    if (candidates.length === 0) return false;
    const i = (frameJumpCycle.get(word) || 0) % candidates.length;
    frameJumpCycle.set(word, i + 1);
    const el = candidates[i];
    revealAncestors(el);
    revealInScrollContainers(el);
    fastScrollIntoView(el);
    setTimeout(() => {
      try {
        el.contentWindow?.postMessage({ __salesban: 1, type: "jump", word }, "*");
      } catch (_e) {}
    }, 300);
    return true;
  }

  window.addEventListener("message", (e) => {
    const d = e.data;
    if (!d || d.__salesban !== 1) return;
    if (d.type === "frame-detect") {
      const el = findFrameElBySource(e.source);
      if (!el) return;
      frameReports.set(el, sanitizeWords(d.words));
      if (IS_TOP) reportProgress();
      else postDetectionsToParent();
    } else if (!IS_TOP && e.source === window.parent) {
      if (d.type === "hello") {
        lastPostedSig = null;
        postDetectionsToParent();
        pingChildFrames();
      } else if (d.type === "jump" && typeof d.word === "string") {
        jumpToNextOccurrence(d.word);
      }
    }
  });

  function makeOccurrenceBadge() {
    const badge = document.createElement("span");
    badge.className = "salesban-occurrence-badge";
    return badge;
  }

  function registerDetectionElement(key, el, badgeHost) {
    if (!key || !el) return;
    let arr = wordRegistry.get(key);
    if (!arr) {
      arr = [];
      wordRegistry.set(key, arr);
    }
    const occurrenceNumber = arr.length + 1;
    const badge = makeOccurrenceBadge();
    badge.textContent = String(occurrenceNumber);
    if (badgeHost) badgeHost.appendChild(badge);

    arr.push({ el, badge, occurrenceNumber });
  }

  // ===== 全角半角などの表記ゆれ吸収（NFKC正規化） =====
  // 「Ｍ＆Ａ」「法第３条」「ｵｺﾄﾜﾘ」のような全角・半角・互換文字を同一視して検出する。
  // 正規化で文字数が変わる（例: ㈱→(株)、ｶﾞ→ガ）ため、検出位置は元の文字列の位置へ戻して返す。
  const nfkc = (s) => String(s).normalize("NFKC");

  // 1文字＋後続の結合文字/半角濁点を1単位として正規化し、正規化後の各位置が元の何文字目に当たるかを記録する
  function normalizeWithMap(text) {
    const norm = nfkc(text);
    if (norm === text) return { norm, identity: true };

    const unitRe = /[\s\S][\u3099\u309A\uFF9E\uFF9F\u0300-\u036F]*/gu;
    let out = "";
    const starts = []; // 正規化後の i 文字目 → 元文字列での単位の開始位置
    const ends = [];   // 正規化後の i 文字目 → 元文字列での単位の終了位置
    let m;
    while ((m = unitRe.exec(text)) !== null) {
      const piece = nfkc(m[0]);
      for (let k = 0; k < piece.length; k++) {
        starts.push(m.index);
        ends.push(m.index + m[0].length);
      }
      out += piece;
    }
    return { norm: out, identity: false, starts, ends };
  }

  // 正規化後の範囲 [s, e) を元の文字列の範囲へ戻す
  function mapRangeToOriginal(info, s, e) {
    if (info.identity) return [s, e];
    const os = info.starts[s];
    const oe = info.ends[Math.max(s, e - 1)];
    return [os, oe];
  }

  const escapeRegex = (w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  function buildCombinedRegex(wordList) {
    const uniq0 = [...new Set(wordList.map((w) => nfkc(w).trim()).filter(Boolean))];
    if (uniq0.length === 0) return null;
    // 正規表現の「|」は先に書いた語が優先されるため、長い語を先に並べる。
    // 並べ替えないと「営業」が先に当たって「営業に関するお問い合わせはご遠慮ください」のような
    // 長いフレーズが全体として検出されない（一発アウトワードが効かなくなる）。同じ長さは登録順を維持。
    const uniq = uniq0
      .map((w, i) => ({ w, i }))
      .sort((a, b) => b.w.length - a.w.length || a.i - b.i)
      .map((x) => x.w);
    const pattern = uniq.map(escapeRegex).join("|");
    return new RegExp(`(${pattern})`, "gi");
  }

  function isFeat(id) {
    return isFeatureActive(settings, id);
  }

  // ===== ハイライト本体（テキストノード） =====
  function highlightTextNode(textNode) {
    if (!COMBINED_REGEX) return;
    if (isOurUiElement(textNode) || isForeignBlockerElement(textNode)) return;

    const text = textNode.nodeValue;
    if (!text || text.trim() === "") return;

    // 検出は NFKC 正規化後の文字列で行い、ハイライト位置は元のテキストへ戻す
    const info = normalizeWithMap(text);
    const ntext = info.norm;
    const excludedRanges = computeExcludedRanges(ntext);

    COMBINED_REGEX.lastIndex = 0;
    let m;
    const ranges = [];
    while ((m = COMBINED_REGEX.exec(ntext)) !== null) {
      const matchedText = m[0];
      const nStart = m.index;
      const nEnd = nStart + matchedText.length;

      if (!isRangeExcluded(nStart, nEnd, excludedRanges)) {
        const [start, end] = mapRangeToOriginal(info, nStart, nEnd);
        const prev = ranges[ranges.length - 1];
        if (!prev || start >= prev.end) ranges.push({ start, end, word: matchedText });
      }

      if (matchedText.length === 0) COMBINED_REGEX.lastIndex++;
    }

    if (ranges.length === 0) return;

    const frag = document.createDocumentFragment();
    let cursor = 0;
    for (const r of ranges) {
      if (r.start > cursor) frag.appendChild(document.createTextNode(text.slice(cursor, r.start)));
      const span = document.createElement("span");
      span.className = MARK_CLASS;
      span.textContent = text.slice(r.start, r.end);
      frag.appendChild(span);
      cursor = r.end;

      totalDetections++;
      if (detectedSamples.length < 50) detectedSamples.push(r.word);
      registerDetectionElement(r.word, span, span);
    }
    if (cursor < text.length) frag.appendChild(document.createTextNode(text.slice(cursor)));
    textNode.replaceWith(frag);
  }

  // ===== 入力欄のプレースホルダー（薄い案内文字）のスキャン =====
  // 「営業・セールスはご遠慮ください」のようにplaceholder属性に書かれた文言は
  // テキストノードではないため通常の走査では拾えない。入力欄そのものを検出対象として登録し、
  // 枠を赤く強調する（文字単位のハイライトはできない）。
  const PLACEHOLDER_MARK_ATTR = "data-salesban-ph";
  const PLACEHOLDER_CLASS = "salesban-placeholder-hit";

  function scanPlaceholders(root) {
    if (!COMBINED_REGEX) return;
    if (!(root instanceof Element) && !(root instanceof DocumentFragment)) return;

    const targets = [];
    if (root instanceof Element && root.matches("input[placeholder], textarea[placeholder]")) targets.push(root);
    targets.push(...root.querySelectorAll("input[placeholder], textarea[placeholder]"));

    for (const el of targets) {
      if (el.hasAttribute(PLACEHOLDER_MARK_ATTR)) continue;
      if (isOurUiElement(el) || isForeignBlockerElement(el)) continue;
      el.setAttribute(PLACEHOLDER_MARK_ATTR, "1");

      const text = el.getAttribute("placeholder") || "";
      if (!text.trim()) continue;

      const ntext = normalizeWithMap(text).norm;
      const excludedRanges = computeExcludedRanges(ntext);
      COMBINED_REGEX.lastIndex = 0;
      let m;
      let hit = false;
      while ((m = COMBINED_REGEX.exec(ntext)) !== null) {
        const start = m.index;
        const end = start + m[0].length;
        if (m[0].length === 0) COMBINED_REGEX.lastIndex++;
        if (isRangeExcluded(start, end, excludedRanges)) continue;

        hit = true;
        totalDetections++;
        if (detectedSamples.length < 50) detectedSamples.push(m[0]);
        registerDetectionElement(m[0], el, null);
      }
      if (hit) el.classList.add(PLACEHOLDER_CLASS);
    }
  }

  // ===== 画像 OCR スキャン =====
  function tryGetCanvasDataUrl(img) {
    try {
      const canvas = document.createElement("canvas");
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0);
      return canvas.toDataURL("image/png");
    } catch (_e) {
      return null;
    }
  }

  function collectTargetImages() {
    const images = Array.from(document.querySelectorAll("img"));
    const scoredImages = [];

    for (const img of images) {
      if (img.hasAttribute(OCR_DONE_ATTR)) continue;
      if (isOurUiElement(img) || isForeignBlockerElement(img)) continue;
      // ver9.2: まだ読み込み途中（遅延読み込み等）の画像は「処理済み」にせず、次回の走査に回す
      if (!img.complete || !img.naturalWidth) continue;

      const w = img.naturalWidth || img.width || img.clientWidth || 0;
      const h = img.naturalHeight || img.height || img.clientHeight || 0;

      if (w < 50 || h < 20) continue;
      if (w > 4000 || h > 4000) continue;

      let score = 0;
      if (img.closest("form, [class*='form'], [id*='form']")) score += 50;
      const contextText = (img.closest("section, div, article")?.className || "") + " " +
                          (img.alt || "") + " " + (img.src || "") + " " + (img.id || "");
      if (/contact|inquiry|form|warn|banner|notice|attention|otoiawase|info/i.test(contextText)) {
        score += 30;
      }
      if (w >= 120 && h >= 30 && w / h >= 1.5) score += 20;
      // ver9.4: 文字入りバナーは小さく横長なことが多い／大きな写真には読める文字が少なく、読むのに時間がかかる → 後回し
      if (w * h <= 150000) score += 10;
      if (w * h >= 600000) score -= 40;
      if (/\.jpe?g(\?|$)/i.test(img.currentSrc || img.src || "")) score -= 15;

      scoredImages.push({ img, score, src: img.currentSrc || img.src });
    }

    scoredImages.sort((a, b) => b.score - a.score);
    return scoredImages.slice(0, OCR_MAX_IMAGES_PER_PAGE).map((item) => item.img);
  }

  // 1枚の画像をOCRして判定する。stage: "fast"（まず最短で）／"deep"（念入りに）
  const ocrDataUrlCache = new Map();   // img → dataURL（段階をまたいで使い回し）
  const ocrResponseCache = new Map();  // `${stage}|${src}` → 応答（同じ画像が何度も出るページ用）

  function requestOcr(img, stage) {
    const src = img.currentSrc || img.src;
    const key = `${stage}|${src}`;
    if (ocrResponseCache.has(key)) return ocrResponseCache.get(key);

    let dataUrl = ocrDataUrlCache.get(img);
    if (dataUrl === undefined) {
      dataUrl = tryGetCanvasDataUrl(img);
      ocrDataUrlCache.set(img, dataUrl);
    }
    const p = new Promise((resolve) => {
      // 1枚の応答が返ってこなくても、後ろの画像が読まれなくならないようにタイムアウトを設ける
      const timer = setTimeout(() => resolve({ success: false, error: "timeout" }), 120000);
      try {
        chrome.runtime.sendMessage(
          { type: "requestImageOcr", imageUrl: src, imageData: dataUrl, stage },
          (res) => { clearTimeout(timer); void chrome.runtime.lastError; resolve(res); }
        );
      } catch (err) {
        clearTimeout(timer);
        resolve({ success: false, error: String(err) });
      }
    });
    ocrResponseCache.set(key, p);
    return p;
  }

  async function ocrOneImage(img, stage) {
    if (!img.isConnected) return;
    try {
      const response = await requestOcr(img, stage);
      if (response && response.success && response.text) {
        console.debug("[営業禁止ワード検出/OCR]", stage, img.currentSrc || img.src, `${img.naturalWidth}x${img.naturalHeight}`, `${response.passes || 1}回読み`, response.text.replace(/\s+/g, " ").slice(0, 80));
        analyzeOcrTextOnImage(img, response.text);
      } else {
        console.debug("[営業禁止ワード検出/OCR] 文字なし/失敗", stage, img.currentSrc || img.src, response && response.error);
      }
    } catch (err) {
      console.warn("OCR error for image:", err);
    }
  }

  // 同時に処理する枚数（読み取りエンジン側もPCの性能に合わせて並列に動く）
  const OCR_CONCURRENCY = 3;
  async function runOcrStage(images, stage) {
    let next = 0;
    const lanes = Math.min(OCR_CONCURRENCY, images.length);
    await Promise.all(Array.from({ length: lanes }, async () => {
      while (next < images.length) {
        const img = images[next++];
        await ocrOneImage(img, stage);
      }
    }));
  }

  // ページを開いた直後に、OCRエンジンの準備（モデルの読み込み）だけ先に済ませておく
  function warmupOcr() {
    if (!IS_TOP || !isFeat("ocrScan")) return;
    try { chrome.runtime.sendMessage({ type: "warmupOcr" }, () => void chrome.runtime.lastError); } catch (_e) { /* 無視 */ }
  }

  async function scanImagesWithOcr() {
    if (!IS_TOP) return;
    if (!isFeat("ocrScan") || !COMBINED_REGEX || isOcrRunning) return;
    if (isHalted()) return; // 一時停止中／このサイトはオフ：画像を読まない（再開時に kickoffDetection が改めて呼ぶ）
    isOcrRunning = true;

    try {
      const targetImages = collectTargetImages();
      if (targetImages.length === 0) return;
      targetImages.forEach((img) => img.setAttribute(OCR_DONE_ATTR, "1"));

      // ver9.4: 2段階。まず全画像を「最短の読み」で（ほとんどの画像はここで結果が出る）→ 続けて「念入りな読み」で取りこぼしを拾う。
      // 検出はどちらの段階でも見つかり次第すぐ画面に出る
      const t0 = performance.now();
      await runOcrStage(targetImages, "fast");
      const t1 = performance.now();
      await runOcrStage(targetImages, "deep");
      const t2 = performance.now();
      console.info(`[営業禁止ワード検出/OCR] 画像${targetImages.length}枚：最短の読み ${((t1 - t0) / 1000).toFixed(1)}秒／念入りな読み ${((t2 - t1) / 1000).toFixed(1)}秒`);
      ocrDataUrlCache.clear();
      ocrResponseCache.clear();
    } finally {
      isOcrRunning = false;
      reportProgress();
    }
  }

  const ocrSeenWords = new WeakMap(); // img → 検出済みの語（段階をまたいで同じ語を二重に数えない）

  function analyzeOcrTextOnImage(img, text) {
    if (!COMBINED_REGEX || !text) return;

    const ntext = normalizeWithMap(text).norm;
    const excludedRanges = computeExcludedRanges(ntext);
    COMBINED_REGEX.lastIndex = 0;
    const matchedWords = [];
    let m;
    while ((m = COMBINED_REGEX.exec(ntext)) !== null) {
      const matched = m[0];
      const start = m.index;
      const end = start + matched.length;

      if (!isRangeExcluded(start, end, excludedRanges)) {
        matchedWords.push(matched);
      }
      if (matched.length === 0) COMBINED_REGEX.lastIndex++;
    }

    if (matchedWords.length === 0) return;

    let seen = ocrSeenWords.get(img);
    if (!seen) { seen = new Set(); ocrSeenWords.set(img, seen); }
    const uniqueWords = [...new Set(matchedWords)].filter((w) => !seen.has(w));
    if (uniqueWords.length === 0) return;
    uniqueWords.forEach((w) => seen.add(w));

    totalDetections += uniqueWords.length;
    ocrDetectionsCount += uniqueWords.length;

    uniqueWords.forEach((w) => {
      const key = `【画像内】${w}`;
      detectedSamples.push(key);
    });

    img.classList.add("salesban-ocr-highlight");
    renderImageOcrBadge(img, uniqueWords, [...seen]);
  }

  function renderImageOcrBadge(img, newWords, allWords) {
    const existing = img.parentElement?.classList?.contains("salesban-ocr-wrapper") ? img.parentElement : null;
    if (existing) {
      // 2段階目で新しい語が見つかった場合：バッジの文言を更新し、新しい語だけ登録する
      const badge = existing.querySelector(".salesban-ocr-badge");
      if (badge) badge.textContent = `[画像内検出] 営業禁止ワード: 「${allWords.join("、")}」`;
      newWords.forEach((w) => registerDetectionElement(`【画像内】${w}`, img, existing));
      return;
    }

    const wrapper = document.createElement("div");
    wrapper.className = "salesban-ocr-wrapper";

    const badge = document.createElement("div");
    badge.className = "salesban-ocr-badge";
    badge.textContent = `[画像内検出] 営業禁止ワード: 「${allWords.join("、")}」`;

    if (img.parentNode) {
      img.parentNode.insertBefore(wrapper, img);
      wrapper.appendChild(badge);
      wrapper.appendChild(img);

      newWords.forEach((w) => {
        registerDetectionElement(`【画像内】${w}`, img, wrapper);
      });
    }
  }

  // ===== 走査（ShadowDOM / iframe 対応） =====
  // 以前は「1回の走査で2000ノードまで」で打ち切っており、長いページでは
  // 下の方（お問い合わせフォーム下部の規約ボックス等）が未スキャンのまま
  // 「スキャン済み」扱いになっていた。全ノードを先に集め、上限ごとに分割して
  // 最後まで処理する方式に変更。
  function collectTextNodes(root, out) {
    if (isOurUiElement(root) || isForeignBlockerElement(root)) return;

    if (root.nodeType === Node.TEXT_NODE) {
      if (!root.nodeValue || root.nodeValue.trim() === "") return;
      if (root.parentElement?.closest?.(`.${MARK_CLASS}`)) return;
      if (root.parentNode && EXCLUDE_TAGS.has(root.parentNode.nodeName)) return;
      out.push(root);
      return;
    }
    if (!(root instanceof Element) && !(root instanceof DocumentFragment)) return;
    if (root instanceof Element) {
      if (EXCLUDE_TAGS.has(root.nodeName)) return;
      if (root.classList?.contains(MARK_CLASS)) return;
    }

    for (const child of Array.from(root.childNodes)) collectTextNodes(child, out);

    if (isFeat("shadowDomScan") && root.shadowRoot) {
      for (const child of Array.from(root.shadowRoot.childNodes)) collectTextNodes(child, out);
    }
  }

  let pendingTextNodes = [];
  let drainScheduled = false;

  function highlightChunk(nodes) {
    for (const n of nodes) {
      if (n.isConnected) highlightTextNode(n);
    }
  }

  // 上限を超えた残りを、ページを固めないよう少しずつ処理する
  function drainPendingTextNodes() {
    drainScheduled = false;
    if (pendingTextNodes.length === 0) return;
    observer.disconnect();
    try {
      highlightChunk(pendingTextNodes.splice(0, BATCH_LIMIT));
      reportProgress();
    } finally {
      setTimeout(() => observer.observe(document.body, { childList: true, subtree: true }), 0);
    }
    if (pendingTextNodes.length > 0) scheduleDrain();
  }

  function scheduleDrain() {
    if (drainScheduled) return;
    drainScheduled = true;
    setTimeout(drainPendingTextNodes, 30);
  }

  function processElement(root) {
    if (!(root instanceof Element) && !(root instanceof DocumentFragment)) return;
    if (root instanceof Element && root.hasAttribute(MARK_ATTR)) return;
    if (isOurUiElement(root) || isForeignBlockerElement(root)) return;

    scanPlaceholders(root);

    const nodes = [];
    collectTextNodes(root, nodes);
    highlightChunk(nodes.splice(0, BATCH_LIMIT));
    if (nodes.length > 0) {
      pendingTextNodes.push(...nodes);
      scheduleDrain();
    }
    if (root instanceof Element) root.setAttribute(MARK_ATTR, "1");
  }

  function scanIframes() {
    if (!isFeat("iframeScan")) return;
    document.querySelectorAll("iframe").forEach((iframe) => {
      if (isOurUiElement(iframe) || isForeignBlockerElement(iframe)) return;
      try {
        const doc = iframe.contentDocument;
        if (!doc || !doc.body) return;
        processElement(doc.body);
      } catch (_e) {
        // 別ドメインiframe
      }
    });
  }

  // ===== バッチ実行 =====
  function flushQueue() {
    scheduled = false;
    observer.disconnect();
    try {
      const items = Array.from(queue);
      queue.clear();
      for (const el of items) processElement(el);
      scanIframes();
      firstFlushDone = true;
      reportProgress();

      if (isFeat("ocrScan") && isFeat("ocrAutoScan")) {
        setTimeout(scanImagesWithOcr, 400);
      }
    } finally {
      setTimeout(() => observer.observe(document.body, { childList: true, subtree: true }), 0);
    }
  }

  function scheduleEl(el) {
    if (el && el.isConnected && !isOurUiElement(el) && !isForeignBlockerElement(el)) queue.add(el);
    if (!scheduled) {
      scheduled = true;
      if (window.requestIdleCallback) {
        requestIdleCallback(flushQueue, { timeout: 200 });
      } else {
        setTimeout(flushQueue, 50);
      }
    }
  }

  // ===== 警告アラート（「一発アウト」フレーズ / 「営業」＋「お断り・禁止」の組み合わせ） =====
  let alertShown = false;
  const stripImagePrefix = (w) => (w.startsWith("【画像内】") ? w.slice(5) : w);

  function checkCombinationAlert() {
    if (!IS_TOP || !isFeat("comboAlertPopup") || alertShown) return;
    if (shouldSuppressInterrupts()) return; // Domain Blocker の全画面表示中／一時停止中は出さない（alertShown は立てない）
    const samples = [...detectedSamples, ...frameWordCounts().keys()];

    // ① 一発アウト：これ単体で検出されたら組み合わせ関係なく即警告
    const instantHit = samples.find((w) => INSTANT_ALERT_PHRASES.includes(stripImagePrefix(w)));
    if (instantHit) {
      requestAlertDialog({
        title: "営業禁止の可能性が高いページです",
        text: `「${escapeHtml(stripImagePrefix(instantHit))}」という決定的な表現が検出されました。<br>送信前に内容を必ずご確認ください。`,
        triggerWord: stripImagePrefix(instantHit),
      });
      return;
    }

    // ② 組み合わせ：「営業」系表現と「お断り/禁止」系表現の両方が検出されたら警告
    //    （既存の広い判定に加え、カテゴリ登録ワードとの完全一致も判定材料にする）
    const hasEigyo = samples.some((w) => {
      const bare = stripImagePrefix(w);
      return bare.includes("営業") || EIGYO_CATEGORY_WORDS.includes(bare);
    });
    const hasKotowari = samples.some((w) => {
      const bare = stripImagePrefix(w);
      return (
        bare.includes("お断り") ||
        bare.includes("おことわり") ||
        bare.includes("禁止") ||
        bare.includes("ご遠慮") ||
        KOTOWARI_CATEGORY_WORDS.includes(bare)
      );
    });

    if (hasEigyo && hasKotowari) {
      requestAlertDialog({
        title: "営業禁止の可能性が高いページです",
        text: "「営業」と「お断り／禁止」の両方の表現が検出されました。<br>送信前に内容を必ずご確認ください。",
        triggerWord: null,
      });
    }
  }

  // ===== 裏タブでの警告ダイアログの遅延表示（ver9.10） =====
  // 裏タブ（別のタブを見ている間）に検出しても警告ダイアログは出さず、そのタブが表示された時に出す。
  // alertShown は「依頼を受けた時点」で立てる（保留中に checkCombinationAlert が何度走っても二重に保留しない）。
  let pendingAlert = null;

  function requestAlertDialog(opts) {
    alertShown = true;
    if (document.visibilityState !== "visible") {
      pendingAlert = opts; // 表示された時に出す
      return;
    }
    showAlertDialog(opts);
  }

  function flushPendingAlert() {
    if (!pendingAlert || document.visibilityState !== "visible") return;
    const opts = pendingAlert;
    pendingAlert = null;
    if (shouldSuppressInterrupts()) {
      // 表示された時点で Domain Blocker の全画面表示が出ている／一時停止中なら、出さない。
      // 次の検出更新（reportProgress）でもう一度判定できるよう、alertShown を戻す。
      alertShown = false;
      return;
    }
    showAlertDialog(opts);
  }
  document.addEventListener("visibilitychange", flushPendingAlert);

  function showAlertDialog({ title, text, triggerWord, dialogId, noScroll }) {
    const dlgId = dialogId || "salesban-combo-dialog";
    document.getElementById(dlgId)?.remove();

    const dialog = document.createElement("dialog");
    dialog.id = dlgId;
    dialog.className = "salesban-dialog";

    dialog.innerHTML = `
      <div class="salesban-dialog-content">
        <div class="salesban-dialog-icon">[警告]</div>
        <div class="salesban-dialog-body">
          <h2 class="salesban-dialog-title">${escapeHtml(title)}</h2>
          <p class="salesban-dialog-text">${text}</p>
        </div>
      </div>
      <div class="salesban-dialog-actions">
        <button id="${dlgId}-close" class="salesban-dialog-btn">閉じる</button>
      </div>
    `;

    document.documentElement.appendChild(dialog);

    const closeBtn = dialog.querySelector(`#${dlgId}-close`);
    closeBtn.addEventListener("click", () => dialog.close());
    dialog.addEventListener("close", () => {
      dialog.remove();
      if (!noScroll) scrollToComboRelevantMatch(triggerWord);
    });

    try {
      dialog.showModal();
      closeBtn.focus();
    } catch (_e) {
      dialog.remove();
    }
  }

  // ===== 危険サイトリスト（スタッフからの注意喚起）（ver10.1 I） =====
  // 共通API（GAS）のシート「危険サイト」を、background.js が同期して chrome.storage.local の dangerList に持つ。
  // dangerList = { forms: { 正規化したURL: 理由 }, domains: { ドメイン: 理由 } }（キーで直接引けるので、数千件でも軽い）
  // 表示は既存の警告ダイアログ（showAlertDialog）を使う。新しい部品は作らない（.salesban-dialog は isOurUiElement に登録済み）。
  // 止める条件は既存のまま：全体スイッチ（オフなら startUp で何も動かない）／一時停止・このサイトはオフ・Domain Blocker の全画面表示中（shouldSuppressInterrupts）
  const DANGER_NOTICE_TITLE = "スタッフから注意喚起があります";
  const DANGER_NOTICE_TEXT = "このページ（またはサイト）は営業禁止の報告があります。";
  const DANGER_NOTICE_REASON_LABEL = "理由：";
  let dangerList = null;
  let dangerNoticeDone = false; // このページで出したか（メモリ上）

  // 正規化の規則は background.js の normalizeDangerUrlKey と同じ（スキーム・www.・?以降・#以降・末尾の/を除く）
  function normalizeDangerUrl(raw) {
    try {
      const u = new URL(String(raw || ""));
      if (u.protocol !== "http:" && u.protocol !== "https:") return "";
      return u.hostname.toLowerCase().replace(/^www\./, "") + u.pathname.replace(/\/+$/, "");
    } catch (_e) { return ""; }
  }
  function ownHas(obj, key) {
    return !!obj && Object.prototype.hasOwnProperty.call(obj, key);
  }
  // 一致したら { reason } を返す。フォーム：完全一致／ドメイン：そのドメインまたはサブドメイン
  function matchDanger() {
    if (!dangerList) return null;
    const key = normalizeDangerUrl(location.href);
    if (!key) return null;
    if (ownHas(dangerList.forms, key)) return { reason: dangerList.forms[key] || "" };
    let host = key.split("/")[0];
    while (host.includes(".")) {
      if (ownHas(dangerList.domains, host)) return { reason: dangerList.domains[host] || "" };
      host = host.slice(host.indexOf(".") + 1);
    }
    return null;
  }
  function dangerShownKey() { return "salesban_danger_shown:" + normalizeDangerUrl(location.href); }

  function checkDangerNotice() {
    if (!IS_TOP || dangerNoticeDone || !dangerList) return;
    const hit = matchDanger();
    if (!hit) return;
    // そのタブ・そのページで1回だけ（再読み込みしても出さない。タブを閉じるとリセット）
    try { if (sessionStorage.getItem(dangerShownKey())) { dangerNoticeDone = true; return; } } catch (_e) { /* 使えなければメモリ上だけで判定 */ }
    if (shouldSuppressInterrupts()) return; // 出さない状態。再開時の kickoffDetection でもう一度判定する
    if (document.visibilityState !== "visible") {
      // 裏タブでは出さず、表示された時に判定し直す
      document.addEventListener("visibilitychange", function once() {
        if (document.visibilityState !== "visible") return;
        document.removeEventListener("visibilitychange", once);
        checkDangerNotice();
      });
      return;
    }
    dangerNoticeDone = true;
    try { sessionStorage.setItem(dangerShownKey(), "1"); } catch (_e) { /* 無視 */ }
    const reason = hit.reason ? `<br>${escapeHtml(DANGER_NOTICE_REASON_LABEL)}${escapeHtml(hit.reason)}` : "";
    showAlertDialog({
      title: DANGER_NOTICE_TITLE,
      text: escapeHtml(DANGER_NOTICE_TEXT) + reason,
      triggerWord: null,
      dialogId: "salesban-danger-dialog",
      noScroll: true,
    });
  }

  // ===== お知らせカード（ver10.2：ページ上） =====
  // 新しい版・試験版・運用のお知らせを、最上位のページの右下にカードで出す。1日1回（その日、最初に開いたページで）。
  // 見せるかどうか（版の比較・期間・［あとで］・［この件は無視］・試験版のスイッチ）は background.js が決める。
  // Shadow DOM で作り、ページ側のCSSの影響を受けない。文字はすべて textContent（HTMLとして解釈しない）。
  // 部品（#salesban-notice-card）は isOurUiElement の除外に登録済み。
  const NOTICE_CARD_ID = "salesban-notice-card";
  const NOTICE_CARD_SUB_COLLAPSE_LEN = 80; // 補足がこれより長いときは［詳しく見る］で開く

  function showNoticeCard(list) {
    if (!list.length || document.getElementById(NOTICE_CARD_ID)) return;
    const host = document.createElement("div");
    host.id = NOTICE_CARD_ID;
    host.style.cssText = "all:initial;position:fixed;right:12px;bottom:12px;z-index:2147483646;";
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
      .card { box-sizing: border-box; width: min(360px, calc(100vw - 24px)); background: #fff; color: #222; border: 1px solid #90caf9; border-left: 5px solid #1976d2;
        border-radius: 8px; box-shadow: 0 4px 16px rgba(0,0,0,.25); padding: 12px 14px; font: 13px/1.6 "Meiryo","Yu Gothic UI",sans-serif; }
      .card.beta { border-left-color: #f57c00; } .card.notice { border-left-color: #2e7d32; }
      .head { display: flex; align-items: center; gap: 6px; font-size: 11px; color: #555; margin-bottom: 4px; }
      .tag { background: #1976d2; color: #fff; border-radius: 8px; padding: 1px 7px; font-size: 10.5px; }
      .beta .tag { background: #f57c00; } .notice .tag { background: #2e7d32; }
      .pos { margin-left: auto; }
      .title { font-weight: 700; font-size: 14px; margin-bottom: 4px; word-break: break-word; }
      .msg, .sub { white-space: pre-wrap; word-break: break-word; }
      .sub { margin-top: 6px; font-size: 11.5px; color: #555; }
      .more { margin-top: 4px; font-size: 11.5px; color: #1565c0; background: none; border: none; padding: 0; cursor: pointer; text-decoration: underline; font-family: inherit; }
      .row { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 10px; }
      button.b, a.b { flex: 0 1 auto; padding: 6px 10px; border: 1px solid #ccc; border-radius: 5px; background: #f5f5f5; color: #222; font-size: 12px; cursor: pointer; font-family: inherit; text-decoration: none; line-height: 1.4; }
      a.b.primary { background: #1976d2; border-color: #1565c0; color: #fff; }
      button.b:hover, a.b:hover { filter: brightness(.95); }
    `;
    root.appendChild(style);
    const card = document.createElement("div");
    root.appendChild(card);
    document.documentElement.appendChild(host);

    let idx = 0;
    const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
    const close = () => host.remove();
    const send = (action, id) => { try { chrome.runtime.sendMessage({ type: "noticeAction", action, id }, () => { void chrome.runtime.lastError; }); } catch (_e) { /* 無視 */ } };

    function render() {
      const n = list[idx];
      card.textContent = "";
      card.className = "card" + (n.kind === "beta" ? " beta" : n.kind === "notice" ? " notice" : "");
      const head = el("div", "head");
      head.appendChild(el("span", "tag", n.kind === "beta" ? "試験版" : n.kind === "notice" ? "お知らせ" : "新しい版"));
      if (list.length > 1) head.appendChild(el("span", "pos", `${idx + 1}/${list.length}`));
      card.appendChild(head);
      card.appendChild(el("div", "title", n.title || (n.version ? `バージョン ${n.version}` : "お知らせ")));
      if (n.message) card.appendChild(el("div", "msg", n.message));
      if (n.sub) {
        const sub = el("div", "sub", n.sub);
        card.appendChild(sub);
        if (n.sub.length > NOTICE_CARD_SUB_COLLAPSE_LEN || n.sub.split("\n").length > 2) {
          sub.style.display = "none";
          const more = el("button", "more", "詳しく見る");
          more.type = "button";
          more.addEventListener("click", () => {
            const open = sub.style.display === "none";
            sub.style.display = open ? "" : "none";
            more.textContent = open ? "閉じる" : "詳しく見る";
          });
          card.appendChild(more);
        }
      }
      const row = el("div", "row");
      for (const l of (n.links || []).slice(0, 3)) {
        if (!l || !l.name || !/^https:\/\//i.test(l.url || "")) continue; // 名前が空・https:// でないものは出さない
        const a = el("a", "b primary", l.name);
        a.href = l.url; a.target = "_blank"; a.rel = "noopener noreferrer";
        row.appendChild(a);
      }
      const removeCurrent = () => {
        list.splice(idx, 1);
        if (!list.length) { close(); return; }
        if (idx >= list.length) idx = 0;
        render();
      };
      const later = el("button", "b", "あとで"); later.type = "button";
      later.addEventListener("click", () => { send("later", n.id); removeCurrent(); });
      const ign = el("button", "b", "この件は無視"); ign.type = "button";
      ign.addEventListener("click", () => { send("ignore", n.id); removeCurrent(); });
      row.appendChild(later); row.appendChild(ign);
      if (list.length > 1) {
        const next = el("button", "b", `次へ（${idx + 1}/${list.length}）`); next.type = "button";
        next.addEventListener("click", () => { idx = (idx + 1) % list.length; render(); });
        row.appendChild(next);
      }
      card.appendChild(row);
    }
    render();
  }

  // 出してよい状態（最上位のページ・全体オン・一時停止でない・このサイトはオフでない・Domain Blocker の全画面表示が出ていない）のときだけ、1日1回の判定を background に頼む
  function maybeShowNoticeCard() {
    if (!IS_TOP) return;
    if (shouldSuppressInterrupts()) return;
    if (document.visibilityState !== "visible") {
      // 裏タブでは出さず、表示された時に判定し直す（「その日、最初に開いたページ」を裏タブで消費しないため）
      document.addEventListener("visibilitychange", function once() {
        if (document.visibilityState !== "visible") return;
        document.removeEventListener("visibilitychange", once);
        maybeShowNoticeCard();
      });
      return;
    }
    try {
      chrome.runtime.sendMessage({ type: "getPageNotices" }, (res) => {
        void chrome.runtime.lastError;
        const list = res && Array.isArray(res.notices) ? res.notices : [];
        if (list.length && !shouldSuppressInterrupts()) showNoticeCard(list);
      });
    } catch (_e) { /* 拡張機能が更新された直後などは何もしない */ }
  }

  // ===== 「上から下まで確認」のスクロール誘導（ver10.1 J） =====
  // 常時パネルの［上から下まで確認］で、ページの先頭から一定の速さで下まで自動スクロールする。
  // 新しい検出の処理は足さない（スクロールで読み込まれた内容は、既存の監視・強調・OCRが拾う）。
  const SCROLL_CHECK_SEC_PER_SCREEN = 4;   // 画面1枚ぶんにかける秒数（ここで速さを変えられる）
  const SCROLL_CHECK_MAX_EXTENSIONS = 3;   // 最後に着いたとき、ページが伸びていたら続ける回数の上限
  const SCROLL_CHECK_END_WAIT_MS = 1000;   // 最後に着いてから、遅れて読み込まれる内容を待つ時間
  const SCROLL_CHECK_TOAST_ID = "salesban-scrollcheck-toast"; // isOurUiElement の除外に登録済み
  let scrollCheck = null; // 動いている間だけ { pct, y, lastSet, last, ext, raf, timer, cleanup }

  function docMaxScroll() {
    const de = document.documentElement, b = document.body;
    const h = Math.max(de ? de.scrollHeight : 0, b ? b.scrollHeight : 0);
    return Math.max(0, h - window.innerHeight);
  }

  function showScrollCheckToast(message) {
    if (shouldSuppressInterrupts()) return;
    document.getElementById(SCROLL_CHECK_TOAST_ID)?.remove();
    const toast = document.createElement("div");
    toast.id = SCROLL_CHECK_TOAST_ID;
    toast.className = "salesban-hint-toast";
    toast.textContent = message;
    document.documentElement.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add("show"));
    const dismiss = () => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 300);
    };
    toast.addEventListener("click", dismiss);
    setTimeout(dismiss, 5000);
  }

  function stopScrollCheck(finished) {
    const st = scrollCheck;
    if (!st) return;
    scrollCheck = null;
    cancelAnimationFrame(st.raf);
    clearTimeout(st.timer);
    if (st.cleanup) st.cleanup();
    renderOnPagePanel();
    if (finished) showScrollCheckToast(`最後まで確認しました（検出：${getTotalDetections()}件）`);
  }

  function startScrollCheck() {
    if (!IS_TOP || scrollCheck || isHalted() || !isFeat("panelScrollCheck")) return;
    const st = { pct: 0, y: 0, lastSet: 0, last: performance.now(), ext: 0, raf: 0, timer: 0, cleanup: null };
    scrollCheck = st;

    // 途中でホイール・キー操作・クリックなどが入ったら、すぐに止める（パネル内のクリックは、そのボタン自身が処理する）
    const onUser = (e) => {
      if ((e.type === "mousedown" || e.type === "click" || e.type === "touchstart") && onPagePanelEl && onPagePanelEl.contains(e.target)) return;
      stopScrollCheck(false);
    };
    const evs = ["wheel", "keydown", "mousedown", "click", "touchstart"];
    evs.forEach((t) => window.addEventListener(t, onUser, { capture: true, passive: true }));
    st.cleanup = () => evs.forEach((t) => window.removeEventListener(t, onUser, { capture: true }));

    const setY = (y) => { st.y = y; st.lastSet = Math.round(y); window.scrollTo({ top: y, behavior: "instant" }); };
    setY(0);
    renderOnPagePanel();

    const setPct = (max) => {
      const pct = max > 0 ? Math.min(99, Math.floor((st.y / max) * 100)) : 0;
      if (pct === st.pct) return;
      st.pct = pct;
      // 進み具合は、パネルを作り直さず、文字だけ書き換える（作り直すと、［中止］を押している最中にクリックを取りこぼすことがあるため）
      const label = onPagePanelEl && onPagePanelEl.querySelector(".panel-scan-row .panel-pause-text");
      if (label) label.textContent = `確認中… ${pct}%`; else renderOnPagePanel();
    };

    const step = (now) => {
      if (scrollCheck !== st) return;
      if (isHalted()) { stopScrollCheck(false); return; }
      // ほかの手段（スクロールバーのドラッグなど）で位置が動かされていたら止める
      if (Math.abs(window.scrollY - st.lastSet) > 30) { stopScrollCheck(false); return; }
      const dt = Math.min(100, now - st.last);
      st.last = now;
      const max = docMaxScroll();
      const next = st.y + (window.innerHeight / SCROLL_CHECK_SEC_PER_SCREEN) * (dt / 1000);
      if (next >= max) {
        setY(max);
        setPct(max);
        // 最後に着いた：遅れて読み込まれて、ページが伸びていたら続ける（上限あり）
        st.timer = setTimeout(() => {
          if (scrollCheck !== st) return;
          if (docMaxScroll() > st.y + 20 && st.ext < SCROLL_CHECK_MAX_EXTENSIONS) {
            st.ext++;
            st.last = performance.now();
            st.raf = requestAnimationFrame(step);
          } else {
            stopScrollCheck(true);
          }
        }, SCROLL_CHECK_END_WAIT_MS);
        return;
      }
      setY(next);
      setPct(max);
      st.raf = requestAnimationFrame(step);
    };
    st.raf = requestAnimationFrame(step);
  }

  // 警告ダイアログを閉じた後、該当箇所へスクロール
  // triggerWordが分かっている場合（一発アウト）はその箇所へ、
  // 分からない場合（組み合わせ検出）は「営業」または「お断り/禁止」系ワードの箇所へ
  function scrollToComboRelevantMatch(triggerWord) {
    if (triggerWord && wordRegistry.has(triggerWord)) {
      jumpToNextOccurrence(triggerWord);
      return;
    }
    if (triggerWord && jumpToFrameOccurrence(triggerWord)) return;
    for (const [word, list] of wordRegistry.entries()) {
      if (!list.length) continue;
      const isRelevant =
        word.includes("営業") ||
        word.includes("お断り") ||
        word.includes("おことわり") ||
        word.includes("禁止") ||
        word.includes("ご遠慮") ||
        EIGYO_CATEGORY_WORDS.includes(word) ||
        KOTOWARI_CATEGORY_WORDS.includes(word);
      if (isRelevant) {
        jumpToNextOccurrence(word);
        return;
      }
    }
    for (const w of frameWordCounts().keys()) {
      const bare = stripImagePrefix(w);
      if (
        bare.includes("営業") || bare.includes("お断り") || bare.includes("おことわり") ||
        bare.includes("禁止") || bare.includes("ご遠慮") ||
        EIGYO_CATEGORY_WORDS.includes(bare) || KOTOWARI_CATEGORY_WORDS.includes(bare)
      ) {
        if (jumpToFrameOccurrence(w)) return;
      }
    }
  }

  // ===== レポート & UI更新 =====
  function reportProgress() {
    if (!IS_TOP) {
      postDetectionsToParent();
      return;
    }
    renderBanner();
    renderOnPagePanel();
    checkCombinationAlert();
  }

  // ===== 上部バナー =====
  let bannerEl = null;
  function renderBanner() {
    if (shouldSuppressInterrupts()) {
      // Domain Blocker の全画面表示中／一時停止中はバナーを出さない（出ていれば消す）
      bannerEl?.remove();
      bannerEl = null;
      return;
    }
    if (!isFeat("topBanner")) {
      bannerEl?.remove();
      bannerEl = null;
      return;
    }
    if (getTotalDetections() === 0 && !isFeat("zeroCountIndicator")) {
      bannerEl?.remove();
      bannerEl = null;
      return;
    }
    if (!bannerEl) {
      bannerEl = document.createElement("div");
      bannerEl.id = "salesban-banner";
      const closeBtn = document.createElement("button");
      closeBtn.id = "salesban-banner-close";
      closeBtn.textContent = "×";
      closeBtn.title = "バナーを閉じる";
      closeBtn.addEventListener("click", () => {
        bannerEl?.remove();
        bannerEl = null;
      });
      bannerEl.appendChild(closeBtn);
      document.documentElement.appendChild(bannerEl);
    }

    const existing = bannerEl.querySelector("#salesban-banner-text");
    if (existing) existing.remove();
    const textSpan = document.createElement("span");
    textSpan.id = "salesban-banner-text";

    if (getTotalDetections() > 0) {
      bannerEl.className = "salesban-banner-alert";
      const ocrNote = ocrDetectionsCount > 0 ? `（画像内 ${ocrDetectionsCount} 件含む）` : "";
      textSpan.textContent = `このページで営業禁止に関する表現が ${getTotalDetections()} 件検出されました${ocrNote} — 送信前に必ずご確認ください`;
    } else {
      bannerEl.className = "salesban-banner-ok";
      textSpan.textContent = "営業禁止ワードの検出：0件（スキャン完了）";
    }
    bannerEl.insertBefore(textSpan, bannerEl.firstChild);
  }

  // ===== 常時表示パネル（画面左下） =====
  let onPagePanelEl = null;
  let lastPanelSignature = null;
  let siteScanState = { status: "idle", totalScanned: 0, hits: [] };

  // ===== パネルの透明度・位置（chrome.storage.local に保存。サイトをまたいで共通・永続） =====
  let panelTransparency = 0; // 0〜80（%）。0 = 透けない（5%刻み）
  let panelPosition = null; // { left, top }（px）。null = 初期位置（左下）

  function sanitizePanelPos(v) {
    if (v && Number.isFinite(v.left) && Number.isFinite(v.top)) return { left: v.left, top: v.top };
    return null;
  }

  function applyPanelTransparency() {
    if (!onPagePanelEl) return;
    // 本体CSSの opacity はこの変数を参照する。「透」ボタン中(peek-mode)は別指定で常に優先される
    onPagePanelEl.style.setProperty("--salesban-panel-opacity", String((100 - panelTransparency) / 100));
  }

  function clampPanelPos(left, top, width, height) {
    const vw = document.documentElement.clientWidth || window.innerWidth;
    const vh = window.innerHeight || document.documentElement.clientHeight;
    return {
      left: Math.min(Math.max(0, left), Math.max(0, vw - width)),
      top: Math.min(Math.max(0, top), Math.max(0, vh - height)),
    };
  }

  function setPanelPosStyle(panel, left, top) {
    // style.css 側が !important なので、インライン指定も !important にしないと反映されない
    panel.style.setProperty("left", `${Math.round(left)}px`, "important");
    panel.style.setProperty("top", `${Math.round(top)}px`, "important");
    panel.style.setProperty("bottom", "auto", "important");
    panel.style.setProperty("right", "auto", "important");
  }

  // 保存された位置を反映（画面外にはみ出さないよう補正。保存値自体は変えない）。null なら初期位置へ戻す
  function applyPanelPosition() {
    const panel = onPagePanelEl;
    if (!panel) return;
    if (!panelPosition) {
      for (const p of ["left", "top", "bottom", "right"]) panel.style.removeProperty(p);
      return;
    }
    const rect = panel.getBoundingClientRect();
    const pos = clampPanelPos(panelPosition.left, panelPosition.top, rect.width, rect.height);
    setPanelPosStyle(panel, pos.left, pos.top);
  }

  if (IS_TOP) {
    // ポップアップ/設定画面での変更を、開いているタブにリアルタイム反映
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.panelTransparency) {
        panelTransparency = normalizePanelTransparency(changes.panelTransparency.newValue);
        applyPanelTransparency();
      }
      if (changes.panelPosition) {
        panelPosition = sanitizePanelPos(changes.panelPosition.newValue);
        applyPanelPosition();
      }
    });
    window.addEventListener("resize", () => {
      if (panelPosition) applyPanelPosition();
    });
  }

  // パネル本体に対して1度だけイベント委任を設定
  // （毎回innerHTMLを作り直すたびに個別リスナーを付け直すと、
  //   再描画のタイミングによってクリックが効かなくなる「反応不良」の原因になっていた）
  function setupPanelEventDelegation(panel) {
    panel.addEventListener("click", (e) => {
      const toggleBtn = e.target.closest(".panel-toggle-btn");
      if (toggleBtn) {
        panelCollapsed = !panelCollapsed;
        renderOnPagePanel();
        return;
      }

      const item = e.target.closest(".panel-item");
      if (item && panel.contains(item)) {
        const word = decodeURIComponent(item.dataset.word);
        jumpToNextOccurrence(word);
        return;
      }

      if (e.target.closest(".panel-scan-start")) {
        startScrollCheck();
        return;
      }
      if (e.target.closest(".panel-scan-stop")) {
        stopScrollCheck(false);
        return;
      }

      const pauseBtn = e.target.closest(".panel-pause-btn");
      if (pauseBtn && panel.contains(pauseBtn)) {
        const min = Number(pauseBtn.dataset.min);
        if (min > 0) startPause(min);
        return;
      }

      if (e.target.closest(".panel-site-off-btn")) {
        siteOffConfirming = true;
        renderOnPagePanel();
        return;
      }
      if (e.target.closest(".panel-site-off-cancel")) {
        siteOffConfirming = false;
        renderOnPagePanel();
        return;
      }
      if (e.target.closest(".panel-site-off-confirm")) {
        setSiteOff(true);
        return;
      }
      if (e.target.closest(".panel-site-resume-btn")) {
        setSiteOff(false);
        return;
      }

      const resumeBtn = e.target.closest(".panel-resume-btn, .panel-undo-btn");
      if (resumeBtn && panel.contains(resumeBtn)) {
        clearPause();
        return;
      }

      const noticeOpenBtn = e.target.closest(".panel-site-notice-open");
      if (noticeOpenBtn && panel.contains(noticeOpenBtn)) {
        showSiteScanNotice(siteScanState.hits || []);
        return;
      }

      const siteHitBtn = e.target.closest(".panel-site-hit");
      if (siteHitBtn && panel.contains(siteHitBtn)) {
        const url = decodeURIComponent(siteHitBtn.dataset.url);
        if (url) window.open(url, "_blank");
        return;
      }
    });
  }

  // 透過ボタン：押している間だけパネルを透明度90%（不透明度10%）にして裏側を見る
  function setupPanelPeekButton(panel) {
    let peeking = false;

    const endPeek = () => {
      if (!peeking) return;
      peeking = false;
      panel.classList.remove("peek-mode");
      window.removeEventListener("pointerup", endPeek);
      window.removeEventListener("pointercancel", endPeek);
    };

    panel.addEventListener("pointerdown", (e) => {
      const btn = e.target.closest(".panel-peek-btn");
      if (!btn) return;
      e.preventDefault();
      e.stopPropagation(); // ドラッグ開始を防ぐ
      peeking = true;
      panel.classList.add("peek-mode");
      window.addEventListener("pointerup", endPeek);
      window.addEventListener("pointercancel", endPeek);
    });
  }

  function renderOnPagePanel() {
    if (!IS_TOP) return;
    if (!isFeat("onPageDetectionPanel")) {
      onPagePanelEl?.remove();
      onPagePanelEl = null;
      lastPanelSignature = null;
      return;
    }

    if (!onPagePanelEl) {
      onPagePanelEl = document.createElement("div");
      onPagePanelEl.id = "salesban-onpage-panel";
      setupPanelDraggable(onPagePanelEl);
      setupPanelEventDelegation(onPagePanelEl);
      setupPanelPeekButton(onPagePanelEl);
      document.documentElement.appendChild(onPagePanelEl);
      applyPanelTransparency();
    }

    const countMap = new Map();
    for (const w of detectedSamples) {
      countMap.set(w, (countMap.get(w) || 0) + 1);
    }
    // iframe内で検出された分を合算
    for (const [w, c] of frameWordCounts()) {
      countMap.set(w, (countMap.get(w) || 0) + c);
    }

    const entries = Array.from(countMap.entries());
    const kindsCount = entries.length;

    let headerTitle = "営業禁止ワード検出";
    let statusClass = "panel-idle";

    const paused = isHalted();
    const siteOff = isSiteOff();
    if (paused) {
      headerTitle = siteOff ? "このサイト：オフ" : "一時停止中";
      statusClass = "panel-paused";
    } else if (!firstFlushDone) {
      headerTitle = "スキャン中...";
      statusClass = "panel-scanning";
    } else if (getTotalDetections() > 0) {
      headerTitle = `検出あり（${kindsCount}種類 / 計${getTotalDetections()}件）`;
      statusClass = "panel-alert";
    } else {
      headerTitle = "検出なし（0件）";
      statusClass = "panel-ok";
    }

    const newClassName = `${statusClass} ${panelCollapsed ? "collapsed" : ""}`;

    let bodyHtml = "";
    if (paused) {
      // 停止中は検出の一覧を出さない（「検出なし（0件）」と読み違えないように）
      bodyHtml = `<div class="panel-empty panel-empty-paused">${siteOff ? "このサイトでは検出しません。" : "一時停止中は検出しません。"}<br><span class="panel-empty-sub">下の［再開］で元に戻ります</span></div>`;
    } else if (getTotalDetections() === 0) {
      bodyHtml = '<div class="panel-empty">検出されませんでした。<br><span class="panel-empty-sub">※目視での確認も推奨します</span></div>';
    } else {
      bodyHtml = '<ul class="panel-list">';
      entries.forEach(([word, count]) => {
        const isOcr = word.startsWith("【画像内】");
        const displayWord = isOcr ? word.replace("【画像内】", "") : word;
        const ocrIcon = isOcr ? '<span class="panel-ocr-tag">[画像]</span>' : "";
        const curIdx = currentOccurrenceByKey.get(word) || 1;
        const posText = count > 1 ? `<span class="panel-pos">${curIdx}/${count}</span>` : "";

        bodyHtml += `
          <li class="panel-item ${isOcr ? "panel-item-ocr" : ""}" data-word="${encodeURIComponent(word)}" title="クリックで該当箇所へジャンプ">
            <span class="panel-item-name">${ocrIcon}${escapeHtml(displayWord)}</span>
            <span class="panel-item-count">${posText}計${count}件</span>
          </li>
        `;
      });
      bodyHtml += "</ul>";
    }

    // サイト全体スキャン結果表示
    let siteScanHtml = "";
    if (!paused && isFeat("siteWideScan")) {
      siteScanHtml = renderSiteScanSection();
    }

    const newHtml = `
      <div class="panel-header">
        <span class="panel-drag-handle" title="ドラッグで移動">:::</span>
        <span class="panel-header-title">${headerTitle}</span>
        <button class="panel-peek-btn" title="押している間だけ半透明にして裏側を見る">透</button>
        <button class="panel-toggle-btn" title="${panelCollapsed ? "展開" : "折りたたむ"}">${panelCollapsed ? "+" : "-"}</button>
      </div>
      <div class="panel-body">
        ${bodyHtml}
        ${siteScanHtml}
      </div>
      ${renderPanelFooter()}
    `;

    if (onPagePanelEl.className !== newClassName) {
      onPagePanelEl.className = newClassName;
    }

    // 内容に変化がない場合はinnerHTMLを再構築しない
    // （毎回作り直すと、クリック直後の再描画でボタン要素が差し替わり
    //   イベントを取りこぼす「反応不良」の原因になっていた。
    //   イベント自体は上のsetupPanelEventDelegationで委任済みなので影響なし）
    const newSignature = newClassName + "||" + newHtml;
    if (newSignature !== lastPanelSignature) {
      onPagePanelEl.innerHTML = newHtml;
      lastPanelSignature = newSignature;
      // 内容（=高さ）が変わると画面外にはみ出す場合があるので、保存位置を補正して反映
      if (panelPosition) applyPanelPosition();
    }
  }

  // ===== パネル下部（折りたたみ時は CSS で非表示）：一時停止 =====
  // 中身は renderOnPagePanel の newHtml に含まれ、内容が変わらない限り再構築されない。
  // ボタンはイベント委任（setupPanelEventDelegation）で処理する。
  function renderPanelFooter() {
    const now = Date.now();
    let row;
    const siteKey = currentSiteKey();
    if (isSiteOff()) {
      // オフ中の印（一時停止より優先して表示。一時停止の期限はそのまま進む）
      row = `
        <div class="panel-pause-row panel-pause-active">
          <span class="panel-pause-text">このサイト：オフ</span>
          <button class="panel-site-resume-btn" type="button">再開</button>
        </div>`;
    } else if (isPaused()) {
      if (pauseUndo && now < pauseUndo.until) {
        row = `
          <div class="panel-pause-row panel-pause-undo">
            <span class="panel-pause-text">一時停止しました（${escapeHtml(pauseUndo.label)}）</span>
            <button class="panel-undo-btn" type="button">元に戻す</button>
          </div>`;
      } else {
        row = `
          <div class="panel-pause-row panel-pause-active">
            <span class="panel-pause-text">一時停止中 残り${formatPauseRemaining(pausedUntil - now)}</span>
            <button class="panel-resume-btn" type="button">再開</button>
          </div>`;
      }
    } else {
      row = isFeat("panelPause") ? `
        <div class="panel-pause-row">
          <span class="panel-pause-text">一時停止</span>
          <button class="panel-pause-btn" type="button" data-min="15">15分</button>
          <button class="panel-pause-btn" type="button" data-min="60">1時間</button>
        </div>` : "";
      if (siteKey) {
        if (siteOffConfirming) {
          // 2段階目：ドメインを表示して確認（window.confirm や新しいモーダルは使わない）
          row += `
        <div class="panel-site-confirm">
          <div class="panel-site-confirm-text">「<strong>${escapeHtml(siteKey)}</strong>」では今後、検出しません。よろしいですか？</div>
          <div class="panel-site-confirm-btns">
            <button class="panel-site-off-cancel" type="button">やめる</button>
            <button class="panel-site-off-confirm" type="button">オフにする</button>
          </div>
        </div>`;
        } else {
          row += `
        <div class="panel-pause-row panel-site-off-row">
          <button class="panel-site-off-btn" type="button">このサイトで検出をオフ</button>
        </div>`;
        }
      }
    }
    // ［上から下まで確認］（ver10.1）：止めている間は出さない
    let scanRow = "";
    if (IS_TOP && !isHalted() && isFeat("panelScrollCheck")) {
      scanRow = scrollCheck
        ? `<div class="panel-pause-row panel-scan-row"><span class="panel-pause-text">確認中… ${scrollCheck.pct}%</span><button class="panel-scan-stop" type="button">中止</button></div>`
        : `<div class="panel-pause-row panel-scan-row"><button class="panel-scan-start" type="button">上から下まで確認</button></div>`;
    }
    return `<div class="panel-footer">${scanRow}${row}</div>`;
  }

  // 一時停止の開始（1クリックで実行。5秒間「元に戻す」を出す）
  function startPause(minutes) {
    const now = Date.now();
    pausedUntil = now + minutes * 60000;
    pauseUndo = { until: now + PAUSE_UNDO_MS, label: minutes >= 60 ? `${minutes / 60}時間` : `${minutes}分間` };
    try { chrome.storage.local.set({ pausedUntil }); } catch (_e) { /* 拡張の更新直後などは無視 */ }
    syncPauseState();
  }

  // このサイトで検出をオフ／再開
  function setSiteOff(off) {
    const key = currentSiteKey();
    if (!key) return;
    siteOffConfirming = false;
    const next = new Set(disabledSites);
    if (off) next.add(key); else next.delete(key);
    disabledSites = [...next];
    try { chrome.storage.local.set({ disabledSites }); } catch (_e) { /* 無視 */ }
    syncPauseState();
  }

  // 再開／元に戻す（同じ処理）
  function clearPause() {
    pausedUntil = 0;
    pauseUndo = null;
    try { chrome.storage.local.set({ pausedUntil: 0 }); } catch (_e) { /* 無視 */ }
    syncPauseState();
  }

  // 一時停止の状態が変わった時（開始・再開・期限切れ・他タブでの変更）の共通処理。何度呼んでも安全
  function syncPauseState() {
    // このサイトがオフになった瞬間（このタブで操作した時／他のタブで操作した時）は、パネルを折りたたむ。
    // 折りたたむのは切り替わった瞬間だけ。その後に +/- で展開すれば、［再開］が押せる（展開したままにもできる）
    const siteOffNow = isSiteOff();
    if (siteOffNow && !lastSiteOff) panelCollapsed = true;
    lastSiteOff = siteOffNow;
    const now = isHalted();
    if (pauseUndo && Date.now() >= pauseUndo.until) pauseUndo = null;
    if (now !== lastPausedState) {
      lastPausedState = now;
      if (now) {
        pendingAlert = null; // 保留中の警告ダイアログは出さない
        renderBanner();       // 出ているバナーを消す
      } else {
        pauseUndo = null;
        siteOffConfirming = false;
        // 止めていた間の変化を拾い直す（まだ一度も走らせていなければ最初から）。UIはこの中の reportProgress で更新
        if (startUpDone) kickoffDetection();
        try { chrome.runtime.sendMessage({ type: "refreshBadge" }, () => void chrome.runtime.lastError); } catch (_e) { /* 無視 */ }
      }
    }
    renderOnPagePanel();
    // 残り時間・「元に戻す」の表示を更新するための秒刻みの確認。使う間だけ動かす
    const needTick = isPaused() || !!pauseUndo; // 秒刻みは「残り○分」と「元に戻す」のためだけ（サイトオフには不要）
    if (needTick && !pauseTicker) {
      pauseTicker = setInterval(syncPauseState, 1000);
    } else if (!needTick && pauseTicker) {
      clearInterval(pauseTicker);
      pauseTicker = null;
    }
  }

  function renderSiteScanSection() {
    let content = "";
    if (siteScanState.status === "scanning") {
      content = '<div class="site-scan-status">サイト他ページを先読み中...</div>';
    } else if (siteScanState.hits && siteScanState.hits.length > 0) {
      content = `
        <div class="site-scan-hits">
          <div class="site-scan-title">他ページで禁止ワード検出 (${siteScanState.hits.length}ページ)
            <button class="panel-site-notice-open" type="button">大きく表示</button>
          </div>
          ${siteScanState.hits.map(h => `
            <button class="panel-site-hit" data-url="${encodeURIComponent(h.url)}">
              ${escapeHtml(h.title || h.url)} (${h.words.slice(0, 2).join("、")})
            </button>
          `).join("")}
        </div>
      `;
    } else if (siteScanState.status === "completed") {
      content = `<div class="site-scan-ok">他${siteScanState.totalScanned || 0}ページ確認済み・記載なし</div>`;
    }
    return `<div class="panel-site-scan">${content}</div>`;
  }

  // ===== 該当箇所ジャンプ =====

  // 要素が実際に画面上で見える状態かどうかを判定
  // （アコーディオンの中身やdisplay:noneの要素などにジャンプしてしまうのを防ぐ）
  function isElementVisible(el) {
    if (!el || !el.isConnected) return false;
    if (typeof el.checkVisibility === "function") {
      try {
        return el.checkVisibility({
          checkOpacity: false,
          checkVisibilityCSS: true,
        });
      } catch (_e) {
        // checkVisibility未対応/エラー時はフォールバックへ
      }
    }
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  }

  // ネイティブのscrollIntoView(smooth)より速い、独自のスムーズスクロール
  function fastScrollIntoView(el, { duration = 260 } = {}) {
    const rect = el.getBoundingClientRect();
    const startX = window.scrollX;
    const startY = window.scrollY;
    const targetX = startX + rect.left - (window.innerWidth - rect.width) / 2;
    const targetY = startY + rect.top - (window.innerHeight - rect.height) / 2;
    const diffX = targetX - startX;
    const diffY = targetY - startY;

    if (Math.abs(diffX) < 1 && Math.abs(diffY) < 1) return;

    const easeOutQuad = (t) => 1 - (1 - t) * (1 - t);
    let startTime = null;

    function step(ts) {
      if (startTime === null) startTime = ts;
      const progress = Math.min((ts - startTime) / duration, 1);
      const eased = easeOutQuad(progress);
      window.scrollTo(startX + diffX * eased, startY + diffY * eased);
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // 折りたたまれたアコーディオン等の中に対象要素がある場合、可能な範囲で展開して見せる
  // （<details>のopen属性、hidden属性のみが対象。サイト独自JSのアコーディオン
  //   （aria-expandedやCSSクラスでの開閉）は挙動が多様すぎるため自動展開は行わない）
  function revealAncestors(el) {
    let node = el;
    while (node && node !== document.body) {
      if (node.tagName === "DETAILS" && !node.open) {
        node.open = true;
      }
      if (node.hasAttribute("hidden")) {
        node.removeAttribute("hidden");
      }
      node = node.parentElement;
    }
  }

  // 展開してもなお見えない場合の保険：見える範囲まで祖先をさかのぼってそこへスクロールする
  function findNearestVisibleAncestor(el) {
    let node = el?.parentElement;
    while (node && node !== document.documentElement) {
      if (isElementVisible(node)) return node;
      node = node.parentElement;
    }
    return null;
  }

  // 横/縦スクロールギャラリー対策：
  // overflow-x/y が auto/scroll になっている祖先コンテナ（ユーザーがドラッグ等で
  // スクロール操作できるタイプ）の中に対象がある場合、そのコンテナ自体のスクロール位置も
  // 中央寄せに調整する。window.scrollTo だけでは、こうした「ページ内の別のスクロール領域」
  // は動かせないため必要な処理。
  // （transform等で画像を動かすJS実装のカルーセル、overflow:hiddenで隠すタイプは
  //   scrollLeft操作が効かないため対象外。これはサイトごとの実装差が大きく汎用対応できない）
  function revealInScrollContainers(el) {
    let node = el.parentElement;
    while (node && node !== document.body) {
      const style = getComputedStyle(node);
      const canScrollX = /(auto|scroll)/.test(style.overflowX) && node.scrollWidth > node.clientWidth;
      const canScrollY = /(auto|scroll)/.test(style.overflowY) && node.scrollHeight > node.clientHeight;

      if (canScrollX || canScrollY) {
        const elRect = el.getBoundingClientRect();
        const containerRect = node.getBoundingClientRect();
        if (canScrollX) {
          node.scrollLeft += (elRect.left + elRect.width / 2) - (containerRect.left + containerRect.width / 2);
        }
        if (canScrollY) {
          node.scrollTop += (elRect.top + elRect.height / 2) - (containerRect.top + containerRect.height / 2);
        }
      }
      node = node.parentElement;
    }
  }

  // 「見た目上は見つからないが検出はされている」ことをやさしい言葉で伝えるトースト通知
  function showLocationHintToast() {
    if (shouldSuppressInterrupts()) return; // Domain Blocker の全画面表示中／一時停止中は出さない
    document.getElementById("salesban-hint-toast")?.remove();

    const toast = document.createElement("div");
    toast.id = "salesban-hint-toast";
    toast.className = "salesban-hint-toast";
    toast.textContent =
      "この検出結果、今の画面には見当たりませんでした。プルダウンやタブの中、横にスクロールして見る一覧（カルーセル）の中など、この近くのどこかに隠れているかもしれません。まれに検出ミスのこともあります。（タップで閉じる）";

    document.documentElement.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add("show"));

    const dismiss = () => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 300);
    };
    toast.addEventListener("click", dismiss);
    setTimeout(dismiss, 6000);
  }

  function jumpToNextOccurrence(word) {
    const list = wordRegistry.get(word);
    if (!list || list.length === 0) {
      jumpToFrameOccurrence(word);
      return;
    }

    document.querySelectorAll(".salesban-occurrence-badge").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".salesban-focus-pulse").forEach((el) => el.classList.remove("salesban-focus-pulse"));
    document.querySelectorAll(".salesban-approx-pulse").forEach((el) => el.classList.remove("salesban-approx-pulse"));

    // 現在位置から1件ずつ、実際に見える要素が見つかるまで最大list.length回試す
    // （その過程で、<details>等の折りたたみは自動展開を試みる）
    let target = null;
    let foundIdx = -1;
    const startIdx = (panelCycleIndex.get(word) || 0) % list.length;
    for (let i = 0; i < list.length; i++) {
      const idx = (startIdx + i) % list.length;
      const candidate = list[idx];
      if (!candidate.el || !candidate.el.isConnected) continue;
      revealAncestors(candidate.el);
      if (isElementVisible(candidate.el)) {
        target = candidate;
        foundIdx = idx;
        break;
      }
    }

    if (!target) {
      // 展開を試みても見える要素が1つもない場合（サイト独自JSのアコーディオン・カルーセル等）は、
      // 正確な位置には案内できないので、見える範囲までスクロールして「だいたいこの辺」を示し、
      // やさしい言葉のトーストで状況を説明する
      const firstIdx = startIdx % list.length;
      const fallbackSource = list[firstIdx]?.el;
      const fallbackEl = fallbackSource && findNearestVisibleAncestor(fallbackSource);
      if (fallbackEl) {
        revealInScrollContainers(fallbackEl);
        fastScrollIntoView(fallbackEl);
        fallbackEl.classList.add("salesban-approx-pulse");
      }
      showLocationHintToast();
      renderOnPagePanel();
      return;
    }

    panelCycleIndex.set(word, (foundIdx + 1) % list.length);
    currentOccurrenceByKey.set(word, foundIdx + 1);

    revealInScrollContainers(target.el);
    fastScrollIntoView(target.el);
    target.el.classList.add("salesban-focus-pulse");
    if (target.badge) target.badge.classList.add("active");

    renderOnPagePanel();
  }

  function setupPanelDraggable(panel) {
    let dragging = false;
    let moved = false;
    let pointerId = null;
    let startX = 0, startY = 0, initialLeft = 0, initialTop = 0;
    let lastPos = null;

    panel.addEventListener("pointerdown", (e) => {
      if (e.button !== undefined && e.button !== 0) return;
      if (e.target.closest(".panel-toggle-btn, .panel-peek-btn, .panel-item, .panel-site-hit, .panel-site-notice-open, .panel-pause-btn, .panel-resume-btn, .panel-undo-btn, .panel-site-off-btn, .panel-site-off-cancel, .panel-site-off-confirm, .panel-site-resume-btn")) return;
      const rect = panel.getBoundingClientRect();
      dragging = true;
      moved = false;
      pointerId = e.pointerId;
      startX = e.clientX;
      startY = e.clientY;
      initialLeft = rect.left;
      initialTop = rect.top;
      lastPos = null;
      try { panel.setPointerCapture(e.pointerId); } catch (_) { /* 非対応環境では無視 */ }
      panel.style.setProperty("user-select", "none", "important");
      e.preventDefault();
    });

    panel.addEventListener("pointermove", (e) => {
      if (!dragging || e.pointerId !== pointerId) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (!moved && Math.abs(dx) + Math.abs(dy) < 3) return; // クリックとの区別
      moved = true;
      const rect = panel.getBoundingClientRect();
      lastPos = clampPanelPos(initialLeft + dx, initialTop + dy, rect.width, rect.height);
      setPanelPosStyle(panel, lastPos.left, lastPos.top);
    });

    const endDrag = (e) => {
      if (!dragging || (e && e.pointerId !== pointerId)) return;
      dragging = false;
      try { panel.releasePointerCapture(pointerId); } catch (_) { /* 無視 */ }
      panel.style.removeProperty("user-select");
      if (moved && lastPos) {
        // 動かした位置を保存（別サイト・別タブ・次回起動後も同じ位置に出る）
        panelPosition = { left: Math.round(lastPos.left), top: Math.round(lastPos.top) };
        chrome.storage.local.set({ panelPosition });
      }
    };
    panel.addEventListener("pointerup", endDrag);
    panel.addEventListener("pointercancel", endDrag);
  }

  // ===== サンクスページ（送信完了ページ）の先読みチェック =====
  // お問い合わせフォームのページで、実際に送信することなく「/thanks/」等の
  // よくある完了ページURLを裏側でGETし、そこに営業禁止の記載がないか確認する。
  // フォームへのPOSTは一切行わない（＝実際の送信は発生しない）ので安全。
  const THANKS_SLUGS = [
    "thanks", "thankyou", "thank-you", "thank_you",
    "complete", "kanryo", "kanryou", "kansei", "kanryou/index",
    "confirm", "finish", "success", "sent", "arigatou",
  ];
  let thanksPrecheckDone = false;

  function looksLikeContactForm() {
    const forms = document.querySelectorAll("form");
    for (const f of forms) {
      const hasTextarea = f.querySelector("textarea");
      const inputCount = f.querySelectorAll("input, textarea, select").length;
      if (hasTextarea && inputCount >= 3) return true;
    }
    return false;
  }

  function buildThanksCandidates() {
    const { origin, pathname } = location;
    const base = pathname.endsWith("/") ? pathname : pathname + "/";
    const parentSegs = base.split("/").filter(Boolean);
    parentSegs.pop();
    const parentBase = "/" + (parentSegs.length ? parentSegs.join("/") + "/" : "");

    const urls = new Set();
    for (const slug of THANKS_SLUGS) {
      urls.add(origin + base + slug + "/");
      urls.add(origin + parentBase + slug + "/");
    }
    return [...urls].slice(0, 20);
  }

  async function fetchTextIfHtml(url) {
    try {
      const res = await fetch(url, { credentials: "same-origin" });
      if (!res.ok) return null;
      const ct = res.headers.get("content-type") || "";
      if (!ct.includes("text/html")) return null;
      const finalUrl = res.url;
      // 別ページへのリダイレクトで、結局同じフォームページ等に戻された場合は除外
      if (finalUrl.replace(/\/$/, "") === location.href.replace(/\/$/, "")) return null;
      return { url: finalUrl, html: await res.text() };
    } catch (_e) {
      return null;
    }
  }

  function extractBannedHits(html) {
    if (!COMBINED_REGEX) return [];
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll("script, style, noscript").forEach((el) => el.remove());
    const text = nfkc(doc.body?.innerText || "");
    const excludedRanges = computeExcludedRanges(text);
    const hits = [];
    const re = new RegExp(COMBINED_REGEX.source, COMBINED_REGEX.flags);
    let m;
    while ((m = re.exec(text)) !== null) {
      if (m[0].length === 0) { re.lastIndex++; continue; }
      if (!isRangeExcluded(m.index, m.index + m[0].length, excludedRanges)) hits.push(m[0]);
      if (hits.length >= 20) break;
    }
    return hits;
  }

  function showThanksPrecheckDialog(url, hits) {
    if (shouldSuppressAlerts()) return; // Domain Blocker の全画面表示中は出さない
    document.getElementById("salesban-thanks-dialog")?.remove();
    const uniqueHits = [...new Set(hits)].slice(0, 5);

    const dialog = document.createElement("dialog");
    dialog.id = "salesban-thanks-dialog";
    dialog.className = "salesban-dialog";

    dialog.innerHTML = `
      <div class="salesban-dialog-content">
        <div class="salesban-dialog-icon">[警告]</div>
        <div class="salesban-dialog-body">
          <h2 class="salesban-dialog-title">送信完了ページに営業禁止の記載があります</h2>
          <p class="salesban-dialog-text">
            このフォームの送信完了後に表示されると思われるページに、
            「${uniqueHits.map(escapeHtml).join("」「")}」という表現が見つかりました。<br>
            まだ送信前です。内容をよくご確認のうえ、送信するかどうかご判断ください。
          </p>
        </div>
      </div>
      <div class="salesban-dialog-actions gap">
        <button id="salesban-thanks-dialog-close" class="salesban-dialog-btn-secondary">閉じる</button>
        <button id="salesban-thanks-dialog-open" class="salesban-dialog-btn">確認ページを開く</button>
      </div>
    `;

    document.documentElement.appendChild(dialog);

    const closeBtn = dialog.querySelector("#salesban-thanks-dialog-close");
    const openBtn = dialog.querySelector("#salesban-thanks-dialog-open");
    closeBtn.addEventListener("click", () => dialog.close());
    openBtn.addEventListener("click", () => {
      window.open(url, "_blank");
      dialog.close();
    });
    dialog.addEventListener("close", () => dialog.remove());

    try {
      dialog.showModal();
      openBtn.focus();
    } catch (_e) {
      dialog.remove();
    }
  }

  async function runThanksPagePrecheck() {
    if (!IS_TOP || thanksPrecheckDone) return;
    if (!isFeat("thanksPagePrecheck")) return;
    if (!looksLikeContactForm()) return;
    thanksPrecheckDone = true;

    for (const url of buildThanksCandidates()) {
      const result = await fetchTextIfHtml(url);
      if (!result) continue;
      const hits = extractBannedHits(result.html);
      if (hits.length > 0) {
        showThanksPrecheckDialog(result.url, hits);
        return; // 最初に見つかった1件を知らせれば十分
      }
    }
  }

  // ===== サイト全体先読みスキャン =====
  function triggerSiteWideScan() {
    if (!IS_TOP) return;
    if (!isFeat("siteWideScan")) return;
    if (isHalted()) return; // 一時停止中／このサイトはオフ：先読みしない
    siteScanState.status = "scanning";
    renderOnPagePanel();

    chrome.runtime.sendMessage(
      { type: "startSiteWideScan", url: location.href },
      (resp) => {
        if (resp && resp.success) {
          siteScanState = {
            status: "completed",
            totalScanned: resp.totalScanned,
            hits: resp.hits || [],
          };
        } else {
          siteScanState.status = "idle";
        }
        renderOnPagePanel();
        maybeShowSiteScanNotice();
      }
    );
  }

  // ===== 他ページで見つかった場合の「確認してね」ダイアログ（オレンジ） =====
  // 先読みスキャンの結果は「他ページにあるかも」という精度の低い情報（外れることも少なくない）なので、
  // 赤の警告ではなくオレンジの確認依頼として出し、邪魔になりすぎないよう次の制限を設ける。
  //  ・同じサイトでは一度表示したら24時間は再表示しない（キャッシュ結果で毎ページ出ないように）
  //  ・このページ自身が警告ダイアログを出している場合、他のダイアログが開いている場合は出さない
  //  ・閉じる／Esc／背景クリックですぐ閉じられる。設定画面でOFFにもできる
  const SITE_NOTICE_SUPPRESS_MS = 24 * 60 * 60 * 1000;
  const SITE_NOTICE_MAX_ROWS = 8;

  function maybeShowSiteScanNotice() {
    if (!IS_TOP || !isFeat("siteScanNoticeDialog")) return;
    const hits = (siteScanState.hits || []).filter((h) => h && /^https?:\/\//i.test(h.url || "") && h.url !== location.href);
    if (hits.length === 0) return;
    if (alertShown) return; // このページ自身が既に警告済み（他ページの一覧はパネルに出ている）
    if (shouldSuppressInterrupts()) return; // Domain Blocker の全画面表示中／一時停止中は出さない（24時間の再表示抑止も消費しない）
    if (document.querySelector("dialog.salesban-dialog[open]")) return;

    const host = location.hostname;
    chrome.storage.local.get({ siteScanNoticeShownAt: {} }, (data) => {
      const now = Date.now();
      const map = data.siteScanNoticeShownAt || {};
      if (now - (Number(map[host]) || 0) < SITE_NOTICE_SUPPRESS_MS) return;
      for (const [k, t] of Object.entries(map)) {
        if (now - Number(t) >= SITE_NOTICE_SUPPRESS_MS) delete map[k]; // 期限切れを掃除
      }
      map[host] = now;
      chrome.storage.local.set({ siteScanNoticeShownAt: map });
      showSiteScanNotice(hits);
    });
  }

  function showSiteScanNotice(allHits) {
    const hits = (allHits || []).filter((h) => h && /^https?:\/\//i.test(h.url || ""));
    if (hits.length === 0) return;
    document.getElementById("salesban-site-notice")?.remove();

    const shown = hits.slice(0, SITE_NOTICE_MAX_ROWS);
    const rest = hits.length - shown.length;
    const shortUrl = (u) => {
      try { const x = new URL(u); return x.host + x.pathname + x.search; } catch (_e) { return u; }
    };
    const rows = shown
      .map((h) => {
        const words = [...new Set((h.words || []).map(stripImagePrefix))].slice(0, 3);
        return `
          <li class="salesban-site-notice-item">
            <a class="salesban-site-notice-link" href="${escapeHtml(h.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(h.title || h.url)}</a>
            <div class="salesban-site-notice-url">${escapeHtml(shortUrl(h.url))}</div>
            ${words.length ? `<div class="salesban-site-notice-words">見つかった表現：「${words.map(escapeHtml).join("」「")}」</div>` : ""}
          </li>`;
      })
      .join("");

    const dialog = document.createElement("dialog");
    dialog.id = "salesban-site-notice";
    dialog.className = "salesban-dialog salesban-site-notice";
    dialog.innerHTML = `
      <div class="salesban-site-notice-head">
        <div class="salesban-site-notice-badge">確認</div>
        <h2 class="salesban-site-notice-title">このサイトの他のページに、営業禁止の記載があるかもしれません</h2>
      </div>
      <div class="salesban-site-notice-body">
        <p class="salesban-site-notice-lead">
          同じサイトの他のページを先読みしたところ、下の${hits.length}ページで営業禁止に関わる表現が見つかりました。<br>
          <strong>営業禁止とは無関係な内容が検出されている場合もあります（外れることも少なくありません）。</strong>
          念のため、送信前に気になるページをご確認ください。
        </p>
        <ul class="salesban-site-notice-list">${rows}</ul>
        ${rest > 0 ? `<p class="salesban-site-notice-more">ほか${rest}ページ（画面左下の常時表示パネルに全件の一覧があります）</p>` : ""}
      </div>
      <div class="salesban-site-notice-actions">
        <span class="salesban-site-notice-hint">同じサイトでは24時間は再表示しません</span>
        <button type="button" class="salesban-site-notice-close">閉じる</button>
      </div>
    `;

    document.documentElement.appendChild(dialog);

    const close = () => dialog.close();
    dialog.querySelector(".salesban-site-notice-close").addEventListener("click", close);
    // 背景（ダイアログの外側）クリックでも閉じる
    dialog.addEventListener("click", (e) => { if (e.target === dialog) close(); });
    dialog.addEventListener("close", () => dialog.remove());

    try {
      dialog.showModal();
      dialog.querySelector(".salesban-site-notice-close").focus();
    } catch (_e) {
      dialog.remove();
    }
  }

  // ===== 手動OCRリクエスト受信 =====
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // ポップアップの［このページを報告］から：パネルに出ている検出語（最上位ページだけが答える）
    if (msg?.type === "getDetectedWords" && IS_TOP) {
      const set = new Set();
      for (const w of detectedSamples) set.add(w);
      for (const w of frameWordCounts().keys()) set.add(w);
      const words = [...set].slice(0, 50).map((w) => (w.startsWith("【画像内】") ? "[画像]" + w.replace("【画像内】", "") : w));
      sendResponse({ words });
      return;
    }
    if (msg?.type === "triggerImageOcr" && IS_TOP) {
      (async () => {
        const prev = ocrDetectionsCount;
        await scanImagesWithOcr();
        sendResponse({
          success: true,
          ocrCount: ocrDetectionsCount,
          newFound: ocrDetectionsCount - prev,
        });
      })();
      return true;
    }
  });

  // ===== 監視 =====
  const observer = new MutationObserver((muts) => {
    if (isHalted()) return; // 一時停止中／このサイトはオフ：新しい内容を見ない（再開時に取りこぼしを拾い直す）
    for (const m of muts) {
      if (m.type === "childList" && m.addedNodes?.length) {
        m.addedNodes.forEach((n) => {
          if (isOurUiElement(n) || isForeignBlockerElement(n)) return;
          if (n.nodeType === Node.ELEMENT_NODE || n.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
            scheduleEl(n);
          } else if (n.nodeType === Node.TEXT_NODE) {
            highlightTextNode(n);
          }
        });
      }
    }
  });

  // ===== 初期化 =====
  // 一括スキャン（URLモード）が開いたタブでは、通常の検出・表示・OCR・先読みは行わない
  // （二重のOCRや先読み、ダイアログが出るのを避ける。判定は一括スキャン画面が行う）
  // 検出の開始（起動時と、一時停止から再開した時に呼ぶ）。再開時に呼んでも二重にならないよう、既に処理済みの印は外して拾い直す
  let startUpDone = false;
  let detectionStartedOnce = false;
  function kickoffDetection() {
    if (!document.body) return;
    if (detectionStartedOnce) {
      // 止めていた間に追加された内容を拾うため、処理済みの印を外す（既に強調済みの語は .salesban-highlight の中なので二重には数えない）
      document.querySelectorAll(`[${MARK_ATTR}]`).forEach((el) => el.removeAttribute(MARK_ATTR));
    }
    detectionStartedOnce = true;

    for (const child of Array.from(document.body.childNodes)) {
      if (isOurUiElement(child) || isForeignBlockerElement(child)) continue;
      if (child.nodeType === Node.ELEMENT_NODE) {
        scheduleEl(child);
      } else if (child.nodeType === Node.TEXT_NODE) {
        highlightTextNode(child);
      }
    }

    reportProgress();
    observer.observe(document.body, { childList: true, subtree: true });

    // 危険サイトリスト（スタッフからの注意喚起）。再開時にも呼ばれるので、出していなければ出す
    setTimeout(checkDangerNotice, 700);

    // 子フレームへ「検出結果を送って」と合図（読み込み完了順の取りこぼし対策）
    setTimeout(pingChildFrames, 1500);
    setTimeout(pingChildFrames, 5000);
    window.addEventListener("load", () => setTimeout(pingChildFrames, 500));

    if (isFeat("ocrScan") && isFeat("ocrAutoScan")) {
      warmupOcr(); // ver9.4: 画像を読み始める前に、OCRエンジンの準備を先に始めておく
      setTimeout(scanImagesWithOcr, 600);
    }

    if (isFeat("siteWideScan")) {
      setTimeout(triggerSiteWideScan, 1200);
    }
  }

  // 一時停止の変更を、開いている全タブ・全フレームにすぐ反映
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !startUpDone) return;
    if (!changes.pausedUntil && !changes.disabledSites) return;
    if (changes.pausedUntil) pausedUntil = normalizePausedUntil(changes.pausedUntil.newValue);
    if (changes.disabledSites) disabledSites = normalizeDisabledSites(changes.disabledSites.newValue);
    syncPauseState();
  });

  // 設定画面で［上から下まで確認］［一時停止］のスイッチを切り替えたら、開いているタブにすぐ反映
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !startUpDone || !changes.featureSettings || !settings) return;
    const nf = (changes.featureSettings.newValue || {}).features || {};
    const wasPause = isFeat("panelPause");
    for (const id of ["panelScrollCheck", "panelPause"]) {
      if (typeof nf[id] === "boolean") settings.features[id] = nf[id];
    }
    if (!isFeat("panelScrollCheck") && scrollCheck) stopScrollCheck(false);
    if (wasPause && !isFeat("panelPause") && IS_TOP) {
      // 一時停止の機能をオフにしたら、停止中だった期限も消す（あとでオンにしたとき突然止まらないように）
      pausedUntil = 0;
      pauseUndo = null;
      try { chrome.storage.local.set({ pausedUntil: 0 }); } catch (_e) { /* 無視 */ }
    }
    syncPauseState();
  });

  const startUp = () => getFeatureSettings((s) => {
    settings = s;
    if (!settings.master) { showMasterOffNotice(); return; } // ver9.14: 検出は動かさず、通知だけ出す

    chrome.storage.local.get(
      {
        storedKeywords: [],
        userKeywords: [],
        syncedExcludedPhrases: [],
        syncedCategoryWords: { eigyo: [], kotowari: [], instant: [] },
        panelTransparency: 0,
        panelPosition: null,
        pausedUntil: 0,
        disabledSites: [],
        dangerList: null,
      },
      (data) => {
        pausedUntil = normalizePausedUntil(data.pausedUntil);
        disabledSites = normalizeDisabledSites(data.disabledSites);
        dangerList = data.dangerList && typeof data.dangerList === "object" ? data.dangerList : null;
        panelTransparency = normalizePanelTransparency(data.panelTransparency);
        panelPosition = sanitizePanelPos(data.panelPosition);
        applyPanelTransparency();

        if (data.syncedExcludedPhrases?.length) {
          EXCLUDED_PHRASES = [...new Set([...DEFAULT_EXCLUDED_PHRASES, ...data.syncedExcludedPhrases])];
        }

        // シート連携された「営業/禁止・お断り/一発アウト」ワードを内蔵ワードにマージ
        // 検出語は NFKC 正規化後の表記で返るため、比較に使う分類ワード側も正規化しておく
        EIGYO_CATEGORY_WORDS = EIGYO_CATEGORY_WORDS.map(nfkc);
        KOTOWARI_CATEGORY_WORDS = KOTOWARI_CATEGORY_WORDS.map(nfkc);
        INSTANT_ALERT_PHRASES = INSTANT_ALERT_PHRASES.map(nfkc);

        const cat = data.syncedCategoryWords || {};
        if (cat.eigyo?.length) {
          EIGYO_CATEGORY_WORDS = [...new Set([...EIGYO_CATEGORY_WORDS, ...cat.eigyo.map(nfkc)])];
        }
        if (cat.kotowari?.length) {
          KOTOWARI_CATEGORY_WORDS = [...new Set([...KOTOWARI_CATEGORY_WORDS, ...cat.kotowari.map(nfkc)])];
        }
        if (cat.instant?.length) {
          INSTANT_ALERT_PHRASES = [...new Set([...INSTANT_ALERT_PHRASES, ...cat.instant.map(nfkc)])];
        }

        const activeUserWords = (data.userKeywords || [])
          .filter((u) => u.enabled !== false)
          .map((u) => u.word);
        ALL_WORDS = [
          ...DEFAULT_KEYWORDS,
          ...(data.storedKeywords || []),
          ...activeUserWords,
          ...EIGYO_CATEGORY_WORDS,
          ...KOTOWARI_CATEGORY_WORDS,
          ...INSTANT_ALERT_PHRASES,
        ];

        COMBINED_REGEX = buildCombinedRegex(ALL_WORDS);

        if (!document.body) return;

        startUpDone = true;
        // オフにしたサイトを開いた時は、最初から折りたたんだ状態で出す（＝この後の syncPauseState では「切り替わり」と見なさない）
        lastSiteOff = isSiteOff();
        if (lastSiteOff) panelCollapsed = true;
        if (isHalted()) {
          // 一時停止中／オフのサイトで開いたページ：検出は始めず、パネルだけ「一時停止中［再開］」で出す
          syncPauseState();
        } else {
          kickoffDetection();
        }

        setTimeout(runThanksPagePrecheck, 1200);
        setTimeout(maybeShowNoticeCard, 2500); // ver10.2: お知らせカード（1日1回）
      }
    );
  });

  {
    let started = false;
    const go = () => { if (started) return; started = true; startUp(); };
    try {
      chrome.runtime.sendMessage({ type: "isBulkTab" }, (resp) => {
        void chrome.runtime.lastError;
        if (resp && resp.bulk) { started = true; return; }
        go();
      });
    } catch (_e) {
      go();
    }
    setTimeout(go, 1500); // 応答が無い場合も、通常どおり動かす
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
    );
  }
})();

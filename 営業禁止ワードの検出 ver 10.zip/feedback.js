// feedback.js — ver 10
// 「このページを報告」画面。入力を集めて background.js に渡し、background.js が共通API（GAS）へ送る。
(() => {
  const MAX_COMMENT = 500;
  const IMG_MAX_EDGE = 1280;   // 長辺の上限（px）
  const IMG_QUALITY = 0.7;     // JPEG品質
  const IMG_TARGET_BYTES = 1000 * 1000; // 約1MB以下に収める
  const NAME_KEY = "feedbackReporterName";

  const $ = (id) => document.getElementById(id);
  const params = new URLSearchParams(location.search);
  const pageUrl = params.get("url") || "";
  const pageTitle = params.get("title") || "";
  let words = [];
  try { const w = JSON.parse(params.get("words") || "[]"); if (Array.isArray(w)) words = w.filter((x) => typeof x === "string").slice(0, 50); } catch (_e) { /* 空でよい */ }

  let shot = null;      // { data: base64（接頭辞なし）, bytes, dataUrl }
  let sent = false;
  let configured = false;

  $("fbUrl").textContent = pageUrl || "（取得できませんでした）";
  $("fbTitle").textContent = pageTitle || "（なし）";
  $("fbWords").textContent = words.length ? words.join("、") : "（なし）";

  function setMsg(text, kind) { const m = $("msg"); m.textContent = text || ""; m.dataset.kind = kind || ""; }

  // 共通APIが未設定のときは、送信を無効にして説明を出す
  chrome.runtime.sendMessage({ type: "sharedApiStatus" }, (res) => {
    void chrome.runtime.lastError;
    configured = !!(res && res.configured);
    if (!configured) {
      $("sendBtn").disabled = true;
      setMsg("送信先がまだ設定されていません。管理者に連絡してください（background.js の SHARED_API_URL）。", "info");
    }
  });

  // 報告者名：前回の入力を復元
  chrome.storage.local.get({ [NAME_KEY]: "" }, (d) => { $("reporter").value = String(d[NAME_KEY] || ""); });

  $("comment").addEventListener("input", () => { $("commentCount").textContent = String($("comment").value.length); });

  // ===== スクショ：貼り付け → 縮小 → プレビュー =====
  function loadBitmap(blob) {
    if (window.createImageBitmap) return createImageBitmap(blob);
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(blob);
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("load")); };
      img.src = url;
    });
  }
  function canvasToJpeg(canvas, q) {
    return new Promise((resolve) => canvas.toBlob((b) => resolve(b), "image/jpeg", q));
  }
  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve({ dataUrl: String(r.result), data: String(r.result).split(",")[1] || "" });
      r.onerror = () => reject(new Error("read"));
      r.readAsDataURL(blob);
    });
  }

  // 長辺1280px・JPEG品質0.7に縮小。1MBを超えたら、品質→大きさの順に下げる
  async function shrink(blob) {
    const bmp = await loadBitmap(blob);
    const w0 = bmp.width, h0 = bmp.height;
    let scale = Math.min(1, IMG_MAX_EDGE / Math.max(w0, h0));
    let quality = IMG_QUALITY;
    let out = null;
    for (let i = 0; i < 6; i++) {
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(w0 * scale));
      canvas.height = Math.max(1, Math.round(h0 * scale));
      const ctx = canvas.getContext("2d");
      ctx.fillStyle = "#fff"; // PNGの透明部分が黒くならないように
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
      out = await canvasToJpeg(canvas, quality);
      if (out && out.size <= IMG_TARGET_BYTES) break;
      if (quality > 0.5) quality = 0.5; else scale *= 0.8;
    }
    if (bmp.close) bmp.close();
    if (!out) throw new Error("encode");
    return out;
  }

  async function onPasteImage(file) {
    try {
      setMsg("画像を縮小しています…", "info");
      const out = await shrink(file);
      const b64 = await blobToBase64(out);
      shot = { data: b64.data, bytes: out.size, dataUrl: b64.dataUrl };
      $("shotPreview").src = b64.dataUrl;
      $("shotInfo").textContent = `${Math.round(out.size / 1024).toLocaleString()} KB に縮小しました`;
      $("shotWrap").hidden = false;
      setMsg("", "");
    } catch (_e) {
      setMsg("画像を読み込めませんでした。もう一度貼り付けてください。", "ng");
    }
  }

  document.addEventListener("paste", (e) => {
    const items = (e.clipboardData && e.clipboardData.items) || [];
    for (const it of items) {
      if (it.kind === "file" && it.type.startsWith("image/")) {
        const f = it.getAsFile();
        if (f) { e.preventDefault(); onPasteImage(f); return; }
      }
    }
  });
  $("shotRemove").addEventListener("click", () => {
    shot = null;
    $("shotPreview").removeAttribute("src");
    $("shotWrap").hidden = true;
  });

  // ===== 送信 =====
  $("sendBtn").addEventListener("click", () => {
    if (sent || !configured) return;
    const kindEl = document.querySelector('input[name="kind"]:checked');
    if (!kindEl) { setMsg("種別を選んでください。", "ng"); return; }

    const reporter = $("reporter").value.trim().slice(0, 50);
    chrome.storage.local.set({ [NAME_KEY]: reporter });

    const payload = {
      kind: kindEl.value,
      url: pageUrl,
      title: pageTitle,
      words: words.join("、"),
      comment: $("comment").value.slice(0, MAX_COMMENT),
      reporter,
      screenshot: shot ? { mime: "image/jpeg", data: shot.data } : null,
    };

    const btn = $("sendBtn");
    btn.disabled = true; btn.textContent = "送信中…";
    setMsg("", "");
    chrome.runtime.sendMessage({ type: "submitFeedback", payload }, (res) => {
      void chrome.runtime.lastError;
      if (res && res.ok) {
        sent = true;
        btn.textContent = "送信しました";
        setMsg("送信しました。ご協力ありがとうございます。このタブは閉じて構いません。", "ok");
      } else {
        // 失敗：入力はそのまま残す。［再送］で、もう一度送れる
        btn.disabled = false; btn.textContent = "再送";
        setMsg("送信に失敗しました。ネットワークを確認して、［再送］を押してください。入力した内容は残っています。", "ng");
      }
    });
  });
})();

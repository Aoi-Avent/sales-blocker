// featureConfig.js — ver 10
// 全機能の定義を一元管理。content.js / background.js / options.js / popup.js から参照する。

const FEATURE_DEFS = [
  // ===== メイン機能 =====
  {
    id: "siteWideScan",
    category: "サイト全体スキャン",
    label: "サイト全体をバックグラウンドで先読みスキャン",
    desc: "今開いているページに記載が無くても、トップページや会社概要ページなど同じサイトの他ページに「営業禁止」等の記載がないか、裏側で自動的に確認します（最大25ページ・結果は1日間キャッシュ）。ページの表示速度には影響しません。",
    default: true,
    isAdvanced: false,
  },
  {
    id: "siteScanOcr",
    category: "サイト全体スキャン",
    label: "先読みスキャンで、会社概要・規約・お問い合わせ等のページの画像内の文字（OCR）も確認",
    desc: "先読みスキャンの際、会社概要・規約・ポリシー・お問い合わせなどのページにある画像（バナー等）の文字も読み取ります（1ページ最大3枚・1サイト最大10枚・合計60秒まで。小さな画像・svg・gifは対象外）。古いPCでは重くなる場合があります。オンにした直後は、前回までの先読み結果（1日キャッシュ）を使わず、もう一度確認します。",
    default: false,
    isAdvanced: false,
  },
  {
    id: "siteScanNoticeDialog",
    category: "サイト全体スキャン",
    label: "他ページで見つかった場合、確認ダイアログ（オレンジ）で一覧を表示",
    desc: "先読みスキャンで同じサイトの他ページに営業禁止に関わる表現が見つかった場合、該当ページの一覧を大きく表示して確認を促します。外れることもあるため、一度表示したら同じサイトでは24時間は再表示しません（常時表示パネルの「大きく表示」からいつでも開き直せます）。",
    default: true,
    isAdvanced: false,
  },
  {
    id: "thanksPagePrecheck",
    category: "サイト全体スキャン",
    label: "送信完了ページ（サンクスページ）を送信前に先読みチェック",
    desc: "お問い合わせフォームのページでは、「/thanks/」「/complete/」等よくある送信完了ページのURLを実際には送信せずに裏側で確認し、そこに営業禁止の記載が見つかった場合は送信前にお知らせします（フォームは自動送信しません）。URLの推測がハズレた場合は何も表示しません。",
    default: true,
    isAdvanced: false,
  },
  {
    id: "comboAlertPopup",
    category: "表示・通知",
    label: "「営業」＋「お断り/禁止」の組み合わせ検出、または決定的な表現の単体検出で警告ポップアップ",
    desc: "「営業」という単語だけでは「営業時間」等の誤検知が多いため、単体では警告しません。「営業」と、「お断り」「おことわり」「禁止」のいずれかが同時に検出された場合、または「特定電子メール法」に関する文言など単体で決定的な表現（一発アウトワード）が検出された場合に、ページ読み込み時にネイティブダイアログで警告します。",
    default: true,
    isAdvanced: false,
  },
  {
    id: "onPageDetectionPanel",
    category: "表示・通知",
    label: "ページ上に検出ワード一覧を常時表示（クリックでジャンプ）",
    desc: "拡張機能アイコンを開かなくても、検出された表現の一覧を画面左下に常時表示します。項目をクリックすると該当箇所まで自動スクロールし、動的に強調表示します。何も検出されない場合は「検出されませんでした。目視必須」と表示されます。",
    default: true,
    isAdvanced: false,
  },
  {
    id: "topBanner",
    category: "表示・通知",
    label: "ページ上部に固定警告バナーを表示",
    desc: "検出があった場合、スクロールしても見える位置に警告バナーを表示します。",
    default: false,
    isAdvanced: false,
  },
  {
    id: "zeroCountIndicator",
    category: "表示・通知",
    label: "「0件検出（スキャン完了）」を明示",
    desc: "未チェックと0件検出を混同しないよう、スキャン完了状態を明示します。",
    default: false,
    isAdvanced: false,
  },

  // ===== 高度な設定（アコーディオン内に格納） =====
  {
    id: "shadowDomScan",
    category: "高度な設定",
    label: "Shadow DOM内のテキストも検出",
    desc: "Web Componentsで構築されたサイトの中のテキストも走査します。",
    default: true,
    isAdvanced: true,
  },
  {
    id: "iframeScan",
    category: "高度な設定",
    label: "同一オリジンiframe内も検出",
    desc: "同じドメインのiframe内は走査します。別ドメインのiframeはブラウザのセキュリティ制約上スキャンできません。",
    default: true,
    isAdvanced: true,
  },
  {
    id: "ocrScan",
    category: "高度な設定",
    label: "画像内テキストのOCR検出",
    desc: "お問い合わせフォーム周辺等のバナー画像内の「営業お断り」等の文字を自動認識して赤枠警告します（Tesseract.js完全オフライン動作）。",
    default: true,
    isAdvanced: true,
  },
  {
    id: "ocrAutoScan",
    category: "高度な設定",
    label: "ページ表示時の自動OCRスキャン",
    desc: "ページを開いた際に自動で画像を解析します。OFFの場合はポップアップからの手動スキャンのみ実行します。",
    default: true,
    isAdvanced: true,
  },
  {
    id: "syncFailureNotify",
    category: "高度な設定",
    label: "同期失敗時にブラウザ通知",
    desc: "スプレッドシートとの同期に失敗した場合、ブラウザ通知でお知らせします。",
    default: true,
    isAdvanced: true,
  },
  {
    id: "panelScrollCheck",
    category: "高度な設定",
    label: "常時表示パネルに［上から下まで確認］ボタンを表示",
    desc: "常時表示パネルの下部にボタンを出し、押すとページの先頭から最後まで自動でスクロールして、遅れて表示される内容も含めて確認します。オフの間はボタンを表示しません。",
    default: false,
    isAdvanced: true,
  },
  {
    id: "panelPause",
    category: "高度な設定",
    label: "常時表示パネルに［一時停止（15分／1時間）］ボタンを表示",
    desc: "常時表示パネルの下部に一時停止ボタンを出し、押した間は検出・警告の表示を止めます。オフにすると、ボタンを隠すと同時に、停止中だった場合は一時停止も解除されます（「このサイトで検出をオフ」は別機能で、この設定の影響を受けません）。",
    default: false,
    isAdvanced: true,
  },
  {
    id: "betaNotice",
    category: "高度な設定",
    label: "試験版のお知らせも受け取る",
    desc: "正式版のお知らせに加えて、試験段階（テスト中）の新しい版のお知らせも、ページ上のカード・ポップアップ・アイコンのバッジ（NEW）でお知らせします。通常はオフのままで構いません。",
    default: false,
    isAdvanced: true,
  },
];

const DEFAULT_FEATURE_STATE = (() => {
  const state = {};
  for (const f of FEATURE_DEFS) state[f.id] = f.default;
  return state;
})();

// ===== 共通ユーティリティ =====

function getFeatureSettings(callback) {
  chrome.storage.local.get({ featureSettings: null }, (data) => {
    let settings = data.featureSettings;
    if (!settings) {
      settings = { master: true, features: { ...DEFAULT_FEATURE_STATE } };
    } else {
      settings.features = { ...DEFAULT_FEATURE_STATE, ...(settings.features || {}) };
      if (typeof settings.master !== "boolean") settings.master = true;
    }
    callback(settings);
  });
}

function saveFeatureSettings(settings, callback) {
  chrome.storage.local.set({ featureSettings: settings }, callback);
}

// ===== 常時表示パネルの見た目設定（透明度・位置）=====
// featureSettings とは別のキーに保存する（ポップアップ/設定画面の保存が互いを上書きしないように）。
// chrome.storage.local なのでサイトをまたいで共通・永続。
const PANEL_TRANSPARENCY_KEY = "panelTransparency"; // 0〜80（%）。0 = 透けない
const PANEL_POSITION_KEY = "panelPosition";         // { left, top }（px）。無ければ初期位置（左下）
const PANEL_TRANSPARENCY_MIN = 0;
const PANEL_TRANSPARENCY_MAX = 80;
const PANEL_TRANSPARENCY_STEP = 5;

function normalizePanelTransparency(v) {
  let n = Number(v);
  if (!Number.isFinite(n)) n = 0;
  n = Math.round(n / PANEL_TRANSPARENCY_STEP) * PANEL_TRANSPARENCY_STEP;
  return Math.min(PANEL_TRANSPARENCY_MAX, Math.max(PANEL_TRANSPARENCY_MIN, n));
}

function getPanelTransparency(callback) {
  chrome.storage.local.get({ [PANEL_TRANSPARENCY_KEY]: 0 }, (data) => {
    callback(normalizePanelTransparency(data[PANEL_TRANSPARENCY_KEY]));
  });
}

function setPanelTransparency(value, callback) {
  chrome.storage.local.set({ [PANEL_TRANSPARENCY_KEY]: normalizePanelTransparency(value) }, callback);
}

function resetPanelPosition(callback) {
  chrome.storage.local.remove(PANEL_POSITION_KEY, callback);
}

// ===== 単語の自動同期の間隔（ver10）=====
// スプレッドシートからの取り込み（検出キーワード・除外フレーズ・警告ダイアログ用ワード）を自動で行う間隔。分。
// featureSettings とは別のキーに保存する。標準は15分。
const SYNC_INTERVAL_KEY = "syncIntervalMinutes";
const SYNC_INTERVAL_DEFAULT = 15;
const SYNC_INTERVAL_CHOICES = [15, 30, 60, 180, 360, 720, 1440];

// 数値を、選べる間隔のうち一番近いものに丸める（不正な値は標準の15分）
function normalizeSyncInterval(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return SYNC_INTERVAL_DEFAULT;
  return SYNC_INTERVAL_CHOICES.reduce((best, c) => (Math.abs(c - n) < Math.abs(best - n) ? c : best), SYNC_INTERVAL_DEFAULT);
}

function getSyncInterval(callback) {
  chrome.storage.local.get({ [SYNC_INTERVAL_KEY]: SYNC_INTERVAL_DEFAULT }, (data) => {
    callback(normalizeSyncInterval(data[SYNC_INTERVAL_KEY]));
  });
}

function setSyncInterval(value, callback) {
  chrome.storage.local.set({ [SYNC_INTERVAL_KEY]: normalizeSyncInterval(value) }, callback);
}

function isFeatureActive(settings, id) {
  if (!settings || !settings.master) return false;
  return !!settings.features[id];
}

if (typeof module !== "undefined") {
  module.exports = { FEATURE_DEFS, DEFAULT_FEATURE_STATE, getFeatureSettings, saveFeatureSettings, isFeatureActive,
    normalizePanelTransparency, getPanelTransparency, setPanelTransparency, resetPanelPosition,
    SYNC_INTERVAL_DEFAULT, SYNC_INTERVAL_CHOICES, normalizeSyncInterval };
}

// offscreen.js — Tesseract.js OCR engine running in Manifest V3 Offscreen Document
// ver9.4: ワーカーを複数（PCの性能に応じて1〜3）立てて並列に読む／「速い読み」→「念入りな読み」の2段階

// ===== ワーカー（読み取りエンジン）のプール =====
const POOL_MAX = (() => {
  const c = navigator.hardwareConcurrency || 2;
  return c >= 8 ? 3 : c >= 4 ? 2 : 1;
})();
const pool = [];       // { worker, busy }
const waiters = [];    // 空きを待っている処理

async function createOcrWorker() {
  return await Tesseract.createWorker(['jpn', 'eng'], 1, {
    workerPath: chrome.runtime.getURL('lib/worker.min.js'),
    corePath: chrome.runtime.getURL('lib/tesseract-core-simd-lstm.wasm.js'),
    langPath: chrome.runtime.getURL('lib/traineddata'),
    gzip: true,
    // 重要: Manifest V3 の拡張機能ページ(offscreenドキュメント)内では、
    //    Tesseract.js のデフォルト動作（workerPathを一旦fetchしてBlob化してから
    //    Workerを起動する）が "Failed to execute 'importScripts'...failed to load"
    //    エラーで失敗することがある。workerBlobURL:false にすると、
    //    chrome-extension://.../lib/worker.min.js を直接 new Worker() で起動する
    //    方式に切り替わり、この問題を回避できる。
    workerBlobURL: false,
    logger: () => {}
  });
}

// 空いているワーカーを借りる。無ければ（上限まで）新しく作る。上限なら空くのを待つ
async function acquireWorker() {
  const free = pool.find((s) => s.worker && !s.busy);
  if (free) { free.busy = true; return free; }
  if (pool.length < POOL_MAX) {
    const slot = { worker: null, busy: true };
    pool.push(slot);
    try {
      slot.worker = await createOcrWorker();
    } catch (err) {
      pool.splice(pool.indexOf(slot), 1);
      console.error('Failed to initialize Tesseract worker:', err);
      throw err;
    }
    return slot;
  }
  return await new Promise((resolve) => waiters.push(resolve));
}

function releaseWorker(slot) {
  const next = waiters.shift();
  if (next) next(slot); // busy のまま次の処理へ渡す
  else slot.busy = false;
}

// ===== 前処理 =====
// 実測でわかったこと：小さな文字（約10px）や赤などの色付き文字は、
// 「等倍・通常のグレースケール」の1回読みだと読み飛ばされる。
// そこで、複数の倍率 × 文字色に強いグレースケール変換で読み、結果をすべて合わせる。
const MAX_OCR_WIDTH = 3200;

// ページ分割モード（PSM）。Tesseract.js の既定は「1つの文字ブロック」扱い(6)で、
// 「白文字の帯＋周囲の別の文字」のようにレイアウトが混在する画像では帯の文字が丸ごと読み飛ばされる
// （実測：サイトの「営業電話お断り」の帯）。前処理した画像は「自動(3)」「疎な文字(11)」でも読む。
const PSM_BLOCK = '6';
const PSM_AUTO = '3';
const PSM_SPARSE = '11';

// 読み方の一覧。stage='fast'：まず最短で（実測で取りこぼしを最も拾えた2通り）／'deep'：念入り（残りの読み方）
// 大きい画像ほど1回が重いので回数を絞る
function planPasses(stage, w, h, transparent) {
  const m = Math.max(w, h);
  const plan = [];
  if (stage === 'fast') {
    plan.push({ raw: true, psm: PSM_BLOCK }); // 元画像そのまま（従来の読み。前処理で逆に読めなくなる画像の保険）
    if (m <= 1200) {
      plan.push({ scale: 2, mode: 'min', psm: PSM_AUTO });
      if (transparent) plan.push({ scale: 2, mode: 'lum', bg: 'black', psm: PSM_AUTO }); // 白文字の透過PNG
    }
  } else {
    if (m <= 1200) {
      plan.push({ scale: 1, mode: 'min', psm: PSM_AUTO });
      plan.push({ scale: 3, mode: 'min', psm: PSM_AUTO });
      plan.push({ scale: 2, mode: 'min', psm: PSM_SPARSE });
      plan.push({ scale: 2, mode: 'lum', psm: PSM_AUTO }); // 色に左右されない通常のグレースケールでも
    } else if (m <= 2000) {
      plan.push({ scale: 1, mode: 'min', psm: PSM_AUTO });
      plan.push({ scale: 2, mode: 'min', psm: PSM_AUTO });
    } else {
      plan.push({ scale: 1, mode: 'min', psm: PSM_AUTO });
    }
  }
  return plan;
}

async function loadBitmap(src) {
  const res = await fetch(src);
  const blob = await res.blob();
  return await createImageBitmap(blob);
}

// mode: 'min' = R/G/B の最小値（赤・青など色付き文字が濃く出る。白文字×暗背景も保たれる）
//       'lum' = 通常の輝度グレースケール
function renderVariant(bmp, scale, mode, bg) {
  let s = Math.min(scale, MAX_OCR_WIDTH / bmp.width);
  if (scale > 1 && s < 1.05) return null; // 実質拡大できない
  s = Math.max(s, 0.1);
  const w = Math.max(1, Math.round(bmp.width * s));
  const h = Math.max(1, Math.round(bmp.height * s));
  const pad = Math.round(20 * Math.max(1, s));
  const canvas = new OffscreenCanvas(w + pad * 2, h + pad * 2);
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  // 透過PNGは背景色に合成する（透過のままだと文字が背景と同化して読めないことがある）。白文字の透過PNGは黒背景でも試す
  ctx.fillStyle = bg === 'black' ? '#000000' : '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(bmp, pad, pad, w, h);
  const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const r = d[i], g = d[i + 1], b = d[i + 2];
    const v = mode === 'min'
      ? Math.min(r, g, b)
      : Math.round(0.299 * r + 0.587 * g + 0.114 * b);
    d[i] = d[i + 1] = d[i + 2] = v;
    d[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  return canvas;
}

// 半透明・透明の部分があるか（白文字の透過PNGのバナー対策）
function hasTransparency(bmp) {
  try {
    const c = new OffscreenCanvas(bmp.width, bmp.height);
    const x = c.getContext('2d', { willReadFrequently: true });
    x.drawImage(bmp, 0, 0);
    const d = x.getImageData(0, 0, c.width, c.height).data;
    for (let i = 3; i < d.length; i += 4) if (d[i] < 250) return true;
  } catch (_e) { /* 無視 */ }
  return false;
}

function canvasToDataUrl(canvas) {
  return canvas.convertToBlob({ type: 'image/png' }).then((blob) => new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.onerror = reject;
    fr.readAsDataURL(blob);
  }));
}

// 日本語の文字どうしの間の空白・改行を詰める（OCRは「営 業 お 断 り」のように空白を入れやすい）
const CJK_CLASS = '぀-ヿ㐀-鿿ｦ-ﾟ、-〿！-｠';
const CJK_GAP_RE = new RegExp(`([${CJK_CLASS}])[\\s　]+(?=[${CJK_CLASS}])`, 'g');
function squashCjkGaps(text) {
  return String(text).replace(CJK_GAP_RE, '$1');
}

async function recognizeMulti(worker, imageSrc, stage) {
  let bmp = null;
  try {
    bmp = await loadBitmap(imageSrc);
  } catch (err) {
    // 読み込めない場合は従来どおり、元の画像をそのまま1回だけ読む（念入りの段階では何もしない）
    console.warn('[営業禁止ワード検出/OCR][offscreen] 前処理用の画像読み込みに失敗。そのまま読み取ります:', err);
    if (stage === 'deep') return { text: '', passes: 0 };
    await worker.setParameters({ tessedit_pageseg_mode: PSM_BLOCK });
    const ret = await worker.recognize(imageSrc);
    return { text: squashCjkGaps(ret?.data?.text || ''), passes: 1 };
  }

  const small = Math.max(bmp.width, bmp.height) <= 1200;
  const plan = planPasses(stage, bmp.width, bmp.height, stage === 'fast' && small && hasTransparency(bmp));
  const texts = [];
  let passes = 0;
  try {
    for (const p of plan) {
      let src;
      if (p.raw) {
        src = imageSrc;
      } else {
        const canvas = renderVariant(bmp, p.scale, p.mode, p.bg);
        if (!canvas) continue;
        src = await canvasToDataUrl(canvas);
      }
      try {
        await worker.setParameters({ tessedit_pageseg_mode: p.psm });
        const ret = await worker.recognize(src);
        const t = squashCjkGaps(ret?.data?.text || '');
        if (t.trim()) texts.push(t);
        passes++;
      } catch (err) {
        console.warn('[営業禁止ワード検出/OCR][offscreen] 1パス失敗:', p, err);
      }
    }
  } finally {
    try { bmp.close(); } catch (_e) { /* 無視 */ }
    try { await worker.setParameters({ tessedit_pageseg_mode: PSM_BLOCK }); } catch (_e) { /* 無視 */ }
  }
  return { text: texts.join('\n'), passes };
}

// Background からの OCR リクエストを受信
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.target !== 'offscreen') return;

  // ページを開いた直後に、エンジンの準備（モデルの読み込み）だけ先に済ませておく
  if (msg.type === 'warmup') {
    (async () => {
      try {
        const slot = await acquireWorker();
        releaseWorker(slot);
        sendResponse({ success: true });
      } catch (err) {
        sendResponse({ success: false, error: String(err) });
      }
    })();
    return true;
  }

  // ver9.14: サイト先読み用。画像のURLを offscreen 側で取得し（<all_urls> の権限で他サイトの画像も取れる。大きなデータをメッセージで渡さない）、
  // 大きさ・種類の条件に合うものだけ「速い読み」で1回読む。条件に合わない時は success:true, skipped:理由 を返す（エラーではない）。
  if (msg.type === 'ocrSiteImage') {
    (async () => {
      let slot = null;
      try {
        const maxBytes = Number(msg.maxBytes) || 2 * 1024 * 1024;
        const minW = Number(msg.minWidth) || 100;
        const minH = Number(msg.minHeight) || 30;
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 10000);
        let blob;
        try {
          const res = await fetch(msg.imageUrl, { credentials: 'omit', signal: ctrl.signal });
          if (!res.ok) { sendResponse({ success: true, skipped: 'http' + res.status }); return; }
          const type = (res.headers.get('content-type') || '').toLowerCase();
          if (type && !type.startsWith('image/')) { sendResponse({ success: true, skipped: 'not-image' }); return; }
          if (/svg|gif|icon/.test(type)) { sendResponse({ success: true, skipped: 'type' }); return; }
          const len = Number(res.headers.get('content-length'));
          if (len && len > maxBytes) { sendResponse({ success: true, skipped: 'too-large' }); return; }
          blob = await res.blob();
        } finally {
          clearTimeout(timer);
        }
        if (blob.size > maxBytes) { sendResponse({ success: true, skipped: 'too-large' }); return; }
        let w = 0, h = 0;
        try {
          const bmp = await createImageBitmap(blob);
          w = bmp.width; h = bmp.height;
          try { bmp.close(); } catch (_e) { /* 無視 */ }
        } catch (_e) {
          sendResponse({ success: true, skipped: 'decode' });
          return;
        }
        if (w < minW || h < minH) { sendResponse({ success: true, skipped: 'small' }); return; }
        const dataUrl = await new Promise((resolve, reject) => {
          const r = new FileReader();
          r.onloadend = () => resolve(r.result);
          r.onerror = reject;
          r.readAsDataURL(blob);
        });
        blob = null;
        slot = await acquireWorker();
        const { text } = await recognizeMulti(slot.worker, dataUrl, 'fast'); // 負荷を抑えるため「速い読み」だけ
        sendResponse({ success: true, text, width: w, height: h });
      } catch (err) {
        sendResponse({ success: false, error: String(err) });
      } finally {
        if (slot) releaseWorker(slot);
      }
    })();
    return true;
  }

  if (msg.type !== 'performOcr') return;

  (async () => {
    let slot = null;
    try {
      const imageSrc = msg.imageData || msg.imageUrl;
      if (!imageSrc) {
        console.warn('[営業禁止ワード検出/OCR][offscreen] 画像データが空でした');
        sendResponse({ success: false, error: 'No image data provided' });
        return;
      }
      if (imageSrc.startsWith('file://')) {
        console.warn(
          '[営業禁止ワード検出/OCR][offscreen] file:// URLをTesseractに直接渡しています。' +
          'このオフスクリーンページ自体に file:// への読み取り権限が無いと、ここで失敗する可能性があります:',
          imageSrc
        );
      }

      slot = await acquireWorker();
      const { text, passes } = await recognizeMulti(slot.worker, imageSrc, msg.stage === 'deep' ? 'deep' : 'fast');
      sendResponse({ success: true, text, passes });
    } catch (err) {
      console.error('[営業禁止ワード検出/OCR][offscreen] OCR recognition error:', err);
      sendResponse({ success: false, error: String(err) });
    } finally {
      if (slot) releaseWorker(slot);
    }
  })();

  return true; // 非同期レスポンス
});

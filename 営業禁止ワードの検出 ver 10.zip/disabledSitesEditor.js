// disabledSitesEditor.js — ver 10
// 「オフにしたいサイト」の入力欄（設定画面・ポップアップ共通）。
// 保存先は従来どおり chrome.storage.local の disabledSites（ドメインの配列）。
// content.js / background.js / settingsBackup.js 側の判定・形式は変更なし。

// 1つの入力（URL／ドメイン）を、保存用のドメイン（小文字・www.なし）に整える。読めなければ null
function normalizeSiteInput(raw) {
  let s = String(raw || "").trim().replace(/^[<"'「（(]+/, "").replace(/[>"'」）),;、。]+$/, "");
  if (!s) return null;
  if (/^[a-z][a-z0-9+.-]*:/i.test(s) && !/^https?:\/\//i.test(s)) return null; // chrome:// など http(s) 以外は対象外
  if (!/^https?:\/\//i.test(s)) s = "http://" + s.replace(/^\/\//, "");
  let host;
  try { host = new URL(s).hostname; } catch (_e) { return null; }
  host = String(host || "").toLowerCase().replace(/\.$/, "").replace(/^www\./, "");
  if (!host || !/^[a-z0-9._\-\[\]:]+$/.test(host)) return null;
  return host;
}

// 欄の文字列 → { sites: 重複なし・並べ替え済みのドメイン配列, invalid: 読めなかった入力 }
// 区切りは改行・空白・タブ・カンマ（スプレッドシートからの貼り付けも通る）
function parseSiteList(text) {
  const set = new Set();
  const invalid = [];
  String(text || "").split(/[\s,、]+/).forEach((tok) => {
    if (!tok) return;
    const h = normalizeSiteInput(tok);
    if (h) set.add(h); else invalid.push(tok);
  });
  return { sites: [...set].sort(), invalid };
}

// 入力欄の組み立て。els: { textarea, saveBtn, copyBtn, msg, count }、opts: { draftKey }
// 戻り値: { refresh(force) }（force=true なら入力中の内容があっても保存内容で置き換える）
function setupDisabledSitesEditor(els, opts) {
  const o = opts || {};
  const ta = els.textarea;
  let savedText = "";   // 保存済みの内容
  let baseText = "";    // 欄に最後に読み込んだ内容（これと同じなら、ユーザーは未編集）
  let savedCount = 0;

  const say = (text, kind) => {
    if (!els.msg) return;
    els.msg.textContent = text || "";
    els.msg.dataset.kind = kind || "";
  };
  const setCount = (n) => {
    savedCount = n;
    if (els.count) els.count.textContent = n ? `${n}件` : "";
  };
  const draftGet = () => { try { return o.draftKey ? localStorage.getItem(o.draftKey) : null; } catch (_e) { return null; } };
  const draftSet = (v) => {
    try {
      if (!o.draftKey) return;
      if (v == null) localStorage.removeItem(o.draftKey); else localStorage.setItem(o.draftKey, v);
    } catch (_e) { /* 無視 */ }
  };
  const showDirty = () => {
    if (ta.value !== savedText) say("未保存の変更があります。［保存］で反映されます。", "info");
  };

  function load(force, restoreDraft) {
    chrome.storage.local.get({ disabledSites: [] }, (data) => {
      const raw = Array.isArray(data.disabledSites) ? data.disabledSites : [];
      const sites = [...new Set(raw.filter((x) => typeof x === "string" && x.trim()).map((x) => x.trim()))].sort();
      savedText = sites.join("\n");
      setCount(sites.length);
      if (force || ta.value === baseText) {
        ta.value = savedText;
        baseText = savedText;
        if (force && !restoreDraft) draftSet(null); // 起動時は下書きを残す（下で復元を判断）
      }
      if (restoreDraft) {
        const d = draftGet();
        if (d != null && d !== savedText) {
          ta.value = d;
          say("保存していない下書きを復元しました。［保存］で反映されます。", "info");
        }
      }
    });
  }

  // 入力中の下書きを控える（ポップアップは、外をクリックすると閉じて内容が消えるため）
  ta.addEventListener("input", () => {
    if (ta.value === savedText) draftSet(null); else draftSet(ta.value);
    showDirty();
  });

  els.saveBtn.addEventListener("click", () => {
    const { sites, invalid } = parseSiteList(ta.value);
    if (invalid.length) {
      const shown = invalid.slice(0, 3).join(" / ") + (invalid.length > 3 ? ` ほか${invalid.length - 3}件` : "");
      say(`読み取れない入力があります（${invalid.length}件）：${shown}　直してからもう一度保存してください。`, "ng");
      return;
    }
    if (!sites.length && savedCount > 0 && !confirm(`オフにしたサイト（${savedCount}件）をすべて削除します。よろしいですか？`)) {
      say("保存を取りやめました。", "ng");
      return;
    }
    chrome.storage.local.set({ disabledSites: sites }, () => {
      if (chrome.runtime.lastError) { say("保存に失敗しました：" + chrome.runtime.lastError.message, "ng"); return; }
      savedText = sites.join("\n");
      baseText = savedText;
      ta.value = savedText; // 整えた結果（重複・www.・パスの除去、並べ替え）を欄にも反映
      setCount(sites.length);
      draftSet(null);
      say(`${sites.length}件を保存しました。開いているページにもすぐ反映されます。`, "ok");
    });
  });

  els.copyBtn.addEventListener("click", async () => {
    const text = ta.value.trim();
    if (!text) { say("コピーするサイトがありません。", "ng"); return; }
    const n = text.split(/\r?\n/).filter((l) => l.trim()).length;
    let ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (_e) { /* 下の方法を試す */ }
    if (!ok) {
      try { ta.focus(); ta.select(); ok = document.execCommand("copy"); ta.setSelectionRange(ta.value.length, ta.value.length); } catch (_e) { ok = false; }
    }
    say(ok ? `${n}件をコピーしました。` : "コピーできませんでした。欄の中身を選択してコピーしてください。", ok ? "ok" : "ng");
  });

  // 他の場所（常時パネルの［再開］・別タブの設定画面など）での変更を反映（入力中なら上書きしない）
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.disabledSites) load(false, false);
  });

  load(true, true);
  return { refresh: (force) => load(!!force, false) };
}

if (typeof module !== "undefined") module.exports = { normalizeSiteInput, parseSiteList };

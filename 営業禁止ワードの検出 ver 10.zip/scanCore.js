/*
 * scanCore.js — 一括スキャン用の判定の中核（拡張機能の一括スキャン画面と、Node版スキャンツールで共通）
 *
 * 拡張機能（content.js / background.js のサイト全体スキャン）と同じルールで判定する。
 *  ・照合前に NFKC 正規化（全角半角などの表記ゆれを吸収）
 *  ・検出語は「長い語を先に」並べて照合（短い語が先に当たって長いフレーズを取り逃がさない）
 *  ・除外フレーズの範囲に完全に含まれる検出は無視
 *  ・①一発アウトワードが1つでもある ②「営業」系と「お断り・禁止」系の両方がある → 警告
 * ブラウザ（<script>）でも Node（require）でも読み込める。
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.SalesbanScanCore = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const nfkc = (s) => String(s).normalize("NFKC");
  const escapeRegex = (w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const uniq = (arr) => [...new Set(arr)];

  const IMAGE_PREFIX = "【画像内】";
  const CJK = "\\u3040-\\u30ff\\u3400-\\u9fff\\uff66-\\uff9f";

  class Detector {
    constructor({ keywords = [], eigyo = [], kotowari = [], instant = [], excluded = [] }) {
      // 拡張機能と同じ並び：キーワード → 営業系 → 禁止・お断り系 → 一発アウト
      this.eigyo = uniq(eigyo.map(nfkc));
      this.kotowari = uniq(kotowari.map(nfkc));
      this.instant = uniq(instant.map(nfkc));
      this.excluded = uniq(excluded.map(nfkc).filter(Boolean));
      const all = [...keywords, ...eigyo, ...kotowari, ...instant].map((w) => nfkc(w).trim()).filter(Boolean);
      const ordered = uniq(all)
        .map((w, i) => ({ w, i }))
        .sort((a, b) => b.w.length - a.w.length || a.i - b.i)
        .map((x) => x.w);
      this.words = ordered;
      const pattern = ordered.map(escapeRegex).join("|");
      this.reTest = new RegExp(`(${pattern})`, "i");
      this.reG = new RegExp(`(${pattern})`, "gi");
      this.instantSet = new Set(this.instant);
      this.eigyoSet = new Set(this.eigyo);
      this.kotowariSet = new Set(this.kotowari);
    }

    _excludedRanges(text) {
      const ranges = [];
      for (const phrase of this.excluded) {
        let idx = text.indexOf(phrase);
        while (idx !== -1) {
          ranges.push([idx, idx + phrase.length]);
          idx = text.indexOf(phrase, idx + 1);
        }
      }
      return ranges;
    }

    // 1つの文字列から検出語を拾う（除外フレーズ適用済み）。戻り値: { norm, matches:[{word,start,end}] }
    findMatches(text) {
      const norm = nfkc(text);
      if (!norm || !this.reTest.test(norm)) return { norm, matches: [] };
      const ranges = this._excludedRanges(norm);
      const matches = [];
      const re = this.reG;
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(norm)) !== null) {
        if (m[0].length === 0) { re.lastIndex++; continue; }
        const start = m.index;
        const end = start + m[0].length;
        if (!ranges.some(([a, b]) => start >= a && end <= b)) matches.push({ word: m[0], start, end });
      }
      return { norm, matches };
    }

    // 文字列の配列（本文テキストノード等）をまとめて検査し、hits に積む
    //  hits: Map(word -> { sources:Set, pages:Set, snippets:[] })
    scanSegments(segments, { source, page, hits, snippetRadius = 40, maxSnippets = 3 }) {
      for (const seg of segments) {
        if (!seg) continue;
        const { norm, matches } = this.findMatches(seg);
        for (const mt of matches) {
          let h = hits.get(mt.word);
          if (!h) { h = { sources: new Set(), pages: new Set(), snippets: [] }; hits.set(mt.word, h); }
          h.sources.add(source);
          if (page) h.pages.add(page);
          if (h.snippets.length < maxSnippets) {
            const a = Math.max(0, mt.start - snippetRadius);
            const b = Math.min(norm.length, mt.end + snippetRadius);
            const snip = (a > 0 ? "…" : "") + norm.slice(a, b).replace(/\s+/g, " ") + (b < norm.length ? "…" : "");
            if (!h.snippets.includes(snip)) h.snippets.push(snip);
          }
        }
      }
    }

    classify(words) {
      const bare = (w) => (w.startsWith(IMAGE_PREFIX) ? w.slice(IMAGE_PREFIX.length) : w);
      const out = { instant: [], eigyo: [], kotowari: [], other: [] };
      for (const w0 of words) {
        const w = bare(w0);
        const isInstant = this.instantSet.has(w);
        const isEigyo = w.includes("営業") || this.eigyoSet.has(w);
        const isKotowari = w.includes("お断り") || w.includes("おことわり") || w.includes("禁止") || w.includes("ご遠慮") || this.kotowariSet.has(w);
        if (isInstant) out.instant.push(w0);
        if (isEigyo) out.eigyo.push(w0);
        if (isKotowari) out.kotowari.push(w0);
        if (!isInstant && !isEigyo && !isKotowari) out.other.push(w0);
      }
      return out;
    }

    // 拡張機能の checkCombinationAlert と同じ基準
    judge(words) {
      const c = this.classify(words);
      let label = "検出なし";
      let reason = "";
      if (c.instant.length) {
        label = "アウト（一発ワード）";
        reason = `一発アウトワード：${c.instant.slice(0, 3).join(" / ")}`;
      } else if (c.eigyo.length && c.kotowari.length) {
        label = "警告（営業×お断り）";
        reason = `営業系：${c.eigyo.slice(0, 3).join(" / ")}　お断り系：${c.kotowari.slice(0, 3).join(" / ")}`;
      } else if (words.length) {
        label = "検出のみ（警告なし）";
        reason = `単語のみ：${words.slice(0, 4).join(" / ")}`;
      }
      return { label, reason, classes: c };
    }
  }

  // OCR文字認識の結果は日本語の文字間に空白が入りやすいので、CJK文字同士の間の空白を詰める
  function squashOcrSpaces(text) {
    const re = new RegExp(`([${CJK}])[ \\t\\u3000]+(?=[${CJK}])`, "g");
    return String(text).replace(re, "$1");
  }

  // ===== HTML（DOM）から検査用テキストを取り出す =====
  //  ・拡張機能と同じ対象：本文のテキストノード（script/style/noscript/meta/title/link/dialog は除く）と input/textarea の placeholder
  //  ・追加：ブロック単位で連結した「行」。<b>営業</b>お断り のようにタグで分断された文も拾うため
  const EXCLUDE_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "META", "TITLE", "LINK", "DIALOG", "TEMPLATE"]);
  const BLOCK_TAGS = new Set([
    "ADDRESS", "ARTICLE", "ASIDE", "BLOCKQUOTE", "BODY", "DD", "DETAILS", "DIV", "DL", "DT", "FIELDSET",
    "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "H1", "H2", "H3", "H4", "H5", "H6", "HEADER", "HR", "LI",
    "MAIN", "NAV", "OL", "P", "PRE", "SECTION", "TABLE", "TBODY", "THEAD", "TFOOT", "TD", "TH", "TR", "UL",
    "OPTION", "LEGEND", "SUMMARY", "CAPTION", "BR", "TEXTAREA", "SELECT", "BUTTON",
  ]);

  // opts.images=true のとき、ページ内の画像（文字が書かれていそうな大きさのもの）の一覧も返す
  function extractFromDocument(doc, opts) {
    opts = opts || {};
    const nodes = [];
    const lines = [];
    let buf = "";
    const flush = () => {
      const t = buf.replace(/\s+/g, " ").trim();
      if (t) lines.push(t);
      buf = "";
    };
    const walk = (node) => {
      if (node.nodeType === 3) {
        const v = node.nodeValue;
        if (v && v.trim()) nodes.push(v);
        buf += v || "";
        return;
      }
      if (node.nodeType !== 1 && node.nodeType !== 11 && node.nodeType !== 9) return;
      const tag = node.nodeName;
      if (node.nodeType === 1 && EXCLUDE_TAGS.has(tag)) return;
      const block = node.nodeType === 1 && BLOCK_TAGS.has(tag);
      if (block) flush();
      for (const c of Array.from(node.childNodes)) walk(c);
      // 開いているShadow DOMの中も調べる（ライブのページ用。DOMParserで作った文書には無い）
      if (node.nodeType === 1 && node.shadowRoot) walk(node.shadowRoot);
      if (block) flush();
    };
    if (doc.body) walk(doc.body);
    flush();

    const placeholders = [];
    for (const el of doc.querySelectorAll("input[placeholder], textarea[placeholder]")) {
      const p = el.getAttribute("placeholder") || "";
      if (p.trim()) placeholders.push(p);
    }
    const links = [];
    for (const a of doc.querySelectorAll("a[href]")) {
      links.push({ href: a.getAttribute("href") || "", text: (a.textContent || "").replace(/\s+/g, " ").trim() });
    }
    const textChars = lines.reduce((n, l) => n + l.length, 0);
    const out = { nodes, lines, placeholders, links, hasForm: !!doc.querySelector("form textarea"), textChars };
    if (opts.images) {
      const seen = new Set();
      out.images = [];
      for (const img of Array.from(doc.images || [])) {
        const src = img.currentSrc || img.src || "";
        const w = img.naturalWidth || 0, h = img.naturalHeight || 0;
        if (!/^(https?:|data:image\/)/i.test(src) || seen.has(src) || w < 300 || h < 60) continue; // アイコン等の小さい画像は除く
        seen.add(src);
        out.images.push({ src, w, h });
        if (out.images.length >= 40) break;
      }
    }
    return out;
  }

  // ===== HTMLファイルの文字コード判定（UTF-8 / Shift_JIS / EUC-JP）。TextDecoder が使える環境（ブラウザ・Node）用 =====
  function decodeHtmlBuffer(arrayBuffer) {
    const u8 = arrayBuffer instanceof Uint8Array ? arrayBuffer : new Uint8Array(arrayBuffer);
    if (u8.length >= 3 && u8[0] === 0xef && u8[1] === 0xbb && u8[2] === 0xbf) return new TextDecoder("utf-8").decode(u8.subarray(3));
    const head = new TextDecoder("latin1").decode(u8.subarray(0, 4096));
    const mm = /<meta[^>]+charset\s*=\s*["']?\s*([\w\-_.:]+)/i.exec(head);
    const norm = (n) => {
      n = String(n || "").trim().toLowerCase();
      if (["shift_jis", "shift-jis", "sjis", "x-sjis", "windows-31j", "ms932", "cp932", "ms_kanji"].includes(n)) return "shift_jis";
      if (["euc-jp", "eucjp", "x-euc-jp", "ujis"].includes(n)) return "euc-jp";
      if (["utf8", "utf-8"].includes(n)) return "utf-8";
      return n;
    };
    const cs = mm ? norm(mm[1]) : "";
    if (cs) {
      try { return new TextDecoder(cs).decode(u8); } catch (_e) { /* 次へ */ }
    }
    try { return new TextDecoder("utf-8", { fatal: true }).decode(u8); } catch (_e) { /* UTF-8ではない */ }
    try { return new TextDecoder("shift_jis").decode(u8); } catch (_e) { return new TextDecoder("utf-8").decode(u8); }
  }

  // ===== ファイル名の読み取り：「5_早川産業（有）_main.html」「5_早川産業（有）_sub_1.png」 =====
  //  No と会社名で1社にまとめ、main / sub_N をその会社のページとして扱う。形式が違うファイルは単独で扱う。
  const NAME_RE = /^(\d+)_(.+)_(main|sub_\d+)\.(html?|xhtml|png|jpe?g|webp|gif|bmp)$/i;
  function parseScanFileName(fileName) {
    const name = String(fileName).normalize("NFC");
    const m = NAME_RE.exec(name);
    const ext = (/\.([a-z0-9]+)$/i.exec(name) || [])[1];
    const kind = /^(html?|xhtml)$/i.test(ext || "") ? "html" : /^(png|jpe?g|webp|gif|bmp)$/i.test(ext || "") ? "image" : "other";
    if (m) return { name, kind, grouped: true, no: m[1], company: m[2], page: m[3].toLowerCase(), groupKey: `${m[1]}_${m[2]}` };
    const stem = name.replace(/\.[^.]*$/, "");
    return { name, kind, grouped: false, no: "", company: stem, page: "", groupKey: stem };
  }

  function pageSortKey(page) {
    if (page === "main") return 0;
    const m = /^sub_(\d+)$/.exec(page || "");
    return m ? Number(m[1]) : 99;
  }

  // files: [{ name, ref }]  →  会社ごとのまとまり（Noの数字順）。ref は File やパスなど呼び出し側が自由に使える
  function groupFiles(files) {
    const groups = new Map();
    let ignored = 0;
    for (const f of files) {
      const p = parseScanFileName(f.name);
      if (p.kind === "other") { ignored++; continue; }
      let g = groups.get(p.groupKey);
      if (!g) { g = { key: p.groupKey, no: p.no, company: p.company, grouped: p.grouped, htmls: [], images: [] }; groups.set(p.groupKey, g); }
      (p.kind === "html" ? g.htmls : g.images).push({ name: p.name, page: p.page || p.name, ref: f.ref });
    }
    const list = [...groups.values()];
    for (const g of list) {
      g.htmls.sort((a, b) => pageSortKey(a.page) - pageSortKey(b.page) || a.name.localeCompare(b.name, "ja"));
      g.images.sort((a, b) => pageSortKey(a.page) - pageSortKey(b.page) || a.name.localeCompare(b.name, "ja"));
    }
    list.sort((a, b) => (a.no && b.no ? Number(a.no) - Number(b.no) : a.no ? -1 : b.no ? 1 : 0) || a.company.localeCompare(b.company, "ja"));
    return { groups: list, ignored };
  }

  // ===== URLモード：リンクの選び方・URL一覧の読み取り =====
  const CONTACT_HINTS = ["お問い合わせ", "お問合せ", "お問合わせ", "問い合わせ", "問合せ", "ご相談", "contact", "inquiry", "toiawase", "otoiawase", "mailform", "form", "mail"];
  const OTHER_HINTS = ["会社概要", "会社案内", "企業情報", "about", "company", "profile", "プライバシー", "個人情報", "privacy", "policy", "特定商取引", "特商法", "tokushoho", "利用規約", "規約", "terms", "kiyaku", "よくある質問", "faq", "サイトポリシー", "site-policy"];
  const SKIP_EXT = /\.(pdf|jpe?g|png|gif|webp|svg|zip|docx?|xlsx?|pptx?|mp4|mp3|css|js|ico)(\?|#|$)/i;
  const hostKey = (h) => String(h).toLowerCase().replace(/^www\./, "");

  function scoreLink(href, text) {
    const t = (href + " " + text).toLowerCase();
    if (CONTACT_HINTS.some((h) => t.includes(h.toLowerCase()))) return 100;
    if (OTHER_HINTS.some((h) => t.includes(h.toLowerCase()))) return 50;
    return 0;
  }

  // トップページのリンクから、同じサイトの「お問い合わせ」「会社概要」などを優先して最大 max 件選ぶ
  function pickLinks(baseUrl, links, max) {
    let base;
    try { base = new URL(baseUrl); } catch (_e) { return []; }
    const seen = new Set([base.href.replace(/#.*$/, "").replace(/\/$/, "")]);
    const cands = [];
    for (const l of links) {
      const href = (l.href || "").trim();
      if (!href || /^(mailto:|tel:|javascript:|#)/i.test(href) || SKIP_EXT.test(href)) continue;
      let u;
      try { u = new URL(href, base); } catch (_e) { continue; }
      if (!/^https?:$/.test(u.protocol) || hostKey(u.hostname) !== hostKey(base.hostname)) continue;
      u.hash = "";
      const key = u.href.replace(/\/$/, "");
      if (seen.has(key)) continue;
      const score = scoreLink(u.pathname + u.search, l.text || "");
      if (score <= 0) continue;
      seen.add(key);
      cands.push({ url: u.href, score, isContact: score >= 100 });
    }
    cands.sort((a, b) => b.score - a.score);
    return cands.slice(0, max);
  }

  // スプレッドシートからコピーした行（タブ区切り）やCSVの行から、番号・会社名・URLを読み取る
  const URL_LIKE = /^(https?:\/\/\S+|[A-Za-z0-9][A-Za-z0-9\-]*(\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}(\/\S*)?)$/;
  function parseUrlList(text) {
    const rows = [];
    const skipped = [];
    const seen = new Set();
    let duplicates = 0;
    const lines = String(text || "").replace(/^\uFEFF/, "").split(/\r?\n/);
    // 元のシートの行との対応用：貼り付けた各行の位置（0始まり）を結果に持たせる
    let lineCount = 0;
    lines.forEach((raw, idx) => { if (raw.trim()) lineCount = idx + 1; });
    let headerLine = -1;
    lines.forEach((raw, idx) => {
      const line = raw.trim();
      if (!line) return;
      let cells = line.includes("\t") ? line.split("\t") : (line.split(",").length > 1 ? line.split(",") : [line]);
      cells = cells.map((c) => c.trim().replace(/^"(.*)"$/, "$1").trim());
      const urlCell = cells.find((c) => URL_LIKE.test(c));
      if (!urlCell) { if (idx === 0) headerLine = 0; if (idx > 0 || !/url/i.test(line)) skipped.push(line); return; } // 見出し行は静かに読み飛ばす
      let url = urlCell;
      if (!/^https?:\/\//i.test(url)) url = "https://" + url;
      let parsed;
      try { parsed = new URL(url); } catch (_e) { skipped.push(line); return; }
      if (!/^https?:$/.test(parsed.protocol)) { skipped.push(line); return; }
      const others = cells.filter((c) => c && c !== urlCell);
      const no = (others.find((c) => /^\d+$/.test(c)) || "").trim();
      const company = (others.find((c) => c !== no && !URL_LIKE.test(c)) || parsed.hostname.replace(/^www\./, "")).trim();
      if (seen.has(parsed.href)) duplicates++;
      seen.add(parsed.href);
      rows.push({ no, company, url: parsed.href, startUrl: url, line: idx });
    });
    return { rows, skipped, duplicates, lineCount, headerLine };
  }

  // ===== 結果行（一括スキャン画面・CSV共通） =====
  const SRC_LABEL = { node: "本文", placeholder: "placeholder", line: "タグ分断", ocr: "画像OCR" };
  const RESULT_COLUMNS = [
    "No", "企業名", "URL", "判定", "拡張機能と同じ基準の判定", "判定理由", "一発アウト語", "営業系の語", "お断り系の語", "その他の検出語",
    "検出元", "検出箇所（前後の文）", "検出ページ", "HTML数", "画像数", "本文の文字数", "OCR", "備考", "エラー", "スキャン日時",
  ];
  const pad2 = (n) => String(n).padStart(2, "0");
  function nowIso() {
    const d = new Date();
    return `${d.getFullYear()}/${pad2(d.getMonth() + 1)}/${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
  }

  // hits から結果1行分を作る。meta: { htmlCount, imageCount, textChars, ocrDone, ocrChunks, ocrNote, notes[], error, gotAnyText }
  function buildResult(det, group, hits, meta) {
    const allWords = [...hits.keys()];
    const parityWords = allWords.filter((w) => ["node", "placeholder", "ocr"].some((s) => hits.get(w).sources.has(s)));
    const full = det.judge(allWords);
    const parity = det.judge(parityWords);
    const c = full.classes;
    const fmt = (arr) => arr.join(" / ");

    const sources = new Set();
    for (const h of hits.values()) {
      const xs = [...h.sources];
      const onlyLine = xs.length === 1 && xs[0] === "line";
      for (const x of xs) if (x !== "line" || onlyLine) sources.add(SRC_LABEL[x] || x);
    }
    const order = [...c.instant, ...c.eigyo, ...c.kotowari, ...c.other];
    const seen = new Set();
    const snippets = [];
    for (const w of order) {
      if (seen.has(w)) continue;
      seen.add(w);
      const h = hits.get(w);
      if (h && h.snippets[0]) snippets.push({ word: w.replace(IMAGE_PREFIX, ""), text: h.snippets[0] });
      if (snippets.length >= 6) break;
    }
    const pages = new Set();
    for (const h of hits.values()) for (const p of h.pages) pages.add(p);

    const notes = [...(meta.notes || [])];
    if (full.label !== parity.label) notes.push(`タグで分断された文のみで検出（拡張機能の基準では「${parity.label}」）`);
    if (meta.textChars !== undefined && meta.htmlCount && meta.textChars < 80 && !meta.ocrDone && !meta.error) {
      notes.push("本文がほとんど取れていません（画像のみのサイトの可能性。スクショOCRでの確認を推奨）");
    }
    let label = full.label;
    if (meta.error && !meta.gotAnyText) label = "読み取り失敗";

    const cells = [
      group.no, group.company, group.url || "", label,
      meta.error && !meta.gotAnyText ? "" : parity.label,
      full.reason, fmt(c.instant), fmt(c.eigyo), fmt(c.kotowari), fmt(c.other),
      [...sources].join(","),
      snippets.map((s) => `【${s.word}】${s.text}`).join(" ｜ "),
      [...pages].slice(0, 3).join(" ｜ "),
      meta.htmlCount ?? 0, meta.imageCount ?? 0, meta.textChars ?? "",
      meta.ocrDone ? `実施(${meta.ocrChunks}片)` : (meta.ocrNote || ""),
      notes.join(" / "), meta.error || "", nowIso(),
    ];
    return { label, parityLabel: parity.label, reason: full.reason, cells, snippets, pages: [...pages], notes, error: meta.error || "", group: { no: group.no, company: group.company, url: group.url || "", line: group.line } };
  }

  // ===== CSV =====
  function csvEscape(v) {
    const s = v == null ? "" : String(v);
    return /[",\r\n\t]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  const toCsvLine = (arr) => arr.map(csvEscape).join(",");
  function resultsToCsv(rows) {
    return "\uFEFF" + [toCsvLine(RESULT_COLUMNS), ...rows.map((r) => toCsvLine(r.cells))].join("\r\n") + "\r\n";
  }
  // スプレッドシートに貼り付けるためのタブ区切り（セル内の改行・タブは空白にする）
  function resultsToTsv(rows) {
    const cell = (v) => String(v == null ? "" : v).replace(/[\t\r\n]+/g, " ");
    return [RESULT_COLUMNS.map(cell).join("\t"), ...rows.map((r) => r.cells.map(cell).join("\t"))].join("\r\n");
  }

  // ===== 元のシートと比べるための貼り付け用データ =====
  // 「アウト・警告」の行だけ薄い色を付けた列を作り、元のシートに「書式のみ貼り付け」できるようにする。
  //   opts.mode   : "auto"（URL一覧＝貼り付けた行どおり／フォルダ＝結果の並び）｜"line"｜"no"（Noの番号どおり）｜"order"（結果の並び）
  //   opts.isUrl / opts.urlMeta { lineCount, headerLine } : URL一覧モードの行の対応
  //   opts.kind   : "format"（色だけ・1列）｜"cols"（判定・見つかった表現・検出ページの3列）
  //   opts.color  : アウト・警告の色／opts.colorDetect : 「検出のみ」にも同じ色を付ける／opts.colorFail : 読み取り失敗を薄い黄色にする
  const FAIL_COLOR = "#fff2cc";
  const shortLabelOf = (label) => String(label || "").replace(/（.*）/, "");
  function classOfRow(r) {
    if (!r) return "none";
    const l = String(r.label || "");
    if (/^(アウト|警告)/.test(l)) return "hit";
    if (l.startsWith("検出のみ")) return "detect";
    if (l === "読み取り失敗") return "fail";
    return "ok";
  }
  const escHtml = (v) => String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  function compareSlots(rows, opts) {
    const notes = [];
    let mode = opts.mode || "auto";
    const meta = opts.urlMeta;
    if (mode === "auto") mode = opts.isUrl && meta && rows.every((r) => r.group && r.group.line != null) ? "line" : "order";
    if (mode === "line" && !(opts.isUrl && meta)) mode = "order";
    if (mode === "line") {
      const byLine = new Map(rows.map((r) => [r.group.line, r]));
      const slots = [];
      for (let i = 0; i < meta.lineCount; i++) slots.push(i === meta.headerLine ? { header: true } : { r: byLine.get(i) || null });
      return { slots, mode, notes };
    }
    if (mode === "no") {
      const byNo = new Map();
      let max = 0, skipped = 0;
      for (const r of rows) {
        const n = /^\d+$/.test(String(r.group.no || "")) ? Number(r.group.no) : NaN;
        if (!(n >= 1) || n > 100000) { skipped++; continue; }
        if (!byNo.has(n)) byNo.set(n, r);
        if (n > max) max = n;
      }
      if (byNo.size) {
        const slots = [{ header: true }];
        for (let n = 1; n <= max; n++) slots.push({ r: byNo.get(n) || null });
        if (skipped) notes.push(`Noが読めない${skipped}件は含まれません`);
        return { slots, mode, notes };
      }
      notes.push("Noが読めないため、結果の並びでコピーしました");
    }
    return { slots: [{ header: true }, ...rows.map((r) => ({ r }))], mode: "order", notes };
  }

  function buildCompareOutput(rows, opts) {
    const { slots, mode, notes } = compareSlots(rows, opts);
    const color = opts.color || "#efefef";
    const colorOf = (r) => {
      const c = classOfRow(r);
      if (c === "hit") return color;
      if (c === "detect" && opts.colorDetect) return color;
      if (c === "fail" && opts.colorFail) return FAIL_COLOR;
      return "";
    };
    const cols = opts.kind === "cols";
    const headerCells = cols ? ["判定", "見つかった表現", "検出ページ"] : ["判定"];
    let colored = 0;
    const out = slots.map((sl) => {
      if (sl.header) return { cells: headerCells, color: "" };
      const r = sl.r;
      if (!r) return { cells: headerCells.map(() => ""), color: "" };
      const bg = colorOf(r);
      if (bg) colored++;
      if (cols) {
        return { cells: [shortLabelOf(r.label), (r.snippets || []).slice(0, 3).map((x) => x.word).join(" / "), (r.pages && r.pages[0]) || ""], color: bg };
      }
      return { cells: [bg ? shortLabelOf(r.label) : ""], color: bg };
    });
    const oneLine = (v) => String(v == null ? "" : v).replace(/[\t\r\n]+/g, " ");
    const text = out.map((o) => o.cells.map(oneLine).join("\t")).join("\r\n");
    const html = '<meta charset="utf-8"><table><tbody>' + out.map((o) =>
      "<tr>" + o.cells.map((c) => o.color
        ? `<td bgcolor="${o.color}" style="background-color:${o.color};">${escHtml(c)}</td>`
        : `<td>${escHtml(c)}</td>`).join("") + "</tr>").join("") + "</tbody></table>";
    return { html, text, lines: out.length, colored, mode, notes };
  }

  // 拡張機能（content.js）のソース文字列から、判定の初期値（内蔵ワード等）を取り出す。
  // 拡張機能の画面は eval / new Function が禁止（CSP）なので、文字列リテラルを自前で読み取る。
  function unescapeJsString(body) {
    return body.replace(/\\(u\{([0-9a-fA-F]+)\}|u([0-9a-fA-F]{4})|x([0-9a-fA-F]{2})|(.))/g, (m, _all, cpBrace, u4, x2, ch) => {
      if (cpBrace) return String.fromCodePoint(parseInt(cpBrace, 16));
      if (u4) return String.fromCharCode(parseInt(u4, 16));
      if (x2) return String.fromCharCode(parseInt(x2, 16));
      return { n: "\n", t: "\t", r: "\r", b: "\b", f: "\f", v: "\v", 0: "\0" }[ch] ?? ch;
    });
  }
  function readStringArray(literal) {
    const out = [];
    let i = 0;
    const n = literal.length;
    while (i < n) {
      const c = literal[i];
      if (c === "/" && literal[i + 1] === "/") { while (i < n && literal[i] !== "\n") i++; continue; }
      if (c === "/" && literal[i + 1] === "*") { const e = literal.indexOf("*/", i + 2); i = e < 0 ? n : e + 2; continue; }
      if (c === '"' || c === "'" || c === "`") {
        let j = i + 1;
        let body = "";
        while (j < n && literal[j] !== c) {
          if (literal[j] === "\\") { body += literal[j] + (literal[j + 1] || ""); j += 2; } else { body += literal[j]; j++; }
        }
        out.push(unescapeJsString(body));
        i = j + 1;
        continue;
      }
      i++;
    }
    return out;
  }
  function readArrayLiteral(src, declaration) {
    const i = src.indexOf(declaration + " = [");
    if (i < 0) throw new Error(`content.js から「${declaration}」が見つかりません`);
    const j = src.indexOf("\n  ];", i);
    if (j < 0) throw new Error(`「${declaration}」の終端が見つかりません`);
    return readStringArray(src.slice(i + declaration.length + 3, j + 5));
  }
  function parseExtensionDefaults(contentJsSource) {
    return {
      keywords: readArrayLiteral(contentJsSource, "const DEFAULT_KEYWORDS"),
      eigyo: readArrayLiteral(contentJsSource, "let EIGYO_CATEGORY_WORDS"),
      kotowari: readArrayLiteral(contentJsSource, "let KOTOWARI_CATEGORY_WORDS"),
      instant: readArrayLiteral(contentJsSource, "let INSTANT_ALERT_PHRASES"),
      excluded: readArrayLiteral(contentJsSource, "const DEFAULT_EXCLUDED_PHRASES"),
    };
  }

  return {
    Detector, nfkc, squashOcrSpaces, IMAGE_PREFIX, extractFromDocument, decodeHtmlBuffer,
    parseScanFileName, groupFiles, buildResult, RESULT_COLUMNS, resultsToCsv, resultsToTsv, toCsvLine,
    parseExtensionDefaults, readArrayLiteral, SRC_LABEL, nowIso, pickLinks, parseUrlList, scoreLink, buildCompareOutput, classOfRow,
  };
});
